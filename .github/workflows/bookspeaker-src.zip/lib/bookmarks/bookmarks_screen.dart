/// Screen 7 — every bookmark across every book.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../library/book_model.dart';
import '../player/player_screen.dart';
import '../widgets/book_cover.dart';
import '../widgets/conflict_sheet.dart';

class BookmarksScreen extends StatelessWidget {
  const BookmarksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final entries = state.local.allBookmarks();

    return Scaffold(
      appBar: AppBar(title: const Text('Bookmarks')),
      body: entries.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.bookmarks_outlined,
                        size: 64, color: Theme.of(context).disabledColor),
                    const SizedBox(height: 16),
                    const Text('No bookmarks yet',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    const Text(
                      'Tap the bookmark button in the player to save a moment.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
              itemCount: entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final (bookmark, bookId, bookTitle) = entries[i];
                final target = state.db.book(bookId) ??
                    (state.books.isEmpty ? _dummyBook() : state.books.first);
                return Card(
                  child: ListTile(
                    contentPadding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    leading: SizedBox(
                      width: 44,
                      height: 44,
                      child: BookCover(book: target, showProgressBar: false, radius: 8),
                    ),
                    title: Text(bookTitle,
                        maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (bookmark.label.isNotEmpty) Text(bookmark.label),
                        Text(
                          '${formatDuration(Duration(milliseconds: bookmark.position_ms), hours: false)}'
                          ' • ${formatTimestamp(bookmark.created)}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => PlayerScreen(book: target),
                    )),
                    onLongPress: () => state.deleteBookmark(target, bookmark.id),
                  ),
                );
              },
            ),
    );
  }

  static Book _dummyBook() => Book(
        bookId: 'placeholder',
        title: 'Unknown',
        author: '',
        filePath: '',
        folderName: '',
        format: AudioFormat.mp3,
        totalDuration: Duration.zero,
        dateAdded: DateTime.now(),
        isAvailable: false,
      );
}
