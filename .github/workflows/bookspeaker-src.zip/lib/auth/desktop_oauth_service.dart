/// Google sign-in for Windows (and any other desktop) without Play Services.
///
/// Android signs in through Google Play Services. Windows has no such thing, so
/// this uses the flow Google requires for installed apps: the app opens the
/// user's own browser for consent and listens on a loopback address
/// (http://127.0.0.1:<port>) for the reply. That is RFC 8252, and it means the
/// user types their password into Google's own page — never into this app.
///
/// The client it talks to must be a **Desktop app** OAuth client from the same
/// Google Cloud project as the Android one, so both devices share the same
/// hidden Drive app folder.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'google_auth.dart';

/// Where the refresh token and account details are kept between launches.
abstract class TokenStore {
  Future<Map<String, dynamic>?> read();
  Future<void> write(Map<String, dynamic>? value);
}

/// Default store: one small JSON file beside the app's other data.
class FileTokenStore implements TokenStore {
  const FileTokenStore();

  Future<File?> _file() async {
    try {
      final dir = await getApplicationSupportDirectory();
      return File('${dir.path}${Platform.pathSeparator}google_desktop_auth.json');
    } catch (_) {
      return null; // No support directory: stay signed in for this run only.
    }
  }

  @override
  Future<Map<String, dynamic>?> read() async {
    try {
      final file = await _file();
      if (file == null || !await file.exists()) return null;
      return jsonDecode(await file.readAsString()) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> write(Map<String, dynamic>? value) async {
    try {
      final file = await _file();
      if (file == null) return;
      if (value == null) {
        if (await file.exists()) await file.delete();
        return;
      }
      await file.create(recursive: true);
      await file.writeAsString(jsonEncode(value));
    } catch (_) {
      // Losing the stored token only means signing in again next launch.
    }
  }
}

/// In-memory store, used by tests.
class MemoryTokenStore implements TokenStore {
  Map<String, dynamic>? _value;
  @override
  Future<Map<String, dynamic>?> read() async => _value;
  @override
  Future<void> write(Map<String, dynamic>? value) async => _value = value;
}

class DesktopGoogleAuthService extends GoogleAuth {
  DesktopGoogleAuthService({
    String? clientId,
    this.clientSecret = '',
    http.Client Function()? httpClientFactory,
    TokenStore? store,
    Future<void> Function(String url)? openBrowser,
    this.signInTimeout = const Duration(minutes: 5),
  })  : clientId = (clientId ?? '').trim(),
        _newClient = httpClientFactory ?? http.Client.new,
        _store = store ?? const FileTokenStore(),
        _openBrowser = openBrowser ?? openInSystemBrowser;

  /// OAuth client id. Empty means the build has none compiled in, and the
  /// settings screen offers a field to paste one.
  String clientId;
  /// Google issues Desktop app clients a secret as well as an id, and the
  /// token exchange is rejected with `client_secret is missing` without it.
  /// It is not really confidential — every install of the app can read it — but
  /// Google requires it to be sent.
  String clientSecret;

  final Duration signInTimeout;
  final http.Client Function() _newClient;
  final TokenStore _store;
  final Future<void> Function(String url) _openBrowser;

  static const _tokenEndpoint = 'https://oauth2.googleapis.com/token';
  static const _revokeEndpoint = 'https://oauth2.googleapis.com/revoke';
  static const _userInfoEndpoint = 'https://openidconnect.googleapis.com/v1/userinfo';

  /// drive.appdata is a hidden, app-private folder: the app can never see the
  /// rest of the user's Drive. openid/email/profile are only used to show which
  /// account is connected.
  static const scopes = <String>[
    'openid',
    'email',
    'profile',
    'https://www.googleapis.com/auth/drive.appdata',
  ];

  bool get isConfigured => clientId.isNotEmpty;

  /// Which client ID to actually use.
  ///
  /// A value typed into Settings is a deliberate choice and must beat whatever
  /// the build shipped with — otherwise correcting a wrong client ID would
  /// require rebuilding the whole app.
  static String resolveClientId({required String compiled, required String stored}) {
    final fromSettings = stored.trim();
    return fromSettings.isNotEmpty ? fromSettings : compiled.trim();
  }

  /// Google hands out a JSON file for Desktop clients. Accepting it saves
  /// copying two long strings by hand, which is where mistakes happen.
  /// Returns whatever could be found; empty strings when it is not JSON.
  static ({String id, String secret}) parseClientJson(String text) {
    final trimmed = text.trim();
    if (!trimmed.startsWith('{') || !trimmed.contains('"')) {
      return (id: '', secret: '');
    }
    try {
      final decoded = jsonDecode(trimmed);
      if (decoded is! Map) return (id: '', secret: '');
      // The file nests everything under "installed" (or "web"/"desktop").
      Map<dynamic, dynamic> node = decoded;
      for (final key in ['installed', 'desktop', 'web']) {
        final inner = decoded[key];
        if (inner is Map) { node = inner; break; }
      }
      return (
        id: (node['client_id'] as String?)?.trim() ?? '',
        secret: (node['client_secret'] as String?)?.trim() ?? '',
      );
    } catch (_) {
      return (id: '', secret: '');
    }
  }

  /// Google client IDs are always
  /// `<project number>-<random>.apps.googleusercontent.com`, e.g.
  /// `481266824841-utk24fqnq2uhjgnvrokqpfils3dmcosh.apps.googleusercontent.com`.
  static final _clientIdShape = RegExp(
    r'^\d{6,}-[a-z0-9_\-]{16,}\.apps\.googleusercontent\.com$',
    caseSensitive: false,
  );

  /// Catches the common mistakes here rather than leaving Google to answer with
  /// something opaque.
  static String? validateClientId(String value) {
    final v = value.trim();
    if (v.isEmpty) return 'Paste the client ID from your Google Cloud project.';
    if (v.contains(RegExp(r'\s'))) return 'A client ID has no spaces in it.';
    if (!v.toLowerCase().endsWith('.apps.googleusercontent.com')) {
      return 'That does not look like a Google client ID — it should end with '
          '.apps.googleusercontent.com';
    }
    if (!_clientIdShape.hasMatch(v)) {
      return 'That is not the usual client ID shape. It should read like '
          '1234567890-abcdefghijklmnop.apps.googleusercontent.com, exactly as '
          'shown on the Credentials page.';
    }
    return null;
  }

  /// Builds the consent URL. Pure, so the parameters Google insists on can be
  /// asserted in a test rather than discovered in a browser error page.
  static Uri buildAuthUrl({
    required String clientId,
    required String redirectUri,
    required String state,
    required String codeChallenge,
  }) {
    return Uri.https('accounts.google.com', '/o/oauth2/v2/auth', {
      'client_id': clientId,
      'redirect_uri': redirectUri,
      'response_type': 'code',
      'scope': scopes.join(' '),
      'access_type': 'offline',
      'prompt': 'consent',
      'state': state,
      'code_challenge': codeChallenge,
      'code_challenge_method': 'S256',
    });
  }

  @override
  bool get usesBrowserSignIn => true;

  String? _refreshToken;
  String? _accessToken;
  DateTime? _expiry;
  GoogleAuthUser? _user;
  bool _busy = false;
  bool _restored = false;
  String? _lastError;

  @override
  GoogleAuthUser? get user => _user;
  @override
  bool get isSignedIn => _refreshToken != null;
  @override
  bool get busy => _busy;
  @override
  String? get lastError => _lastError;

  @override
  String? get setupHint {
    if (!isConfigured) {
      return 'This build has no Google client ID yet. Paste a Desktop app '
          'client ID below to enable sync.';
    }
    if (!isSignedIn) {
      return 'Signing in opens your browser. Your password is typed on '
          'Google\'s page, never in this app.';
    }
    return null;
  }

  void _setBusy(bool value) {
    _busy = value;
    notifyListeners();
  }

  // ------------------------------------------------------------------ storage

  Future<void> restore() async {
    if (_restored) return;
    _restored = true;
    final saved = await _store.read();
    if (saved == null) return;
    _refreshToken = saved['refresh_token'] as String?;
    final email = saved['email'] as String?;
    if (email != null) {
      _user = GoogleAuthUser(
        email: email,
        displayName: (saved['name'] as String?) ?? email,
        photoUrl: saved['picture'] as String?,
      );
    }
    notifyListeners();
  }

  Future<void> _persist() async {
    final token = _refreshToken;
    if (token == null) {
      await _store.write(null);
      return;
    }
    await _store.write({
      'refresh_token': token,
      'email': _user?.email,
      'name': _user?.displayName,
      'picture': _user?.photoUrl,
      'saved_at': DateTime.now().toIso8601String(),
    });
  }

  // ------------------------------------------------------------------- tokens

  @override
  Future<String?> validAccessToken() async {
    await restore();
    if (_refreshToken == null) return null;
    final expiry = _expiry;
    if (_accessToken != null &&
        expiry != null &&
        DateTime.now().isBefore(expiry.subtract(const Duration(minutes: 5)))) {
      return _accessToken;
    }
    try {
      await _refreshAccessToken();
      return _accessToken;
    } catch (e) {
      _lastError = _friendly(e);
      notifyListeners();
      return null;
    }
  }

  Future<void> _refreshAccessToken() async {
    final token = _refreshToken;
    if (token == null) throw StateError('not signed in');
    final client = _newClient();
    try {
      final response = await client
          .post(
            Uri.parse(_tokenEndpoint),
            headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
            body: {
              'grant_type': 'refresh_token',
              'refresh_token': token,
              'client_id': clientId,
              if (clientSecret.isNotEmpty) 'client_secret': clientSecret,
            },
          )
          // A hung network must not hold up the app's first frame.
          .timeout(const Duration(seconds: 15));
      final body = _decode(response.body);
      if (response.statusCode != 200) {
        // A revoked or expired refresh token means the user must sign in again.
        if (body['error'] == 'invalid_grant') {
          await _forget();
          throw StateError('Google sign-in has expired. Connect again.');
        }
        throw StateError(_googleError(body, response.statusCode));
      }
      _adoptTokens(body);
    } finally {
      client.close();
    }
  }

  void _adoptTokens(Map<String, dynamic> body) {
    _accessToken = body['access_token'] as String?;
    final expiresIn = (body['expires_in'] as num?)?.toInt() ?? 3600;
    _expiry = DateTime.now().add(Duration(seconds: expiresIn));
    final refresh = body['refresh_token'] as String?;
    if (refresh != null && refresh.isNotEmpty) _refreshToken = refresh;
  }

  // --------------------------------------------------------------- sign-in

  @override
  Future<bool> signIn() async {
    if (!isConfigured) {
      _lastError = 'No Google client ID is set for this build. Add a Desktop '
          'app client ID in Settings ▸ Account.';
      notifyListeners();
      return false;
    }
    _setBusy(true);
    _lastError = null;
    HttpServer? server;
    try {
      server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      final redirect = 'http://127.0.0.1:${server.port}/';
      final verifier = _randomUrlSafe(48);
      final challenge =
          base64Url.encode(sha256.convert(utf8.encode(verifier)).bytes).replaceAll('=', '');
      final state = _randomUrlSafe(16);

      final authUrl = buildAuthUrl(
        clientId: clientId,
        redirectUri: redirect,
        state: state,
        codeChallenge: challenge,
      );
      debugPrint('Bookspeaker: Google sign-in URL has '
          '${authUrl.queryParameters.length} parameters');

      await _openBrowser(authUrl.toString());
      final reply = await _awaitReply(server, state);
      if (reply.error != null) {
        _lastError = reply.error;
        return false;
      }

      final client = _newClient();
      try {
        final response = await client.post(
          Uri.parse(_tokenEndpoint),
          headers: const {'Content-Type': 'application/x-www-form-urlencoded'},
          body: {
            'grant_type': 'authorization_code',
            'code': reply.code!,
            'redirect_uri': redirect,
            'client_id': clientId,
            'code_verifier': verifier,
            if (clientSecret.isNotEmpty) 'client_secret': clientSecret,
          },
        );
        final body = _decode(response.body);
        if (response.statusCode != 200) {
          throw StateError(_googleError(body, response.statusCode));
        }
        _adoptTokens(body);
        await _readProfile(body['id_token'] as String?);
      } finally {
        client.close();
      }

      await _persist();
      notifyListeners();
      return true;
    } catch (e) {
      _lastError = _friendly(e);
      return false;
    } finally {
      await server?.close(force: true);
      _setBusy(false);
    }
  }

  /// Waits for Google to redirect back to the loopback address.
  Future<_AuthReply> _awaitReply(HttpServer server, String expectedState) {
    final completer = Completer<_AuthReply>();
    late StreamSubscription<HttpRequest> subscription;
    final timer = Timer(signInTimeout, () {
      if (!completer.isCompleted) {
        completer.complete(_AuthReply.failure(
            'Timed out waiting for the browser. Nothing was changed.'));
      }
    });

    subscription = server.listen((request) async {
      final params = request.uri.queryParameters;
      try {
        request.response
          ..statusCode = 200
          ..headers.contentType = ContentType.html
          ..write(_replyPage(params));
        await request.response.close();
      } catch (_) {
        // The browser may have gone away already.
      }
      if (completer.isCompleted) return;
      timer.cancel();
      await subscription.cancel();

      if (params['error'] != null) {
        completer.complete(_AuthReply.failure(params['error'] == 'access_denied'
            ? 'Sign-in was cancelled.'
            : 'Google returned: ${params['error']}'));
      } else if (params['state'] != expectedState) {
        completer.complete(_AuthReply.failure(
            'The reply did not match this request. Please try again.'));
      } else if (params['code'] == null) {
        completer.complete(_AuthReply.failure(
            'Google did not send an authorization code.'));
      } else {
        completer.complete(_AuthReply.success(params['code']!));
      }
    });
    return completer.future;
  }

  @override
  Future<bool> signInSilently() async {
    await restore();
    if (_refreshToken == null) return false;
    final token = await validAccessToken();
    return token != null;
  }

  @override
  Future<void> signOut() async {
    final token = _refreshToken;
    if (token != null) {
      // Best effort: ask Google to drop the grant as well as forgetting it here.
      try {
        final client = _newClient();
        try {
          await client
              .post(Uri.parse('$_revokeEndpoint?token=$token'))
              .timeout(const Duration(seconds: 10));
        } finally {
          client.close();
        }
      } catch (_) {}
    }
    await _forget();
    _lastError = null;
    notifyListeners();
  }

  Future<void> _forget() async {
    _refreshToken = null;
    _accessToken = null;
    _expiry = null;
    _user = null;
    await _store.write(null);
  }

  // ---------------------------------------------------------------- profile

  /// Reads the account's name and picture out of the id_token, falling back to
  /// the userinfo endpoint. Never fails the sign-in over display details.
  Future<void> _readProfile(String? idToken) async {
    if (idToken != null) {
      try {
        final parts = idToken.split('.');
        if (parts.length >= 2) {
          final payload = utf8.decode(
              base64Url.decode(base64Url.normalize(parts[1])));
          final claims = jsonDecode(payload) as Map<String, dynamic>;
          final email = claims['email'] as String?;
          if (email != null) {
            _user = GoogleAuthUser(
              email: email,
              displayName: (claims['name'] as String?) ?? email,
              photoUrl: claims['picture'] as String?,
            );
            return;
          }
        }
      } catch (_) {}
    }
    try {
      final client = _newClient();
      try {
        final response = await client
            .get(
              Uri.parse(_userInfoEndpoint),
              headers: {'Authorization': 'Bearer $_accessToken'},
            )
            .timeout(const Duration(seconds: 10));
        if (response.statusCode == 200) {
          final body = _decode(response.body);
          final email = body['email'] as String?;
          if (email != null) {
            _user = GoogleAuthUser(
              email: email,
              displayName: (body['name'] as String?) ?? email,
              photoUrl: body['picture'] as String?,
            );
          }
        }
      } finally {
        client.close();
      }
    } catch (_) {}
  }

  // ------------------------------------------------------------------ helpers

  Map<String, dynamic> _decode(String body) {
    try {
      final value = jsonDecode(body);
      return value is Map<String, dynamic> ? value : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  /// Public so the wording for a Google rejection can be tested directly.
  String explainTokenError(Map<String, dynamic> body) => _googleError(body, 400);

  String _googleError(Map<String, dynamic> body, int status) {
    final error = (body['error'] as String?) ?? 'http_$status';
    final description = (body['error_description'] as String?) ?? '';
    if (error == 'redirect_uri_mismatch') {
      return 'Google rejected the redirect. The client ID must belong to a '
          '"Desktop app" OAuth client — web clients cannot use this sign-in.';
    }
    if (error == 'invalid_client') {
      return 'Google did not recognise this client ID. Check it was copied '
          'whole, and that it is a Desktop app client.';
    }
    if (description.contains('client_secret')) {
      return 'Google needs this client\'s secret as well. In Cloud Console open '
          'Credentials, click your Desktop app client, copy its "Client secret", '
          'then paste it beside the client ID in Settings.';
    }
    if (error == 'invalid_grant') return 'Google sign-in has expired.';
    return description.isNotEmpty ? '$error — $description' : error;
  }

  String _friendly(Object e) {
    // A socket failure can arrive bare or wrapped in an http ClientException.
    if (e is SocketException || e.toString().contains('SocketException')) {
      return 'Could not reach Google. Check this PC\'s internet connection.';
    }
    if (e is TimeoutException) return 'Google took too long to answer.';
    final text = e.toString();
    return text.startsWith('Bad state: ') ? text.substring(11) : text;
  }

  static String _randomUrlSafe(int bytes) {
    final random = Random.secure();
    final data = List<int>.generate(bytes, (_) => random.nextInt(256));
    return base64Url.encode(data).replaceAll('=', '');
  }

  /// The page the browser lands on once consent is finished.
  static String _replyPage(Map<String, String> params) {
    final failed = params['error'] != null;
    final title = failed ? 'Sign-in wasn\'t completed' : 'Bookspeaker is connected';
    final line = failed
        ? 'You can close this tab and try again in the app.'
        : 'You can close this tab and go back to Bookspeaker.';
    return '<!DOCTYPE html><html><head><meta charset="utf-8">'
        '<title>$title</title><style>'
        'body{margin:0;height:100vh;display:grid;place-items:center;'
        'background:#1b1230;color:#f2eefb;font:16px/1.5 system-ui,Segoe UI,Roboto,sans-serif}'
        'div{text-align:center;max-width:420px;padding:28px}'
        'h1{font-size:20px;margin:0 0 8px}p{color:#c9c0e6;margin:0}'
        '.mark{width:52px;height:52px;border-radius:16px;margin:0 auto 16px;'
        'background:linear-gradient(135deg,#4A3580,#C4A35A);display:grid;place-items:center;'
        'font-weight:800;font-size:24px;color:#fff}</style></head><body><div>'
        '<div class="mark">B</div><h1>$title</h1><p>$line</p></div></body></html>';
  }
}

/// A command to run, kept separate from running it so it can be tested.
class BrowserCommand {
  final String executable;
  final List<String> arguments;
  const BrowserCommand(this.executable, this.arguments);
  @override
  String toString() => '$executable ${arguments.join(' ')}';
}

/// How to hand [url] to the desktop's browser.
///
/// The URL must reach the browser **byte for byte**. OAuth URLs are full of
/// `&`, and `cmd.exe` reads `&` as "run another command", so launching through
/// `cmd /c start` silently truncated the request after the second parameter —
/// Google then answered "Required parameter is missing: response_type".
/// PowerShell receives the URL as a quoted literal instead, where `&` is just
/// a character.
BrowserCommand browserCommandFor(
  String url, {
  bool? onWindows,
  bool? onMacOS,
}) {
  final windows = onWindows ?? Platform.isWindows;
  final macos = onMacOS ?? Platform.isMacOS;
  if (windows) {
    if (url.contains("'")) {
      // URLs percent-encode quotes, so this should never happen — but keep a
      // shell-free route available rather than risk mangling the request.
      return BrowserCommand('rundll32', ['url.dll,FileProtocolHandler', url]);
    }
    return BrowserCommand(
      'powershell',
      ['-NoProfile', '-NonInteractive', '-Command', "Start-Process '$url'"],
    );
  }
  if (macos) return BrowserCommand('open', [url]);
  return BrowserCommand('xdg-open', [url]);
}

/// Opens a URL in whatever browser the desktop uses.
Future<void> openInSystemBrowser(String url) async {
  final command = browserCommandFor(url);
  debugPrint('Bookspeaker: opening the browser for Google sign-in '
      '(${command.executable})');
  final result = await Process.run(
    command.executable,
    command.arguments,
    runInShell: false,
  );
  if (result.exitCode != 0 && Platform.isWindows &&
      command.executable != 'rundll32') {
    // Last resort if PowerShell is unavailable or blocked by policy.
    await Process.run('rundll32', ['url.dll,FileProtocolHandler', url]);
  }
}

class _AuthReply {
  final String? code;
  final String? error;
  const _AuthReply._(this.code, this.error);
  factory _AuthReply.success(String code) => _AuthReply._(code, null);
  factory _AuthReply.failure(String error) => _AuthReply._(null, error);
}
