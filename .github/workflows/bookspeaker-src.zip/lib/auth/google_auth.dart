/// The authentication contract the rest of the app depends on.
///
/// Progress sync only needs one thing from auth: a valid access token. Keeping
/// that behind an interface means Android (Play Services) and Windows (system
/// browser + loopback) can share every line of the sync code.
library;

import 'package:flutter/foundation.dart';

class GoogleAuthUser {
  final String email;
  final String displayName;
  final String? photoUrl;
  const GoogleAuthUser({
    required this.email,
    required this.displayName,
    this.photoUrl,
  });
}

abstract class GoogleAuth extends ChangeNotifier {
  GoogleAuthUser? get user;

  bool get isSignedIn;

  bool get busy;

  /// Human-readable reason the last attempt failed, if any.
  String? get lastError;

  /// A valid access token, refreshed when it is close to expiring.
  Future<String?> validAccessToken();

  Future<bool> signIn();

  /// Never shows UI. Returns false when there is nothing to resume from.
  Future<bool> signInSilently();

  Future<void> signOut();

  /// True when sign-in goes through the system browser (desktop), false when
  /// the platform handles it natively (Android).
  bool get usesBrowserSignIn => false;

  /// A short line the settings screen shows when something still needs setting
  /// up. Null when there is nothing to say.
  String? get setupHint => null;
}
