/// Observable authentication state for the UI.
library;

import 'package:flutter/foundation.dart';

import 'desktop_oauth_service.dart';
import 'google_auth.dart';

enum AuthMode { localOnly, signedOut, signedIn }

class AuthState extends ChangeNotifier {
  AuthState(this.service) {
    service.addListener(notifyListeners);
  }

  final GoogleAuth service;

  AuthMode get mode {
    if (service.isSignedIn) return AuthMode.signedIn;
    return AuthMode.signedOut;
  }

  GoogleAuthUser? get user => service.user;

  /// Non-null on desktop, where sign-in goes through the system browser.
  DesktopGoogleAuthService? get desktop =>
      service is DesktopGoogleAuthService ? service as DesktopGoogleAuthService : null;
  bool get signedIn => service.isSignedIn;

  Future<bool> signIn() => service.signIn();
  Future<void> signOut() => service.signOut();
  Future<bool> trySilentSignIn() => service.signInSilently();
  Future<String?> validAccessToken() => service.validAccessToken();

  @override
  void dispose() {
    service.removeListener(notifyListeners);
    super.dispose();
  }
}
