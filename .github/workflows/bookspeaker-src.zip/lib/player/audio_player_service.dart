/// Playback engine: just_audio for the audio, audio_service for the Android
/// media notification / lock-screen controls.
///
/// Performance rules enforced here:
///  * notification state is published at most once per second (the platform
///    interpolates the position itself between updates);
///  * UI listeners are notified at most ~5×/s and only when the position really
///    moved, so the library screen never rebuilds during playback;
///  * Google Drive pushes are fire-and-forget — nothing on the UI path waits
///    for the network.
library;

import 'dart:async';
import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../library/book_model.dart';
import '../progress/drive_sync_service.dart';
import '../progress/local_storage_service.dart';

class AudioPlayerService extends ChangeNotifier {
  AudioPlayerService(
    this.local,
    this.sync, {
    AudioPlayer? audioPlayer,
    this.localSaveInterval = const Duration(seconds: 10),
    this.drivePushInterval = const Duration(seconds: 30),
  }) : player = audioPlayer ?? AudioPlayer();

  final LocalStorageService local;
  final DriveSyncService sync;

  /// Spec cadence: local SQLite every 10 s, Drive every 30 s while playing.
  final Duration localSaveInterval;
  final Duration drivePushInterval;

  final AudioPlayer player;

  BookspeakerAudioHandler? _handler;
  Book? _currentBook;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  double _speed = 1.0;
  bool _playing = false;
  String? _error;
  bool _completed = false;

  Timer? _localSaveTimer;
  Timer? _drivePushTimer;

  /// Timestamps of the last cadence ticks — shown in Settings so the 10 s / 30 s
  /// cadence is visibly running during playback.
  DateTime? _lastLocalSaveAt;
  DateTime? _lastDrivePushAt;
  int _localSaveTick = 0;
  int _drivePushTick = 0;

  DateTime? get lastLocalSaveAt => _lastLocalSaveAt;
  DateTime? get lastDrivePushAt => _lastDrivePushAt;
  int get localSaveTick => _localSaveTick;
  int get drivePushTick => _drivePushTick;
  bool get cadenceRunning => _drivePushTimer?.isActive ?? false;

  // Throttling state.
  Duration _lastNotifiedPosition = Duration.zero;
  DateTime _lastPublished = DateTime.fromMillisecondsSinceEpoch(0);

  static const _notifyInterval = Duration(milliseconds: 250);
  static const _publishInterval = Duration(milliseconds: 900);

  Book? get currentBook => _currentBook;
  Duration get position => _position;
  Duration get duration => _duration;
  double get speed => _speed;
  bool get playing => _playing;
  String? get error => _error;
  bool get hasBook => _currentBook != null;

  Duration get remaining {
    final left = (_duration - _position).inMilliseconds.clamp(0, 1 << 62);
    final s = _speed <= 0 ? 1.0 : _speed;
    return Duration(milliseconds: (left / s).round());
  }

  /// Wires the audio_service handler after `AudioService.init` completes.
  void attachHandler(BookspeakerAudioHandler handler) {
    _handler = handler;
  }

  Future<void> init() async {
    player.playerStateStream.listen((state) {
      _playing = state.playing;
      if (state.processingState == ProcessingState.completed) {
        _onCompleted();
      }
      _publish(force: true);
      notifyListeners();
    });

    player.positionStream.listen((p) {
      _position = p;
      // Only wake the UI when the position visibly moved.
      if ((p - _lastNotifiedPosition).abs() >= _notifyInterval || p == Duration.zero) {
        _lastNotifiedPosition = p;
        notifyListeners();
      }
      _publish();
    });

    player.durationStream.listen((d) {
      if (d != null && d.inMilliseconds > 0 && d != _duration) {
        _duration = d;
        _publish(force: true);
        notifyListeners();
      }
    });
  }

  /// Loads a book and starts (or resumes) playback.
  Future<void> openBook(Book book, {Duration? startAt, bool autoplay = true}) async {
    // Switching books: flush the book we are leaving — locally *and* to Drive
    // (spec: push immediately on book switch), fire-and-forget.
    final previous = _currentBook;
    _saveLocal();
    if (previous != null && previous.bookId != book.bookId) {
      unawaited(sync.pushBook(previous));
    }
    _currentBook = book;
    _error = null;
    _completed = false;
    notifyListeners();

    try {
      final loaded = await player.setFilePath(book.filePath);
      _duration = loaded ?? book.totalDuration;
      final progress = local.db.ensureProgress(book);
      _speed = progress.playbackSpeed <= 0 ? 1.0 : progress.playbackSpeed;
      await player.setSpeed(_speed);
      await _applySkipSilence();
      final resume = startAt ?? Duration(milliseconds: progress.position_ms);
      if (resume > Duration.zero &&
          (loaded == null || resume < loaded - const Duration(seconds: 5))) {
        await player.seek(resume);
        _position = resume;
      }
      _publishMediaItem(book);
      if (autoplay) await play();
    } catch (e) {
      // Never guess: say what actually went wrong. Until now every failure —
      // including "there is no audio player on this platform at all" — showed
      // the same "may have been moved or deleted" line, which sent the reader
      // looking for a missing file that was sitting right there.
      _error = _describeOpenFailure(book, e);
      debugPrint('Bookspeaker: could not open "${book.filePath}" → $e');
      notifyListeners();
    }
  }

  /// Turns an open failure into a sentence someone can act on.
  String _describeOpenFailure(Book book, Object error) {
    final message = error.toString();
    final exists = File(book.filePath).existsSync();

    if (!exists) {
      return 'File not found. It may have been moved or deleted:\n${book.filePath}';
    }
    if (message.contains('MissingPluginException') ||
        message.contains('No implementation found')) {
      return 'This build has no audio player for this platform, so nothing can '
          'play. Install the build that includes the Windows audio engine.';
    }
    if (book.format == AudioFormat.opus && !Platform.isAndroid) {
      return 'This .opus file could not be decoded. Windows has no built-in '
          'Opus decoder — MP3 and M4A books play normally.';
    }
    final short = message.replaceAll(RegExp(r'\s+'), ' ').trim();
    return 'Could not open this file.\n'
        '${short.length > 200 ? '${short.substring(0, 200)}…' : short}';
  }

  /// Silence skipping is OFF unless the user turns it on in Settings.
  Future<void> _applySkipSilence() async {
    final enabled = local.skipSilence;
    try {
      await player.setSkipSilenceEnabled(enabled);
    } catch (_) {
      // Not every platform/format supports it — harmless when it fails.
    }
  }

  /// Called when the user flips the setting while a book is loaded.
  Future<void> refreshSkipSilence() => _applySkipSilence();

  Future<void> play() async {
    if (_currentBook == null) return;
    if (_completed) {
      await player.seek(Duration.zero);
      _completed = false;
    }
    _startTimers();
    await player.play();
    local.recordDeviceHistory(_currentBook!, _position);
    _publish(force: true);
    notifyListeners();
  }

  Future<void> pause() async {
    // Stop the cadence, then flush — synchronously — so "push immediately on
    // pause" happens on the tap itself, not after a platform round-trip.
    _stopTimers();
    _saveLocal();
    final book = _currentBook;
    if (book != null) unawaited(sync.pushBook(book));
    notifyListeners();
    try {
      await player.pause();
    } catch (_) {
      // Player already gone: the position is already saved and pushed.
    }
  }

  Future<void> toggle() async => _playing ? pause() : play();

  Future<void> seek(Duration position) async {
    await player.seek(position);
    _position = position;
    _lastNotifiedPosition = position;
    _publish(force: true);
    notifyListeners();
  }

  Future<void> seekToFraction(double fraction) {
    final target = Duration(
      milliseconds: (_duration.inMilliseconds * fraction.clamp(0.0, 1.0)).round(),
    );
    return seek(target);
  }

  Future<void> skipForward() =>
      seekRelative(Duration(seconds: local.skipForwardSeconds));

  Future<void> skipBackward() =>
      seekRelative(-Duration(seconds: local.skipBackwardSeconds));

  Future<void> seekRelative(Duration delta) async {
    var target = _position + delta;
    if (target < Duration.zero) target = Duration.zero;
    if (_duration > Duration.zero && target > _duration) target = _duration;
    await seek(target);
  }

  Future<void> setSpeed(double value) async {
    _speed = value.clamp(0.5, 3.0);
    await player.setSpeed(_speed);
    final book = _currentBook;
    if (book != null) {
      local.saveProgress(book, position: _position, total: _duration, speed: _speed);
    }
    _publish(force: true);
    notifyListeners();
  }

  /// Cycles 0.5 / 0.75 / 1 / 1.25 / 1.5 / 1.75 / 2 / 2.5 / 3.
  static const speedSteps = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0];

  Future<void> cycleSpeed() async {
    final index = speedSteps.indexOf(_speed);
    final next = index == -1 ? 2 : (index + 1) % speedSteps.length;
    await setSpeed(speedSteps[next]);
  }

  Future<void> setVolume(double volume) => player.setVolume(volume);

  Future<void> closeBook() async {
    _saveLocal();
    final book = _currentBook;
    if (book != null) unawaited(sync.pushBook(book));
    await player.stop();
    _stopTimers();
    _currentBook = null;
    _position = Duration.zero;
    _duration = Duration.zero;
    _completed = false;
    _handler?.mediaItem.add(null);
    _publish(force: true);
    notifyListeners();
  }

  void _onCompleted() {
    _completed = true;
    final book = _currentBook;
    if (book != null) {
      local.saveProgress(book,
          position: _duration, total: _duration, finished: true, queueForSync: true);
      local.recordDeviceHistory(book, _duration);
      unawaited(sync.pushBook(book));
    }
    _stopTimers();
    notifyListeners();
  }

  // ---------------------------------------------------------- persistence

  void _startTimers() {
    _localSaveTimer?.cancel();
    _drivePushTimer?.cancel();
    // Spec: local every 10 s, Drive every 30 s while playing.
    _localSaveTimer = Timer.periodic(localSaveInterval, (_) {
      _localSaveTick++;
      _lastLocalSaveAt = DateTime.now();
      _saveLocal();
    });
    _drivePushTimer = Timer.periodic(drivePushInterval, (_) {
      final book = _currentBook;
      if (book == null) return;
      _drivePushTick++;
      _lastDrivePushAt = DateTime.now();
      unawaited(sync.pushBook(book));
    });
    notifyListeners();
  }

  void _stopTimers() {
    if (_localSaveTimer == null && _drivePushTimer == null) return;
    _localSaveTimer?.cancel();
    _drivePushTimer?.cancel();
    notifyListeners();
  }

  void _saveLocal() {
    final book = _currentBook;
    if (book == null) return;
    local.saveProgress(book, position: _position, total: _duration, speed: _speed);
    local.recordDeviceHistory(book, _position);
  }

  /// Public version used on pause / book switch / app close.
  /// [push] defaults to true — all of those are spec moments to reach Drive.
  Future<void> saveAndPush({bool push = true, bool awaitPush = false}) async {
    final book = _currentBook;
    if (book == null) return;
    _saveLocal();
    if (!push) return;
    if (awaitPush) {
      await sync.pushBook(book).timeout(const Duration(seconds: 6), onTimeout: () {});
    } else {
      unawaited(sync.pushBook(book));
    }
  }

  // ------------------------------------------------- audio_service bridge

  void _publish({bool force = false}) {
    final handler = _handler;
    if (handler == null) return;
    final now = DateTime.now();
    if (!force && now.difference(_lastPublished) < _publishInterval) return;
    _lastPublished = now;

    handler.playbackState.add(PlaybackState(
      controls: [
        MediaControl.rewind,
        if (_playing) MediaControl.pause else MediaControl.play,
        MediaControl.fastForward,
        MediaControl.stop,
      ],
      systemActions: const {
        MediaAction.seek,
        MediaAction.seekForward,
        MediaAction.seekBackward,
      },
      androidCompactActionIndices: const [0, 1, 2],
      processingState: _completed
          ? AudioProcessingState.completed
          : (_currentBook == null
              ? AudioProcessingState.idle
              : AudioProcessingState.ready),
      playing: _playing,
      updatePosition: _position,
      bufferedPosition: _duration,
      speed: _speed,
    ));
  }

  void _publishMediaItem(Book book) {
    final handler = _handler;
    if (handler == null) return;
    handler.mediaItem.add(MediaItem(
      id: book.bookId,
      title: book.title,
      artist: book.author.isEmpty ? 'Unknown author' : book.author,
      album: book.folderName,
      duration: _duration.inMilliseconds > 0 ? _duration : book.totalDuration,
      artUri: book.coverCachePath != null ? Uri.file(book.coverCachePath!) : null,
      extras: {'path': book.filePath},
    ));
  }

  void refreshMediaItemCover(Book book) {
    if (_currentBook?.bookId == book.bookId) _publishMediaItem(book);
  }

  @override
  void dispose() {
    _localSaveTimer?.cancel();
    _drivePushTimer?.cancel();
    player.dispose();
    super.dispose();
  }
}

/// The audio_service handler. Every control the user can press — notification,
/// lock screen, Bluetooth headset — lands on [AudioPlayerService].
class BookspeakerAudioHandler extends BaseAudioHandler with SeekHandler {
  BookspeakerAudioHandler(this.service);

  final AudioPlayerService service;

  @override
  Future<void> play() => service.play();

  @override
  Future<void> pause() => service.pause();

  @override
  Future<void> stop() async {
    await service.pause();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) => service.seek(position);

  @override
  Future<void> rewind() => service.skipBackward();

  @override
  Future<void> fastForward() => service.skipForward();

  @override
  Future<void> setSpeed(double speed) => service.setSpeed(speed);
}

/// Reports whether the underlying audio file still exists.
bool bookFileExists(Book book) => File(book.filePath).existsSync();
