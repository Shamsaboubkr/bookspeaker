/// Sleep timer: pauses playback after a chosen duration.
library;

import 'dart:async';

import 'package:flutter/foundation.dart';

class SleepTimerService extends ChangeNotifier {
  SleepTimerService();

  Timer? _ticker;
  DateTime? _endsAt;
  Duration? _duration;
  bool _fadeOut = true;
  VoidCallback? onElapsed;

  Duration? get duration => _duration;
  bool get active => _endsAt != null;
  bool get fadeOut => _fadeOut;
  void Function(double volume)? onFade;

  Duration get remaining {
    final end = _endsAt;
    if (end == null) return Duration.zero;
    final left = end.difference(DateTime.now());
    return left.isNegative ? Duration.zero : left;
  }

  static const presets = <Duration>[
    Duration(minutes: 5),
    Duration(minutes: 10),
    Duration(minutes: 15),
    Duration(minutes: 30),
    Duration(minutes: 45),
    Duration(minutes: 60),
  ];

  void start(Duration duration, {bool fadeOut = true}) {
    cancel();
    _duration = duration;
    _fadeOut = fadeOut;
    _endsAt = DateTime.now().add(duration);
    _ticker = Timer.periodic(const Duration(seconds: 1), _tick);
    notifyListeners();
  }

  void _tick(Timer timer) {
    final left = remaining;
    // Soft fade over the last 20 seconds so it never cuts off mid-sentence.
    if (_fadeOut && left.inSeconds <= 20 && onFade != null) {
      onFade!(0.15 + 0.85 * (left.inMilliseconds / 20000.0));
    }
    if (left <= Duration.zero) {
      timer.cancel();
      _endsAt = null;
      _duration = null;
      onFade?.call(1.0);
      onElapsed?.call();
      notifyListeners();
      return;
    }
    notifyListeners();
  }

  void addMinutes(int minutes) {
    if (_endsAt == null) return start(Duration(minutes: minutes));
    _endsAt = _endsAt!.add(Duration(minutes: minutes));
    _duration = _duration! + Duration(minutes: minutes);
    notifyListeners();
  }

  void cancel() {
    _ticker?.cancel();
    _ticker = null;
    _endsAt = null;
    _duration = null;
    onFade?.call(1.0);
    notifyListeners();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
