/// Screen 5 — the player.
library;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../library/book_model.dart';
import 'audio_player_service.dart';
import 'sleep_timer_service.dart';
import '../progress/drive_sync_service.dart';
import '../widgets/book_cover.dart';
import '../widgets/conflict_sheet.dart';
import '../widgets/cover_lookup_sheet.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key, required this.book});

  final Book book;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  StreamSubscription<SyncConflict>? _conflictSub;
  bool _conflictShown = false;
  bool _opening = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  Future<void> _start() async {
    final state = context.read<AppState>();
    if (state.player.currentBook?.bookId != widget.book.bookId) {
      await state.openBook(widget.book);
    } else {
      await state.theme.applyCover(state.db.book(widget.book.bookId)?.coverCachePath);
    }
    if (mounted) setState(() => _opening = false);

    _conflictSub = state.sync.conflicts.listen((conflict) async {
      if (conflict.bookId != widget.book.bookId || _conflictShown || !mounted) return;
      _conflictShown = true;
      final choice = await showConflictSheet(context, conflict);
      if (choice != null) {
        await state.sync.resolveConflict(conflict, choice);
        final updated = state.db.book(widget.book.bookId);
        if (updated != null) {
          await state.player.openBook(updated,
              startAt: Duration(milliseconds: choice.position_ms));
        }
      }
    });
  }

  @override
  void dispose() {
    _conflictSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    // Only this screen (and the mini player) listens to playback, so the rest
    // of the app stays perfectly still while audio plays.
    final playback = context.watch<AudioPlayerService>();
    final theme = Theme.of(context);
    final palette = state.theme.palette;
    final dark = theme.brightness == Brightness.dark;
    final book = state.db.book(widget.book.bookId) ?? widget.book;
    final duration = playback.duration.inMilliseconds > 0
        ? playback.duration
        : book.totalDuration;
    final position = playback.position;
    final maxMs = duration.inMilliseconds == 0 ? 1.0 : duration.inMilliseconds.toDouble();

    return PopScope(
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) context.read<AudioPlayerService>().saveAndPush();
      },
      child: Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).maybePop(),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_horiz),
            onSelected: (value) async {
              switch (value) {
                case 'bookmark':
                  await _addBookmark(state, book);
                  break;
                case 'cover':
                  await state.setCoverFromFilePicker(book);
                  break;
                case 'cover_online':
                  if (mounted) showCoverLookupSheet(context, state, book);
                  break;
                case 'sleep':
                  await _showSleepTimerSheet(context, state);
                  break;
                case 'speed':
                  await _showSpeedSheet(context, state);
                  break;
                case 'reopen':
                  await state.player.openBook(book);
                  break;
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'bookmark', child: Text('Add bookmark')),
              PopupMenuItem(value: 'cover', child: Text('Set cover art from device')),
              PopupMenuItem(value: 'cover_online', child: Text('Find cover art online')),
              PopupMenuItem(value: 'sleep', child: Text('Sleep timer')),
              PopupMenuItem(value: 'speed', child: Text('Playback speed')),
              PopupMenuItem(value: 'reopen', child: Text('Restart from saved position')),
            ],
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: dark
                ? [
                    Color.lerp(palette.darkMuted, Colors.black, 0.25)!,
                    Color.lerp(palette.darkMuted, Colors.black, 0.72)!,
                  ]
                : [
                    Color.lerp(palette.lightMuted, Colors.white, 0.35)!,
                    Color.lerp(palette.lightMuted, Colors.white, 0.9)!,
                  ],
          ),
        ),
        child: Stack(
          children: [
            Positioned.fill(child: TitleWatermark(title: book.title)),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 16),
                child: Column(
                  children: [
                    const SizedBox(height: 24),
                    Expanded(
                      flex: 6,
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: 1,
                          child: DecoratedBox(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.32),
                                  blurRadius: 34,
                                  offset: const Offset(0, 16),
                                ),
                              ],
                            ),
                            child: BookCover(
                              book: book,
                              radius: 20,
                              showProgressBar: false,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    Text(
                      book.title,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleLarge
                          ?.copyWith(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      book.author.isEmpty ? 'Unknown author' : book.author,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(color: theme.textTheme.bodyMedium?.color?.withOpacity(0.7)),
                    ),
                    const SizedBox(height: 18),
                    if (playback.error != null)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          playback.error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                        ),
                      ),
                    Slider(
                      value: position.inMilliseconds.toDouble().clamp(0, maxMs),
                      max: maxMs,
                      onChanged: (v) =>
                          playback.seek(Duration(milliseconds: v.round())),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(formatDuration(position),
                              style: theme.textTheme.bodySmall),
                          Text(formatDuration(duration),
                              style: theme.textTheme.bodySmall),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _SkipButton(
                          seconds: state.local.skipBackwardSeconds,
                          forward: false,
                          onTap: playback.skipBackward,
                          onLongPress: () =>
                              _showSkipSheet(context, state, forward: false),
                        ),
                        const SizedBox(width: 26),
                        SizedBox(
                          width: 82,
                          height: 82,
                          child: FilledButton(
                            style: FilledButton.styleFrom(
                              shape: const CircleBorder(),
                              padding: EdgeInsets.zero,
                              backgroundColor: theme.colorScheme.primary,
                            ),
                            onPressed: _opening ? null : playback.toggle,
                            child: _opening
                                ? const CircularProgressIndicator(strokeWidth: 2)
                                : Icon(
                                    playback.playing
                                        ? Icons.pause
                                        : Icons.play_arrow,
                                    size: 42,
                                    color: theme.colorScheme.onPrimary,
                                  ),
                          ),
                        ),
                        const SizedBox(width: 26),
                        _SkipButton(
                          seconds: state.local.skipForwardSeconds,
                          forward: true,
                          onTap: playback.skipForward,
                          onLongPress: () =>
                              _showSkipSheet(context, state, forward: true),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _BottomAction(
                          icon: Icons.speed,
                          label: '${playback.speed}x',
                          onTap: playback.cycleSpeed,
                          onLongPress: () => _showSpeedSheet(context, state),
                        ),
                        _BottomAction(
                          icon: Icons.nightlight_round,
                          label: state.sleepTimer.active
                              ? _formatCountdown(state.sleepTimer.remaining)
                              : 'Sleep',
                          onTap: () => _showSleepTimerSheet(context, state),
                          onLongPress: state.sleepTimer.cancel,
                        ),
                        _BottomAction(
                          icon: Icons.bookmark_add_outlined,
                          label: 'Bookmark',
                          onTap: () => _addBookmark(state, book),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }

  static String _formatCountdown(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  Future<void> _addBookmark(AppState state, Book book) async {
    final controller = TextEditingController();
    final label = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add bookmark'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Label (optional)',
            hintText: 'Great quote here',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (label == null) return;
    final bm = await state.addBookmark(book, label);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Bookmarked at ${formatDuration(state.player.position)}'
          '${bm.label.isEmpty ? '' : ' — ${bm.label}'}'),
    ));
  }
}

/// Skip control. The forward button is the *mirror image* of the rewind
/// button, so both look and measure exactly the same.
class _SkipButton extends StatelessWidget {
  const _SkipButton({
    required this.seconds,
    required this.forward,
    required this.onTap,
    this.onLongPress,
  });

  final int seconds;
  final bool forward;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final color = theme.colorScheme.primary;

    return Semantics(
      button: true,
      label: forward ? 'Skip forward $seconds seconds' : 'Skip back $seconds seconds',
      child: InkResponse(
        radius: 38,
        onTap: onTap,
        onLongPress: onLongPress,
        child: SizedBox(
          width: 72,
          height: 72,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Transform.flip(
                flipX: forward,
                child: Icon(Icons.replay, size: 56, color: color),
              ),
              // The seconds sit inside the circular arrow, like the stock
              // Android skip controls.
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  '$seconds',
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w800,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BottomAction extends StatelessWidget {
  const _BottomAction({
    required this.icon,
    required this.label,
    required this.onTap,
    this.onLongPress,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      onLongPress: onLongPress,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(
          children: [
            Icon(icon, size: 22, color: theme.colorScheme.primary),
            const SizedBox(height: 4),
            Text(label, style: theme.textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

Future<void> _showSpeedSheet(BuildContext context, AppState state) async {
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Playback speed',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('Saved per book',
              style: Theme.of(sheetContext).textTheme.bodySmall),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              for (final speed in AudioPlayerService.speedSteps)
                ChoiceChip(
                  label: Text('${speed}x'),
                  selected: context.read<AudioPlayerService>().speed == speed,
                  onSelected: (_) {
                    context.read<AudioPlayerService>().setSpeed(speed);
                    Navigator.pop(sheetContext);
                  },
                ),
            ],
          ),
        ],
      ),
    ),
  );
}

Future<void> _showSleepTimerSheet(BuildContext context, AppState state) async {
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Sleep timer',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final preset in SleepTimerService.presets)
                ActionChip(
                  label: Text('${preset.inMinutes} min'),
                  onPressed: () {
                    state.sleepTimer.start(preset);
                    Navigator.pop(sheetContext);
                  },
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: () => state.sleepTimer.addMinutes(5),
                icon: const Icon(Icons.add),
                label: const Text('5 minutes'),
              ),
              const SizedBox(width: 12),
              if (state.sleepTimer.active)
                OutlinedButton.icon(
                  onPressed: () {
                    state.sleepTimer.cancel();
                    Navigator.pop(sheetContext);
                  },
                  icon: const Icon(Icons.close),
                  label: const Text('Cancel timer'),
                ),
            ],
          ),
        ],
      ),
    ),
  );
}

Future<void> _showSkipSheet(BuildContext context, AppState state,
    {required bool forward}) async {
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(forward ? 'Skip forward duration' : 'Skip backward duration',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final seconds in const [5, 10, 15, 30, 45, 60])
                ChoiceChip(
                  label: Text('${seconds}s'),
                  selected: forward
                      ? state.local.skipForwardSeconds == seconds
                      : state.local.skipBackwardSeconds == seconds,
                  onSelected: (_) {
                    if (forward) {
                      state.setSkipForward(seconds);
                    } else {
                      state.setSkipBackward(seconds);
                    }
                    Navigator.pop(sheetContext);
                  },
                ),
            ],
          ),
        ],
      ),
    ),
  );
}
