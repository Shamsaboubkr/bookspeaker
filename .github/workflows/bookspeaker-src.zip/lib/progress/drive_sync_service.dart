/// Google Drive progress sync (progress only — never audio).
///
/// Layout mirrors the specification exactly, inside the hidden Drive
/// app-data folder:
///
///   Bookspeaker/
///     manifest.json
///     <bookId>_progress.json
///
/// Offline-first: the local database is always the source of truth for
/// writes; Drive is a mirror that is reconciled on app open, on book open,
/// every 30 s while playing, and whenever connectivity returns.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:_discoveryapis_commons/_discoveryapis_commons.dart' as commons;
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:http/http.dart' as http;

import '../auth/google_sign_in_service.dart';
import '../data/db.dart';
import '../library/book_model.dart';
import 'local_storage_service.dart';

enum SyncState { idle, syncing, offline, driveFull, signedOut, error }

/// One entry in the internal sync log.
///
/// Not shown in the UI any more — it is kept because it is the only record of
/// *why* a push failed, and it is what made the "Client is already closed" bug
/// findable. Surfaced only on request.
class SyncActivity {
  final DateTime at;
  final String label;
  final int positionMs;
  final bool ok;
  final String detail;
  final int count;

  const SyncActivity({
    required this.at,
    required this.label,
    required this.positionMs,
    required this.ok,
    required this.detail,
    this.count = 1,
  });

  SyncActivity again({required DateTime at, required int positionMs}) =>
      SyncActivity(
        at: at,
        label: label,
        positionMs: positionMs,
        ok: ok,
        detail: detail,
        count: count + 1,
      );
}

/// Raised when a book has divergent positions on two devices.
class SyncConflict {
  final String bookId;
  final String title;
  final String author;
  final BookProgress local;
  final BookProgress remote;
  final List<DeviceHistoryEntry> options;
  SyncConflict({
    required this.bookId,
    required this.title,
    required this.author,
    required this.local,
    required this.remote,
    required this.options,
  });
}

class _BearerClient extends http.BaseClient {
  _BearerClient(this._inner, this._token);
  final http.Client _inner;
  final String _token;

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers['Authorization'] = 'Bearer $_token';
    return _inner.send(request);
  }

  @override
  void close() => _inner.close();
}

class DriveSyncService extends ChangeNotifier {
  DriveSyncService(
    this.local,
    this.auth, {
    http.Client Function()? httpClientFactory,
  }) : _newHttpClient = httpClientFactory ?? http.Client.new;

  final LocalStorageService local;
  final GoogleSignInService auth;

  /// Every Drive session gets its **own** http client. The previous build
  /// shared one client for the whole app run and closed it after the first
  /// session, so every later request died with "Client is already closed."
  final http.Client Function() _newHttpClient;

  static const folderName = 'Bookspeaker';
  static const manifestName = 'manifest.json';
  static const conflictWindow = Duration(seconds: 60);

  final StreamController<SyncConflict> _conflicts =
      StreamController<SyncConflict>.broadcast();

  SyncState _state = SyncState.signedOut;
  DateTime? _lastSync;
  String? _lastError;
  Timer? _retryTimer;
  Timer? _syncingHoldTimer;
  bool _syncing = false;

  /// Minimum time the chip stays on "Syncing…" so a fast push is perceivable.
  static const _minSyncingVisible = Duration(milliseconds: 900);

  DateTime? _syncingSince;
  final List<SyncActivity> _activity = <SyncActivity>[];

  SyncState get state => _state;
  DateTime? get lastSync => _lastSync;
  String? get lastError => _lastError;
  bool get isSignedIn => auth.isSignedIn;
  Stream<SyncConflict> get conflicts => _conflicts.stream;

  /// Internal only — no UI reads this any more.
  List<SyncActivity> get activity => List.unmodifiable(_activity);
  SyncActivity? get lastActivity => _activity.isEmpty ? null : _activity.first;

  void _log({
    required String label,
    required int positionMs,
    required bool ok,
    required String detail,
  }) {
    final now = DateTime.now();
    final last = _activity.isEmpty ? null : _activity.first;
    final repeat = !ok &&
        last != null &&
        !last.ok &&
        last.label == label &&
        last.detail == detail &&
        now.difference(last.at) < const Duration(minutes: 2);
    if (repeat) {
      _activity[0] = last.again(at: now, positionMs: positionMs);
    } else {
      _activity.insert(
        0,
        SyncActivity(
          at: now,
          label: label,
          positionMs: positionMs,
          ok: ok,
          detail: detail,
        ),
      );
    }
    if (_activity.length > 30) _activity.removeRange(30, _activity.length);
  }

  BookspeakerDb get db => local.db;

  // ------------------------------------------------------------- plumbing

  Future<DriveSession?> _session() async {
    if (!auth.isSignedIn) {
      _setState(SyncState.signedOut);
      return null;
    }
    final token = await auth.validAccessToken();
    if (token == null) {
      _setState(SyncState.signedOut);
      return null;
    }
    return buildSession(token, _newHttpClient);
  }

  /// Builds one short-lived session over its own http client, so closing it
  /// cannot affect any other session.
  @visibleForTesting
  static DriveSession buildSession(String token, http.Client Function() newClient) {
    final client = _BearerClient(newClient(), token);
    return DriveSession(drive.DriveApi(client), client);
  }

  void _setState(SyncState s, {String? error}) {
    _lastError = error;

    if (s == SyncState.syncing) {
      _syncingSince = DateTime.now();
      _syncingHoldTimer?.cancel();
    }

    if (s == SyncState.idle) {
      _lastSync = DateTime.now();
      local.lastSyncedAt = _lastSync!.toIso8601String();
      // Hold "Syncing…" briefly so the 30 s cadence is visible, not a flicker.
      final since = _syncingSince;
      _syncingSince = null;
      final elapsed =
          since == null ? _minSyncingVisible : DateTime.now().difference(since);
      if (elapsed < _minSyncingVisible) {
        _syncingHoldTimer?.cancel();
        _state = SyncState.syncing;
        _syncingHoldTimer = Timer(_minSyncingVisible - elapsed, () {
          if (_syncingSince == null) {
            _state = SyncState.idle;
            notifyListeners();
          }
        });
        notifyListeners();
        return;
      }
    }

    _state = s;
    notifyListeners();
  }

  /// One short, human-readable line from a long API/exception message.
  static String _tidy(Object error) {
    var text = error.toString().split('\n').first.trim();
    final uri = text.indexOf(', uri=');
    if (uri > 0) text = text.substring(0, uri);
    if (text.length > 72) text = '${text.substring(0, 69)}…';
    return text;
  }

  String _shortReason(SyncState s, Object error) => switch (s) {
        SyncState.driveFull => 'Drive is full',
        SyncState.signedOut => 'sign-in expired',
        SyncState.offline => 'offline — retrying in 45 s',
        _ => 'sync failed — ${_tidy(error)}',
      };

  /// Short one-liner for the Settings error line (null when all is well).
  String? get errorSummary => _lastError == null ? null : _tidy(_lastError!);

  Future<bool> _online() async {
    try {
      final results = await Connectivity().checkConnectivity();
      return results.any((r) => r != ConnectivityResult.none);
    } catch (_) {
      return true; // assume online; the API call will tell us otherwise
    }
  }

  /// App-data folder id, created on first use.
  Future<String?> _folderId(drive.DriveApi api) async {
    final list = await api.files.list(
      q: "name = '$folderName' and mimeType = 'application/vnd.google-apps.folder' and trashed = false",
      spaces: 'appDataFolder',
      $fields: 'files(id,name)',
    );
    final existing = list.files;
    if (existing != null && existing.isNotEmpty && existing.first.id != null) {
      return existing.first.id;
    }
    final folder = drive.File()
      ..name = folderName
      ..mimeType = 'application/vnd.google-apps.folder'
      ..parents = ['appDataFolder'];
    final created = await api.files.create(folder, $fields: 'id');
    return created.id;
  }

  Future<drive.File?> _findFile(drive.DriveApi api, String name) async {
    final list = await api.files.list(
      q: "name = '$name' and trashed = false",
      spaces: 'appDataFolder',
      $fields: 'files(id,name,modifiedTime,size)',
    );
    final files = list.files ?? const <drive.File>[];
    return files.isEmpty ? null : files.first;
  }

  Future<void> _writeJson(
    drive.DriveApi api,
    String name,
    Map<String, Object?> payload,
  ) async {
    final bytes = Uint8List.fromList(utf8.encode(jsonEncode(payload)));
    final media = commons.Media(
      Stream.value(bytes),
      bytes.length,
      contentType: 'application/json',
    );
    final existing = await _findFile(api, name);
    if (existing?.id != null) {
      await api.files.update(drive.File(), existing!.id!, uploadMedia: media);
    } else {
      final folderId = await _folderId(api);
      final meta = drive.File()
        ..name = name
        ..parents = [if (folderId != null) folderId else 'appDataFolder'];
      await api.files.create(meta, uploadMedia: media);
    }
  }

  Future<Map<String, dynamic>?> _readJson(drive.DriveApi api, String name) async {
    final file = await _findFile(api, name);
    if (file?.id == null) return null;
    final media = await api.files.get(
      file!.id!,
      downloadOptions: commons.DownloadOptions.fullMedia,
    ) as commons.Media;
    final chunks = await media.stream.toList();
    final bytes = chunks.expand((c) => c).toList();
    if (bytes.isEmpty) return null;
    return jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
  }

  /// Classifies Drive API failures so the UI can react (quota, offline, auth).
  ///
  /// Unrecognised errors used to be reported as "offline", which labelled a
  /// programming bug as a network problem.
  @visibleForTesting
  static SyncState classifyError(Object error) {
    if (error is commons.DetailedApiRequestError) {
      final reasons = error.errors.map((e) => e.reason ?? '').join(',');
      if (error.status == 403 &&
          (reasons.contains('quota') || reasons.contains('storageQuota'))) {
        return SyncState.driveFull;
      }
      if (error.status == 401 || error.status == 403) return SyncState.signedOut;
      if (error.status == 429 || (error.status ?? 0) >= 500) return SyncState.offline;
      return SyncState.error;
    }
    if (error is http.ClientException) {
      return error.message.contains('already closed')
          ? SyncState.error
          : SyncState.offline;
    }
    if (error is SocketException || error is TimeoutException) {
      return SyncState.offline;
    }
    return SyncState.error;
  }

  SyncState _classify(Object error) => classifyError(error);

  // -------------------------------------------------------------- syncing

  /// Full reconciliation: pull what is newer, push what is pending.
  Future<void> syncNow() async {
    if (_syncing) return;
    if (!auth.isSignedIn) {
      _setState(SyncState.signedOut);
      return;
    }
    if (!await _online()) {
      _setState(SyncState.offline);
      _scheduleRetry();
      return;
    }

    _syncing = true;
    _setState(SyncState.syncing);
    DriveSession? session;
    try {
      session = await _session();
      if (session == null) {
        _setState(SyncState.signedOut); // never leave the chip on "Syncing…"
        return;
      }
      final api = session.api;

      // 1. Push everything that is pending locally.
      for (final progress in db.pendingSync()) {
        final book = db.book(progress.bookId);
        if (book == null) continue;
        await _push(api, progress, book);
      }

      // 2. Pull the manifest and adopt anything newer from other devices.
      final manifest = await _readJson(api, manifestName);
      final entries = (manifest?['books'] as List?) ?? const [];
      for (final raw in entries) {
        if (raw is! Map) continue;
        final entry = raw.cast<String, dynamic>();
        final bookId = entry['bookId'] as String?;
        if (bookId == null) continue;
        final file = (entry['progressFile'] as String?) ?? '${bookId}_progress.json';
        final remoteJson = await _readJson(api, file);
        if (remoteJson == null) continue;
        await _reconcile(bookId, remoteJson, notifyConflict: false);
      }

      await _writeManifest(api);
      _log(label: 'Full sync', positionMs: 0, ok: true,
          detail: 'pulled ${entries.length} book(s) from Drive');
      _setState(SyncState.idle);
    } catch (error) {
      final state = _classify(error);
      _log(label: 'Full sync', positionMs: 0, ok: false,
          detail: _shortReason(state, error));
      _setState(state, error: error.toString());
      if (state == SyncState.offline) _scheduleRetry();
    } finally {
      session?.client.close();
      _syncing = false;
    }
  }

  /// Quick check when a book is opened: pull silently if another device is
  /// ahead; raise [conflicts] when both devices have real, divergent positions.
  Future<void> pullForBook(Book book) async {
    if (!auth.isSignedIn || !await _online()) return;
    DriveSession? session;
    try {
      session = await _session();
      if (session == null) return;
      final json = await _readJson(session.api, '${book.bookId}_progress.json');
      if (json == null) return;
      await _reconcile(book.bookId, json, notifyConflict: true, book: book);
    } catch (error) {
      final state = _classify(error);
      if (state == SyncState.driveFull || state == SyncState.signedOut) {
        _setState(state);
      }
    } finally {
      session?.client.close();
    }
  }

  /// Compare remote vs local for one book and decide: adopt, push, or ask.
  Future<void> _reconcile(
    String bookId,
    Map<String, dynamic> remoteJson, {
    required bool notifyConflict,
    Book? book,
  }) async {
    final localProgress = db.progressFor(bookId);
    final remote = BookProgress.fromDriveJson(remoteJson, fallbackBookId: bookId);
    final target = book ?? db.book(bookId);
    final title = target?.title ?? (remoteJson['title'] as String?) ?? 'Audiobook';
    final author = target?.author ?? (remoteJson['author'] as String?) ?? '';

    // Merge bookmarks both ways (union by id) — never lose a bookmark.
    final mergedBookmarks = <String, Bookmark>{
      for (final b in remote.bookmarks) b.id: b,
      if (localProgress != null) for (final b in localProgress.bookmarks) b.id: b,
    };
    db.replaceBookmarks(bookId, mergedBookmarks.values.toList());

    if (localProgress == null) {
      // Book unknown locally: only keep the metadata for later adoption.
      final adopted = BookProgress.fromDriveJson(remoteJson, fallbackBookId: bookId)
        ..syncStatus = SyncStatus.synced;
      db.saveProgress(adopted);
      return;
    }

    final localPos = localProgress.position_ms;
    final remotePos = remote.position_ms;
    final diff = (localPos - remotePos).abs();
    final localAge = DateTime.now().difference(localProgress.lastPlayed);
    final remoteAge = DateTime.now().difference(
      remote.lastPlayed.isAfter(DateTime.now()) ? DateTime.now() : remote.lastPlayed,
    );

    if (diff <= conflictWindow.inSeconds * 1000) {
      // Close enough — treat as in sync.
      localProgress.syncStatus = SyncStatus.synced;
      db.saveProgress(localProgress);
      return;
    }

    if (localPos == 0) {
      // Never started here → adopt the other device silently.
      _adopt(remote, localProgress);
      return;
    }

    if (remotePos == 0) {
      // Other device has no progress yet → push ours.
      db.setSyncStatus(bookId, SyncStatus.pending);
      return;
    }

    final remoteNewer = remoteAge + conflictWindow < localAge;
    final localNewer = localAge + conflictWindow < remoteAge;

    if (remoteNewer && localProgress.syncStatus != SyncStatus.pending) {
      _adopt(remote, localProgress); // silent pull, per spec
      return;
    }
    if (localNewer) {
      db.setSyncStatus(bookId, SyncStatus.pending);
      return;
    }

    // Genuine divergence: hand the decision to the user.
    localProgress.syncStatus = SyncStatus.conflict;
    db.saveProgress(localProgress);
    final options = <DeviceHistoryEntry>[
      DeviceHistoryEntry(
        deviceName: localProgress.lastPlayedDevice.isEmpty
            ? db.deviceName
            : localProgress.lastPlayedDevice,
        deviceType: localProgress.deviceType,
        position_ms: localProgress.position_ms,
        timestamp: localProgress.lastPlayed,
      ),
      ...remote.deviceHistory.where(
        (e) => e.position_ms != localProgress.position_ms,
      ),
    ];
    if (notifyConflict) {
      _conflicts.add(SyncConflict(
        bookId: bookId,
        title: title,
        author: author,
        local: localProgress,
        remote: remote,
        options: options,
      ));
    }
  }

  void _adopt(BookProgress remote, BookProgress localProgress) {
    final merged = BookProgress(
      bookId: remote.bookId,
      position_ms: remote.position_ms,
      totalDuration_ms: remote.totalDuration_ms > 0
          ? remote.totalDuration_ms
          : localProgress.totalDuration_ms,
      percentComplete: remote.percentComplete,
      playbackSpeed:
          remote.playbackSpeed > 0 ? remote.playbackSpeed : localProgress.playbackSpeed,
      finished: remote.finished,
      lastPlayed: remote.lastPlayed,
      lastPlayedDevice: remote.lastPlayedDevice,
      deviceType: remote.deviceType,
      bookmarks: db.bookmarksFor(remote.bookId),
      syncStatus: SyncStatus.synced,
      deviceHistory: remote.deviceHistory,
    );
    db.saveProgress(merged);
    notifyListeners();
  }

  /// Resolves a conflict with the user's choice.
  Future<void> resolveConflict(SyncConflict conflict, DeviceHistoryEntry choice) async {
    final progress = db.progressFor(conflict.bookId);
    if (progress == null) return;
    progress.position_ms = choice.position_ms;
    progress.totalDuration_ms =
        progress.totalDuration_ms > 0 ? progress.totalDuration_ms : conflict.remote.totalDuration_ms;
    progress.percentComplete = progress.totalDuration_ms > 0
        ? double.parse(
            (choice.position_ms / progress.totalDuration_ms * 100).toStringAsFixed(2))
        : 0;
    progress.lastPlayed = DateTime.now();
    progress.lastPlayedDevice = db.deviceName;
    progress.deviceType = db.deviceType;
    progress.syncStatus = SyncStatus.pending;
    db.saveProgress(progress);
    notifyListeners();
    await syncNow();
  }

  Future<void> _push(drive.DriveApi api, BookProgress progress, Book book) async {
    final payload = progress.toDriveJson(
      title: book.title,
      author: book.author,
      filePath: book.filePath,
    );
    await _writeJson(api, '${book.bookId}_progress.json', payload);
    db.setSyncStatus(book.bookId, SyncStatus.synced);
  }

  /// Pushes one book immediately (used on pause / book switch / app close).
  Future<void> pushBook(Book book) async {
    if (!auth.isSignedIn) return; // local-only mode

    final progress = db.progressFor(book.bookId);
    if (progress == null) return;

    if (!await _online()) {
      _setState(SyncState.offline);
      _log(label: book.title, positionMs: progress.position_ms, ok: false,
          detail: 'offline — retrying in 45 s');
      _scheduleRetry();
      return;
    }

    DriveSession? session;
    try {
      session = await _session();
      if (session == null) {
        _setState(SyncState.signedOut);
        _log(label: book.title, positionMs: progress.position_ms, ok: false,
            detail: 'sign-in expired — sign in again');
        return;
      }
      _setState(SyncState.syncing);
      await _push(session.api, progress, book);
      await _writeManifest(session.api);
      _log(label: book.title, positionMs: progress.position_ms, ok: true,
          detail: 'pushed to Drive');
      _setState(SyncState.idle);
    } catch (error) {
      final state = _classify(error);
      _log(label: book.title, positionMs: progress.position_ms, ok: false,
          detail: _shortReason(state, error));
      _setState(state, error: error.toString());
      if (state == SyncState.offline) _scheduleRetry();
    } finally {
      session?.client.close();
    }
  }

  Future<void> _writeManifest(drive.DriveApi api) async {
    final books = db.allBooks();
    final payload = {
      'lastUpdated': DateTime.now().toUtc().toIso8601String(),
      'totalBooks': books.length,
      'books': books
          .map((b) => {
                'bookId': b.bookId,
                'title': b.title,
                'author': b.author,
                'progressFile': '${b.bookId}_progress.json',
              })
          .toList(),
    };
    await _writeJson(api, manifestName, payload);
  }

  /// Retries every 45 s until the connection is back (spec: retry when online).
  void _scheduleRetry() {
    _retryTimer?.cancel();
    _retryTimer = Timer(const Duration(seconds: 45), () {
      syncNow();
    });
  }

  /// Called when connectivity changes.
  void onConnectivityChanged() {
    if (auth.isSignedIn) syncNow();
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _syncingHoldTimer?.cancel();
    _conflicts.close();
    super.dispose();
  }
}

class DriveSession {
  final drive.DriveApi api;
  final http.Client client;
  DriveSession(this.api, this.client);
}
