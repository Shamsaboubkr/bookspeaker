/// Screen 6 — Settings.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../auth/desktop_oauth_service.dart';
import '../library/book_model.dart';
import '../widgets/sync_indicator.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final theme = Theme.of(context);
    final user = state.auth.user;
    final desktopAccount = state.auth is DesktopGoogleAuthService
        ? state.auth as DesktopGoogleAuthService
        : null;
    final cacheMb = (state.local.cacheBytes / (1024 * 1024));

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 120),
        children: [
          _Header('Account'),
          // Desktop has no Play Services, so sign-in happens in the browser and
          // the account card has to explain that (and offer a client ID field
          // when the build was made without one).
          if (desktopAccount != null)
            _DesktopAccountCard(state: state, account: desktopAccount)
          else if (user == null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Sign in to sync your progress across devices'),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: () => state.signIn(),
                        icon: const Icon(Icons.login),
                        label: const Text('Sign in with Google'),
                      ),
                    ],
                  ),
                ),
              ),
            )
          else
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  ListTile(
                    leading: CircleAvatar(
                      backgroundImage:
                          user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                      child: user.photoUrl == null ? const Icon(Icons.person) : null,
                    ),
                    title: Text(user.email),
                    subtitle: state.sync.lastSync == null
                        ? const Text('Not synced yet')
                        : LiveRelativeTime(
                            state.sync.lastSync!,
                            prefix: 'Last synced: ',
                          ),
                  ),
                  // One short line instead of the raw exception wall. The full
                  // message stays in the internal sync log for diagnosis.
                  if (state.sync.errorSummary != null)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.warning_amber_rounded,
                              size: 15, color: Colors.orange),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              state.sync.errorSummary!,
                              style: const TextStyle(
                                  color: Colors.orange, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const Divider(height: 1),
                  // Quiet one-line proof that the 10 s / 30 s cadence is live.
                  // (The detailed activity log was removed from the UI.)
                  _CadenceTile(state: state),
                  OverflowBar(
                    alignment: MainAxisAlignment.end,
                    children: [
                      TextButton.icon(
                        onPressed: state.forceSync,
                        icon: const Icon(Icons.sync),
                        label: const Text('Force Sync Now'),
                      ),
                      TextButton.icon(
                        onPressed: () => state.signOut(),
                        icon: const Icon(Icons.logout),
                        label: const Text('Sign Out'),
                      ),
                    ],
                  ),
                ],
              ),
            ),

          _Header('Library'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                if (state.folders.isEmpty)
                  const ListTile(
                    leading: Icon(Icons.folder_off_outlined),
                    title: Text('No watched folders'),
                    subtitle: Text('Add a folder of audiobooks to build your library'),
                  ),
                ...state.folders.map((folder) => ListTile(
                      leading: const Icon(Icons.folder_outlined),
                      title: Text(folder,
                          maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${state.books.where((b) => b.filePath.startsWith(folder)).length} books'),
                      trailing: IconButton(
                        icon: const Icon(Icons.close),
                        tooltip: 'Remove',
                        onPressed: () => state.removeFolder(folder),
                      ),
                    )),
                ListTile(
                  leading: const Icon(Icons.add),
                  title: const Text('Add Folder'),
                  onTap: state.addFolderViaPicker,
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.refresh),
                  title: const Text('Re-scan Library'),
                  subtitle: state.scanning
                      ? Text('Scanning ${state.scanDone}/${state.scanTotal}…')
                      : Text(state.lastScanSummary ?? '${state.books.length} books indexed'),
                  onTap: () => state.rescan(),
                ),
              ],
            ),
          ),

          _Header('Playback'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                ListTile(
                  title: const Text('Skip forward duration'),
                  trailing: DropdownButton<int>(
                    value: state.local.skipForwardSeconds,
                    items: const [5, 10, 15, 30, 45, 60]
                        .map((s) => DropdownMenuItem(value: s, child: Text('${s}s')))
                        .toList(),
                    onChanged: (v) => v == null ? null : state.setSkipForward(v),
                  ),
                ),
                ListTile(
                  title: const Text('Skip backward duration'),
                  trailing: DropdownButton<int>(
                    value: state.local.skipBackwardSeconds,
                    items: const [5, 10, 15, 30, 45, 60]
                        .map((s) => DropdownMenuItem(value: s, child: Text('${s}s')))
                        .toList(),
                    onChanged: (v) => v == null ? null : state.setSkipBackward(v),
                  ),
                ),
                SwitchListTile(
                  title: const Text('Skip silence'),
                  subtitle: const Text(
                      'Off by default — turn on to jump over long pauses in the audio'),
                  value: state.local.skipSilence,
                  onChanged: state.setSkipSilence,
                ),
                ListTile(
                  title: const Text('Resume behavior'),
                  subtitle: Text(state.local.resumeBehavior == 'auto'
                      ? 'Auto-resume from newest device'
                      : 'Ask which device'),
                  trailing: DropdownButton<String>(
                    value: state.local.resumeBehavior,
                    items: const [
                      DropdownMenuItem(value: 'ask', child: Text('Ask')),
                      DropdownMenuItem(value: 'auto', child: Text('Auto')),
                    ],
                    onChanged: (v) => v == null ? null : state.setResumeBehavior(v),
                  ),
                ),
              ],
            ),
          ),

          _Header('Appearance'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                ListTile(
                  title: const Text('Theme'),
                  trailing: DropdownButton<ThemeMode>(
                    value: state.theme.mode,
                    items: const [
                      DropdownMenuItem(value: ThemeMode.light, child: Text('Light')),
                      DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark')),
                      DropdownMenuItem(
                          value: ThemeMode.system, child: Text('System Default')),
                    ],
                    onChanged: (v) => v == null ? null : state.setThemeMode(v),
                  ),
                ),
                SwitchListTile(
                  title: const Text('Dynamic color'),
                  subtitle: const Text('Theme follows the current book cover (Recommended)'),
                  value: state.theme.dynamicColor,
                  onChanged: state.setDynamicColor,
                ),
              ],
            ),
          ),

          _Header('Storage'),
          Card(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.sd_storage_outlined),
                  title: const Text('Cache size'),
                  subtitle: Text('${cacheMb.toStringAsFixed(1)} MB of cover art'),
                ),
                ListTile(
                  leading: const Icon(Icons.cleaning_services_outlined),
                  title: const Text('Clear Cache'),
                  onTap: state.clearCache,
                ),
                ListTile(
                  leading: const Icon(Icons.folder_special_outlined),
                  title: const Text('Local data location'),
                  subtitle: Text(state.local.supportDirectory),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              'Bookspeaker 1.0.0\n'
              'Audio stays on your device. Only ~1–3 KB of progress per book '
              'is synced to your own Google Drive.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.title);
  final String title;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 8),
        child: Text(
          title.toUpperCase(),
          style: TextStyle(
            fontSize: 12,
            letterSpacing: 1.2,
            fontWeight: FontWeight.w800,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      );
}


/// One compact line: is the playback save cadence actually running?
class _CadenceTile extends StatelessWidget {
  const _CadenceTile({required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    final player = state.player;
    if (!player.hasBook) return const SizedBox.shrink();
    final local = player.lastLocalSaveAt;
    final drive = player.lastDrivePushAt;
    return ListTile(
      dense: true,
      leading: Icon(
        player.cadenceRunning ? Icons.timer_outlined : Icons.pause_circle_outline,
        size: 19,
      ),
      title: const Text('Saving while playing', style: TextStyle(fontSize: 14)),
      subtitle: Text(
        'Local ${local == null ? '—' : relativeTimePrecise(local)}'
        ' · Drive ${drive == null ? '—' : relativeTimePrecise(drive)}',
        style: const TextStyle(fontSize: 12),
      ),
    );
  }
}

/// Account card shown on Windows (and any desktop build).
class _DesktopAccountCard extends StatefulWidget {
  const _DesktopAccountCard({required this.state, required this.account});

  final AppState state;
  final DesktopGoogleAuthService account;

  @override
  State<_DesktopAccountCard> createState() => _DesktopAccountCardState();
}

class _DesktopAccountCardState extends State<_DesktopAccountCard> {
  late final TextEditingController _idController;
  late final TextEditingController _secretController;
  late bool _showField;

  @override
  void initState() {
    super.initState();
    _idController = TextEditingController(text: widget.account.clientId);
    _secretController = TextEditingController(text: widget.account.clientSecret);
    _showField = !widget.account.isConfigured || widget.account.clientSecret.isEmpty;
  }

  @override
  void dispose() {
    _idController.dispose();
    _secretController.dispose();
    super.dispose();
  }

  void _say(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  /// Saves both values. Also accepts the whole JSON file Google offers for a
  /// Desktop client, so nothing has to be copied field by field.
  void _saveCredentials() {
    var id = _idController.text.trim();
    var secret = _secretController.text.trim();

    final fromJson = DesktopGoogleAuthService.parseClientJson(id);
    if (fromJson.id.isNotEmpty) {
      id = fromJson.id;
      if (fromJson.secret.isNotEmpty) secret = fromJson.secret;
      _idController.text = id;
      _secretController.text = secret;
    }

    final problem = DesktopGoogleAuthService.validateClientId(id);
    if (problem != null) {
      _say(problem);
      return;
    }
    if (secret.isEmpty) {
      _say('Also paste the Client secret — it sits next to the client ID on the '
          'Credentials page, or use the "Download JSON" button and paste the whole file.');
      return;
    }

    widget.account.clientId = id;
    widget.account.clientSecret = secret;
    widget.state.local.db.setSetting('desktop_client_id', id);
    widget.state.local.db.setSetting('desktop_client_secret', secret);
    setState(() => _showField = false);
    _say('Saved — now press Connect Google Drive.');
  }

  @override
  Widget build(BuildContext context) {
    final account = widget.account;
    final state = widget.state;
    final user = account.user;
    final theme = Theme.of(context);
    final hint = account.setupHint;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (user == null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Sign in to sync your progress across devices'),
                  const SizedBox(height: 6),
                  Text(
                    'Your phone and this PC share one hidden Google Drive folder. '
                    'Nothing else in your Drive is ever touched.',
                    style: theme.textTheme.bodySmall,
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: account.busy ? null : () => state.signIn(),
                    icon: account.busy
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.open_in_browser),
                    label: const Text('Connect Google Drive'),
                  ),
                  if (hint != null) ...[
                    const SizedBox(height: 10),
                    Text(hint, style: theme.textTheme.bodySmall),
                  ],
                ],
              ),
            )
          else
            ListTile(
              leading: CircleAvatar(
                backgroundImage:
                    user.photoUrl != null ? NetworkImage(user.photoUrl!) : null,
                child: user.photoUrl == null ? const Icon(Icons.person) : null,
              ),
              title: Text(user.email),
              subtitle: state.sync.lastSync == null
                  ? const Text('Not synced yet')
                  : LiveRelativeTime(
                      state.sync.lastSync!,
                      prefix: 'Last synced: ',
                    ),
            ),

          // A short line instead of a wall of exception text.
          if (account.lastError != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      size: 15, color: Colors.orange),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      account.lastError!,
                      style: const TextStyle(color: Colors.orange, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          if (state.sync.errorSummary != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.cloud_off, size: 15, color: Colors.orange),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      state.sync.errorSummary!,
                      style: const TextStyle(color: Colors.orange, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),

          if (_showField)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Google OAuth client',
                    style: theme.textTheme.labelLarge,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'From a "Desktop app" OAuth client in the same Google Cloud '
                    'project as the Android app — that is what lets both devices '
                    'share one progress folder. Both its ID and its secret are '
                    'needed. Tip: press "Download JSON" on the Credentials page '
                    'and paste the whole file into the first box.',
                    style: theme.textTheme.bodySmall,
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _idController,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      isDense: true,
                      labelText: 'Client ID',
                      hintText: '1234567890-abc.apps.googleusercontent.com',
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _secretController,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      isDense: true,
                      labelText: 'Client secret',
                      hintText: 'GOCSPX-…',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton(
                      onPressed: _saveCredentials,
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ),
            ),

          if (user != null) ...[
            const Divider(height: 1),
            _CadenceTile(state: state),
            OverflowBar(
              alignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: state.forceSync,
                  icon: const Icon(Icons.sync),
                  label: const Text('Force Sync Now'),
                ),
                TextButton.icon(
                  onPressed: () => state.signOut(),
                  icon: const Icon(Icons.logout),
                  label: const Text('Disconnect'),
                ),
              ],
            ),
          ] else if (account.isConfigured)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => setState(() => _showField = !_showField),
                  icon: const Icon(Icons.key),
                  label: const Text('Change client ID / secret'),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
