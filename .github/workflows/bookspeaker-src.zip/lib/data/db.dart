/// Local SQLite storage (`bookspeaker.db`).
///
/// Executes the exact schema from the build specification. All progress data is
/// written here first (offline-first); Google Drive is only ever a mirror.
library;

import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqlite3/sqlite3.dart';

import '../library/book_model.dart';

class BookspeakerDb {
  final Database _db;

  BookspeakerDb._(this._db);

  static const schemaSql = [
    '''
CREATE TABLE IF NOT EXISTS books (
  book_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT,
  file_path TEXT NOT NULL,
  folder_name TEXT NOT NULL,
  format TEXT NOT NULL,
  total_duration_ms INTEGER,
  date_added TEXT NOT NULL,
  is_available INTEGER DEFAULT 1,
  cover_cache_path TEXT,
  cover_checked INTEGER DEFAULT 0
)''',
    '''
CREATE TABLE IF NOT EXISTS progress (
  book_id TEXT PRIMARY KEY,
  position_ms INTEGER DEFAULT 0,
  total_duration_ms INTEGER,
  percent_complete REAL DEFAULT 0,
  playback_speed REAL DEFAULT 1.0,
  finished INTEGER DEFAULT 0,
  last_played TEXT,
  last_device_name TEXT,
  last_device_type TEXT,
  sync_status TEXT DEFAULT 'pending'
)''',
    '''
CREATE TABLE IF NOT EXISTS bookmarks (
  id TEXT PRIMARY KEY,
  book_id TEXT NOT NULL,
  position_ms INTEGER NOT NULL,
  label TEXT,
  created TEXT NOT NULL,
  FOREIGN KEY (book_id) REFERENCES books(book_id)
)''',
    '''
CREATE TABLE IF NOT EXISTS device_history (
  id TEXT PRIMARY KEY,
  book_id TEXT NOT NULL,
  device_name TEXT NOT NULL,
  device_type TEXT NOT NULL,
  position_ms INTEGER NOT NULL,
  timestamp TEXT NOT NULL,
  FOREIGN KEY (book_id) REFERENCES books(book_id)
)''',
    '''
CREATE TABLE IF NOT EXISTS watched_folders (
  id TEXT PRIMARY KEY,
  folder_path TEXT NOT NULL,
  date_added TEXT NOT NULL
)''',
    '''
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
)''',
    'CREATE INDEX IF NOT EXISTS idx_progress_last_played ON progress(last_played)',
    'CREATE INDEX IF NOT EXISTS idx_bookmarks_book ON bookmarks(book_id)',
    'CREATE INDEX IF NOT EXISTS idx_history_book ON device_history(book_id)',
  ];

  static BookspeakerDb open(String filePath) {
    final dir = Directory(p.dirname(filePath));
    if (!dir.existsSync()) dir.createSync(recursive: true);
    final raw = sqlite3.open(filePath);
    final db = BookspeakerDb._(raw);
    db._migrate();
    return db;
  }

  void _migrate() {
    for (final stmt in schemaSql) {
      _db.execute(stmt);
    }
    // Additive migrations for installs created before cover caching existed.
    final cols = _db.select('PRAGMA table_info(books)');
    if (!cols.any((r) => r['name'] == 'cover_cache_path')) {
      _db.execute('ALTER TABLE books ADD COLUMN cover_cache_path TEXT');
    }
    if (!cols.any((r) => r['name'] == 'cover_checked')) {
      _db.execute('ALTER TABLE books ADD COLUMN cover_checked INTEGER DEFAULT 0');
    }
  }

  void close() => _db.dispose();

  // ---------------------------------------------------------------- books

  List<Book> allBooks() => _db
      .select('SELECT * FROM books ORDER BY title COLLATE NOCASE ASC')
      .map((r) => Book.fromRow(r))
      .toList();

  Book? book(String bookId) {
    final rows = _db.select('SELECT * FROM books WHERE book_id = ?', [bookId]);
    return rows.isEmpty ? null : Book.fromRow(rows.first);
  }

  void upsertBook(Book b) {
    _db.execute('''
INSERT INTO books (book_id, title, author, file_path, folder_name, format,
                   total_duration_ms, date_added, is_available, cover_cache_path, cover_checked)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(book_id) DO UPDATE SET
  title = excluded.title,
  author = excluded.author,
  file_path = excluded.file_path,
  folder_name = excluded.folder_name,
  format = excluded.format,
  total_duration_ms = excluded.total_duration_ms,
  is_available = excluded.is_available,
  cover_cache_path = COALESCE(excluded.cover_cache_path, books.cover_cache_path)
''', [
      b.bookId,
      b.title,
      b.author,
      b.filePath,
      b.folderName,
      b.format.label,
      b.totalDuration.inMilliseconds,
      b.dateAdded.toUtc().toIso8601String(),
      b.isAvailable ? 1 : 0,
      b.coverCachePath,
      b.coverChecked ? 1 : 0,
    ]);
  }

  void markUnavailable(String bookId) {
    _db.execute('UPDATE books SET is_available = 0 WHERE book_id = ?', [bookId]);
  }

  void markAvailable(String bookId, String filePath) {
    _db.execute('UPDATE books SET is_available = 1, file_path = ? WHERE book_id = ?',
        [filePath, bookId]);
  }

  void setCoverPath(String bookId, String? path) {
    _db.execute(
        'UPDATE books SET cover_cache_path = ?, cover_checked = 1 WHERE book_id = ?',
        [path, bookId]);
  }

  /// Marks that cover resolution already ran for this book (successful or not),
  /// so launching the app never re-reads every audio file again.
  void markCoverChecked(String bookId) {
    _db.execute('UPDATE books SET cover_checked = 1 WHERE book_id = ?', [bookId]);
  }

  void resetCoverChecks() {
    _db.execute('UPDATE books SET cover_checked = 0');
  }

  /// Removes the book entry but leaves progress data intact (spec: "Remove from
  /// Library" keeps progress on Drive, just removes the local entry).
  void deleteBook(String bookId) {
    _db.execute('DELETE FROM books WHERE book_id = ?', [bookId]);
  }

  // ------------------------------------------------------------- progress

  List<BookProgress> allProgress() {
    final rows = _db.select('SELECT * FROM progress');
    return rows.map((r) {
      final id = r['book_id'] as String;
      return BookProgress.fromRow(r, bookmarksFor(id), historyFor(id));
    }).toList();
  }

  BookProgress? progressFor(String bookId) {
    final rows = _db.select('SELECT * FROM progress WHERE book_id = ?', [bookId]);
    if (rows.isEmpty) return null;
    return BookProgress.fromRow(
        rows.first, bookmarksFor(bookId), historyFor(bookId));
  }

  BookProgress ensureProgress(Book book) {
    final existing = progressFor(book.bookId);
    if (existing != null) return existing;
    final fresh = BookProgress(
      bookId: book.bookId,
      totalDuration_ms: book.totalDuration.inMilliseconds,
      lastPlayed: book.dateAdded,
      lastPlayedDevice: deviceName,
      deviceType: deviceType,
      syncStatus: SyncStatus.pending,
    );
    saveProgress(fresh);
    return fresh;
  }

  void saveProgress(BookProgress pr) {
    _db.execute('''
INSERT INTO progress (book_id, position_ms, total_duration_ms, percent_complete,
                      playback_speed, finished, last_played, last_device_name,
                      last_device_type, sync_status)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(book_id) DO UPDATE SET
  position_ms = excluded.position_ms,
  total_duration_ms = excluded.total_duration_ms,
  percent_complete = excluded.percent_complete,
  playback_speed = excluded.playback_speed,
  finished = excluded.finished,
  last_played = excluded.last_played,
  last_device_name = excluded.last_device_name,
  last_device_type = excluded.last_device_type,
  sync_status = excluded.sync_status
''', [
      pr.bookId,
      pr.position_ms,
      pr.totalDuration_ms,
      pr.percentComplete,
      pr.playbackSpeed,
      pr.finished ? 1 : 0,
      pr.lastPlayed.toUtc().toIso8601String(),
      pr.lastPlayedDevice,
      pr.deviceType,
      pr.syncStatus.label,
    ]);
  }

  List<BookProgress> pendingSync() {
    final rows =
        _db.select("SELECT * FROM progress WHERE sync_status != 'synced'");
    return rows.map((r) {
      final id = r['book_id'] as String;
      return BookProgress.fromRow(r, bookmarksFor(id), historyFor(id));
    }).toList();
  }

  void setSyncStatus(String bookId, SyncStatus status) {
    _db.execute('UPDATE progress SET sync_status = ? WHERE book_id = ?',
        [status.label, bookId]);
  }

  // ------------------------------------------------------------ bookmarks

  List<Bookmark> bookmarksFor(String bookId) => _db
      .select('SELECT * FROM bookmarks WHERE book_id = ? ORDER BY position_ms ASC',
          [bookId])
      .map((r) => Bookmark(
            id: r['id'] as String,
            position_ms: r['position_ms'] as int,
            label: (r['label'] as String?) ?? '',
            created: DateTime.tryParse(r['created'] as String? ?? '')?.toLocal() ??
                DateTime.now(),
          ))
      .toList();

  List<(Bookmark, String, String)> allBookmarksWithBook() => _db
      .select('''
SELECT b.*, bk.title AS book_title FROM bookmarks b
LEFT JOIN books bk ON bk.book_id = b.book_id
ORDER BY b.created DESC
''')
      .map((r) => (
            Bookmark(
              id: r['id'] as String,
              position_ms: r['position_ms'] as int,
              label: (r['label'] as String?) ?? '',
              created:
                  DateTime.tryParse(r['created'] as String? ?? '')?.toLocal() ??
                      DateTime.now(),
            ),
            r['book_id'] as String,
            (r['book_title'] as String?) ?? 'Unknown book',
          ))
      .toList();

  void addBookmark(String bookId, Bookmark bm) {
    _db.execute(
        'INSERT OR REPLACE INTO bookmarks (id, book_id, position_ms, label, created) '
        'VALUES (?, ?, ?, ?, ?)',
        [bm.id, bookId, bm.position_ms, bm.label, bm.created.toUtc().toIso8601String()]);
  }

  void deleteBookmark(String id) => _db.execute('DELETE FROM bookmarks WHERE id = ?', [id]);

  void replaceBookmarks(String bookId, List<Bookmark> bookmarks) {
    _db.execute('DELETE FROM bookmarks WHERE book_id = ?', [bookId]);
    for (final b in bookmarks) {
      addBookmark(bookId, b);
    }
  }

  // ------------------------------------------------------- device history

  List<DeviceHistoryEntry> historyFor(String bookId) => _db
      .select(
          'SELECT * FROM device_history WHERE book_id = ? ORDER BY timestamp DESC LIMIT 10',
          [bookId])
      .map((r) => DeviceHistoryEntry(
            deviceName: r['device_name'] as String,
            deviceType: r['device_type'] as String,
            position_ms: r['position_ms'] as int,
            timestamp:
                DateTime.tryParse(r['timestamp'] as String? ?? '')?.toLocal() ??
                    DateTime.now(),
          ))
      .toList();

  void addHistoryEntry(String bookId, DeviceHistoryEntry entry, String id) {
    _db.execute(
        'INSERT OR REPLACE INTO device_history (id, book_id, device_name, device_type, position_ms, timestamp) '
        'VALUES (?, ?, ?, ?, ?, ?)',
        [
          id,
          bookId,
          entry.deviceName,
          entry.deviceType,
          entry.position_ms,
          entry.timestamp.toUtc().toIso8601String(),
        ]);
  }

  // ------------------------------------------------------- watched folders

  List<(String, String)> watchedFolders() => _db
      .select('SELECT * FROM watched_folders ORDER BY date_added ASC')
      .map((r) => (r['id'] as String, r['folder_path'] as String))
      .toList();

  void addWatchedFolder(String id, String path) {
    _db.execute(
        'INSERT OR REPLACE INTO watched_folders (id, folder_path, date_added) VALUES (?, ?, ?)',
        [id, path, DateTime.now().toUtc().toIso8601String()]);
  }

  void removeWatchedFolder(String id) =>
      _db.execute('DELETE FROM watched_folders WHERE id = ?', [id]);

  // ------------------------------------------------------------- settings

  String? getSetting(String key) {
    final rows = _db.select('SELECT value FROM settings WHERE key = ?', [key]);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  void setSetting(String key, String value) {
    _db.execute(
        'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
        [key, value]);
  }

  int getIntSetting(String key, int fallback) =>
      int.tryParse(getSetting(key) ?? '') ?? fallback;

  double getDoubleSetting(String key, double fallback) =>
      double.tryParse(getSetting(key) ?? '') ?? fallback;

  bool getBoolSetting(String key, bool fallback) {
    final v = getSetting(key);
    if (v == null) return fallback;
    return v == 'true' || v == '1';
  }

  // -------------------------------------------------------------- device

  String get deviceName {
    final stored = getSetting('device_name');
    if (stored != null && stored.isNotEmpty) return stored;
    final host = Platform.localHostname;
    final name = host.isEmpty ? 'Android device' : host;
    setSetting('device_name', name);
    return name;
  }

  set deviceName(String value) => setSetting('device_name', value);

  /// "phone" on Android, "pc" on Windows/desktop.
  String get deviceType => Platform.isAndroid ? 'phone' : 'pc';

  int get cacheBytes {
    final dir = Directory(coverCacheDir);
    if (!dir.existsSync()) return 0;
    return dir
        .listSync(recursive: true)
        .whereType<File>()
        .fold<int>(0, (sum, f) => sum + f.lengthSync());
  }

  String get coverCacheDir => _coverCacheDir ?? '';
  String? _coverCacheDir;
  set coverCacheDir(String value) => _coverCacheDir = value;

  String? _dbPath;
  String get dbPath => _dbPath ?? '';
  set dbPath(String value) => _dbPath = value;
}
