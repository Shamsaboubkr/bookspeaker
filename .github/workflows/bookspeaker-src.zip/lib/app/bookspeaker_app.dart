/// App shell: providers, animated dynamic theme, root navigation.
///
/// Performance structure — important:
///   * [AppState] only changes on library/settings events, never on playback
///     position, so the library never rebuilds while audio plays.
///   * [AudioPlayerService] is its own provider; only the player screen and the
///     mini player listen to it.
///   * The mini player lives in the layout (not in the FAB slot), so nothing
///     overlaps the navigation bar or pops over the content.
library;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../bookmarks/bookmarks_screen.dart';
import '../library/library_screen.dart';
import '../library/onboarding_screen.dart';
import '../platform/platform_bridge.dart';
import '../player/audio_player_service.dart';
import '../player/player_screen.dart';
import '../player/sleep_timer_service.dart';
import '../settings/settings_screen.dart';
import '../progress/drive_sync_service.dart';
import '../widgets/sync_indicator.dart';
import 'theme/dynamic_theme.dart';

class BookspeakerApp extends StatelessWidget {
  const BookspeakerApp({super.key, required this.appState});

  final AppState appState;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AppState>.value(value: appState),
        ChangeNotifierProvider<AudioPlayerService>.value(value: appState.player),
        ChangeNotifierProvider<DriveSyncService>.value(value: appState.sync),
        ChangeNotifierProvider<ThemeController>.value(value: appState.theme),
        ChangeNotifierProvider<SleepTimerService>.value(value: appState.sleepTimer),
      ],
      child: Consumer<ThemeController>(
        builder: (context, theme, _) {
          return MaterialApp(
            title: 'Bookspeaker',
            debugShowCheckedModeBanner: false,
            theme: theme.themeFor(Brightness.light),
            darkTheme: theme.themeFor(Brightness.dark),
            themeMode: theme.mode,
            themeAnimationDuration: const Duration(milliseconds: 400),
            themeAnimationCurve: Curves.easeInOut,
            home: const RootShell(),
          );
        },
      ),
    );
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> with WidgetsBindingObserver {
  int _index = 0;
  bool _bootstrapped = false;
  StreamSubscription<String>? _messageSub;

  @override
  void initState() {
    super.initState();
    // Spec: push on app close, pull on app open.
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final state = context.read<AppState>();
      // Every user-facing result (cover saved, lookup failed, re-linked file…)
      // is shown here — earlier builds stored these messages and never
      // displayed them, so failed actions looked like nothing happened.
      _messageSub = state.messages.listen(_showMessage);
      await state.bootstrap();
      if (!mounted) return;
      setState(() => _bootstrapped = true);
    });
  }

  void _showMessage(String message) {
    if (!mounted) return;
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(seconds: 4),
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final app = context.read<AppState>();
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.hidden:
      case AppLifecycleState.detached:
        // Home, screen off, task swiped away: flush position to SQLite and
        // push to Drive before the process can be reclaimed.
        unawaited(app.player.saveAndPush(awaitPush: true));
      case AppLifecycleState.resumed:
        if (app.sync.isSignedIn) unawaited(app.sync.syncNow());
      case AppLifecycleState.inactive:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _messageSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    if (!_bootstrapped || state.initializing) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (!state.local.onboardingDone) {
      return const OnboardingScreen();
    }

    return PopScope(
      // Back at the root never tears the app down: it backgrounds the task so
      // playback continues and returning is instant (no white launch window,
      // no cold start).
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await state.player.saveAndPush(awaitPush: true);
        final moved = await PlatformBridge.moveTaskToBack();
        if (!moved) {
          state.toast('Bookspeaker keeps playing in the background');
        }
      },
      child: Scaffold(
        body: Column(
          children: [
            const SyncBanners(),
            Expanded(
              child: IndexedStack(
                index: _index,
                children: const [
                  LibraryScreen(),
                  BookmarksScreen(),
                  FavoritesScreen(),
                  SettingsScreen(),
                ],
              ),
            ),
            const MiniPlayerBar(),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: const [
            NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'Home'),
            NavigationDestination(
                icon: Icon(Icons.bookmarks_outlined),
                selectedIcon: Icon(Icons.bookmarks),
                label: 'Bookmarks'),
            NavigationDestination(
                icon: Icon(Icons.favorite_outline),
                selectedIcon: Icon(Icons.favorite),
                label: 'Favorites'),
            NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: 'Settings'),
          ],
        ),
      ),
    );
  }
}

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Favorites')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.favorite_border,
                  size: 64, color: Theme.of(context).disabledColor),
              const SizedBox(height: 16),
              const Text('Favorites are coming soon',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(
                'Bookmarks work today — save a moment while you listen.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Compact now-playing bar shown above the navigation bar. Only this widget
/// (and the player screen) listens to playback updates.
class MiniPlayerBar extends StatelessWidget {
  const MiniPlayerBar({super.key});

  @override
  Widget build(BuildContext context) {
    final player = context.watch<AudioPlayerService>();
    final book = player.currentBook;
    final theme = Theme.of(context);

    return AnimatedSize(
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      alignment: Alignment.bottomCenter,
      child: book == null
          ? const SizedBox(width: double.infinity)
          : Material(
              color: theme.colorScheme.surface,
              child: InkWell(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => PlayerScreen(book: book)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LinearProgressIndicator(
                      value: player.duration.inMilliseconds == 0
                          ? 0
                          : (player.position.inMilliseconds /
                                  player.duration.inMilliseconds)
                              .clamp(0.0, 1.0),
                      minHeight: 2,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(book.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w700, fontSize: 13)),
                                Text(
                                  '${_clock(player.position)} / ${_clock(player.duration)}',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: 'Skip back',
                            icon: const Icon(Icons.replay),
                            onPressed: player.skipBackward,
                          ),
                          IconButton(
                            tooltip: player.playing ? 'Pause' : 'Play',
                            iconSize: 34,
                            color: theme.colorScheme.primary,
                            icon: Icon(player.playing
                                ? Icons.pause_circle_filled
                                : Icons.play_circle_fill),
                            onPressed: player.toggle,
                          ),
                          IconButton(
                            tooltip: 'Skip forward',
                            icon: Transform.flip(
                              flipX: true,
                              child: const Icon(Icons.replay),
                            ),
                            onPressed: player.skipForward,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  static String _clock(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes % 60;
    final s = d.inSeconds % 60;
    final mm = m.toString().padLeft(2, '0');
    final ss = s.toString().padLeft(2, '0');
    return h > 0 ? '$h:$mm:$ss' : '$m:$ss';
  }
}
