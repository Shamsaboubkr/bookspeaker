/// Dark theme entry point (see `dynamic_theme.dart` for the palette mapping).
library;

import 'package:flutter/material.dart';

import '../../covers/palette_service.dart';
import 'dynamic_theme.dart';

ThemeData darkTheme({BookPalette palette = BookPalette.fallback}) =>
    buildDarkTheme(palette, Brightness.dark);
