/// Dynamic colour that follows the current book's cover art.
///
/// Mapping and the contrast guard follow the specification: background
/// gradients come from the muted tones, accents/play button/progress bar from
/// the vibrant tone, and text stays #1A1A1A (light) / #F5F5F5 (dark).
library;

import 'package:flutter/material.dart';

import '../../covers/palette_service.dart';

class ThemeController extends ChangeNotifier {
  BookPalette _palette = BookPalette.fallback;
  ThemeMode _mode = ThemeMode.system;
  bool _dynamicColor = true;

  BookPalette get palette => _palette;
  ThemeMode get mode => _mode;
  bool get dynamicColor => _dynamicColor;

  void setMode(ThemeMode mode) {
    if (_mode == mode) return;
    _mode = mode;
    notifyListeners();
  }

  void setDynamicColor(bool enabled) {
    if (_dynamicColor == enabled) return;
    _dynamicColor = enabled;
    notifyListeners();
  }

  /// Swaps the palette for a new book. The colour change is animated by
  /// [AnimatedTheme] in the app shell (400 ms / easeInOut).
  Future<void> applyCover(String? coverPath) async {
    if (!_dynamicColor) return;
    final next = await PaletteService.paletteFor(coverPath);
    _palette = next;
    notifyListeners();
  }

  void reset() {
    _palette = BookPalette.fallback;
    notifyListeners();
  }

  /// Theme data for the current palette, ready to hand to `AnimatedTheme`.
  ThemeData themeFor(Brightness brightness) {
    final palette = _dynamicColor ? _palette : BookPalette.fallback;
    return brightness == Brightness.dark
        ? buildDarkTheme(palette, brightness)
        : buildLightTheme(palette, brightness);
  }
}

ThemeData buildLightTheme(BookPalette palette, Brightness brightness) {
  final accent = _readableAccent(palette.vibrant, const Color(0xFFFFFFFF), 3.0);
  final scheme = ColorScheme.fromSeed(
    seedColor: palette.dominant,
    brightness: brightness,
    primary: accent,
    secondary: palette.gold,
    surface: Color.alphaBlend(palette.lightMuted.withOpacity(0.55), Colors.white),
  );
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor:
        Color.alphaBlend(palette.lightMuted.withOpacity(0.5), Colors.white),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      foregroundColor: const Color(0xFF1A1A1A),
      titleTextStyle: const TextStyle(
        color: Color(0xFF1A1A1A),
        fontSize: 22,
        fontWeight: FontWeight.w700,
      ),
      iconTheme: const IconThemeData(color: Color(0xFF1A1A1A)),
    ),
    cardTheme: CardTheme(
      color: Colors.white.withOpacity(0.86),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white.withOpacity(0.92),
      indicatorColor: accent.withOpacity(0.18),
      elevation: 0,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: Colors.white,
        minimumSize: const Size(0, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    listTileTheme: const ListTileThemeData(iconColor: Color(0xFF1A1A1A)),
    textTheme: const TextTheme().apply(
      bodyColor: const Color(0xFF1A1A1A),
      displayColor: const Color(0xFF1A1A1A),
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: accent,
      thumbColor: accent,
      inactiveTrackColor: accent.withOpacity(0.22),
    ),
  );
}

ThemeData buildDarkTheme(BookPalette palette, Brightness brightness) {
  final accent = _readableAccent(palette.vibrant, const Color(0xFF121018), 3.0);
  final surface = Color.alphaBlend(palette.darkMuted.withOpacity(0.55), const Color(0xFF0E0C14));
  final scheme = ColorScheme.fromSeed(
    seedColor: palette.dominant,
    brightness: brightness,
    primary: accent,
    secondary: palette.gold,
    surface: surface,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: surface,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: false,
      foregroundColor: const Color(0xFFF5F5F5),
      titleTextStyle: const TextStyle(
        color: Color(0xFFF5F5F5),
        fontSize: 22,
        fontWeight: FontWeight.w700,
      ),
      iconTheme: const IconThemeData(color: Color(0xFFF5F5F5)),
    ),
    cardTheme: CardTheme(
      color: Colors.white.withOpacity(0.06),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      clipBehavior: Clip.antiAlias,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: surface,
      indicatorColor: accent.withOpacity(0.28),
      elevation: 0,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: Colors.black,
        minimumSize: const Size(0, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    textTheme: const TextTheme().apply(
      bodyColor: const Color(0xFFF5F5F5),
      displayColor: const Color(0xFFF5F5F5),
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: accent,
      thumbColor: accent,
      inactiveTrackColor: accent.withOpacity(0.3),
    ),
  );
}

/// Bumps a colour's lightness until it reads clearly on [background]
/// (contrast ≥ 3.0 for large UI elements); falls back to the brand purple.
Color _readableAccent(Color accent, Color background, double minRatio) {
  var candidate = accent;
  for (var i = 0; i < 12; i++) {
    final ratio = _contrast(candidate, background);
    if (ratio >= minRatio) return candidate;
    candidate = Color.lerp(
      candidate,
      background.computeLuminance() > 0.5 ? Colors.black : Colors.white,
      0.12,
    )!;
  }
  return BookPalette.fallback.vibrant;
}

double _contrast(Color a, Color b) {
  final la = a.computeLuminance();
  final lb = b.computeLuminance();
  final hi = la > lb ? la : lb;
  final lo = la > lb ? lb : la;
  return (hi + 0.05) / (lo + 0.05);
}
