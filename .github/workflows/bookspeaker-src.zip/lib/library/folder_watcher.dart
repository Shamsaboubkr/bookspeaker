/// Watches the library folders for real-time changes.
///
/// On app start the folders are scanned (see [BookScanner]); afterwards a
/// `DirectoryWatcher` keeps the library in sync: new files are fingerprinted
/// and added, removed files are greyed out with progress preserved.
library;

import 'dart:async';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:watcher/watcher.dart';

import '../data/db.dart';
import 'book_model.dart';
import 'book_scanner.dart';
import 'fingerprint_service.dart';

class FolderWatcherService {
  FolderWatcherService(this.db, this.scanner);

  final BookspeakerDb db;
  final BookScanner scanner;

  final Map<String, DirectoryWatcher> _watchers = {};
  final Map<String, StreamSubscription<WatchEvent>> _subs = {};
  final _events = StreamController<FolderChange>.broadcast();
  Timer? _debounce;

  Stream<FolderChange> get changes => _events.stream;

  List<String> get watchedPaths => db.watchedFolders().map((e) => e.$2).toList();

  Future<void> addFolder(String path) async {
    final normalized = p.normalize(path);
    if (db.watchedFolders().any((f) => p.equals(f.$2, normalized))) return;
    db.addWatchedFolder(normalized.hashCode.toRadixString(16), normalized);
    await _watch(normalized);
  }

  void removeFolder(String path) {
    final entry = db.watchedFolders().firstWhere(
      (f) => p.equals(f.$2, path),
      orElse: () => ('', ''),
    );
    if (entry.$1.isNotEmpty) db.removeWatchedFolder(entry.$1);
    _subs.remove(path)?.cancel();
    _watchers.remove(path);
  }

  /// Starts filesystem watchers for every stored folder.
  Future<void> startAll() async {
    for (final folder in watchedPaths) {
      await _watch(folder);
    }
  }

  Future<void> _watch(String path) async {
    if (_subs.containsKey(path)) return;
    if (!Directory(path).existsSync()) return;
    try {
      final watcher = DirectoryWatcher(path);
      _watchers[path] = watcher;
      _subs[path] = watcher.events.listen(_onEvent);
    } catch (_) {
      // Some Android storage providers cannot be watched; periodic rescan
      // still keeps the library correct.
    }
  }

  void _onEvent(WatchEvent event) {
    final ext = p.extension(event.path).toLowerCase().replaceFirst('.', '');
    if (!supportedExtensions.contains(ext)) return;

    // Debounce bursts (copying a folder fires many events).
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 700), () async {
      final file = File(event.path);
      if (event.type == ChangeType.REMOVE || !file.existsSync()) {
        _handleRemoval(event.path);
        return;
      }
      if (await file.length() == 0) return;
      try {
        final result = await scanner.ingestFile(file);
        if (result != IngestResult.unchanged) {
          _events.add(FolderChange(file.path, result));
        }
      } catch (_) {}
    });
  }

  void _handleRemoval(String path) {
    final book = db.allBooks().where((b) => b.filePath == path).toList();
    for (final b in book) {
      db.markUnavailable(b.bookId);
      _events.add(FolderChange(path, IngestResult.unchanged));
    }
  }

  /// Re-checks availability for every known book without a full rescan.
  void refreshAvailability() {
    for (final book in db.allBooks()) {
      final exists = File(book.filePath).existsSync();
      if (!exists && book.isAvailable) {
        db.markUnavailable(book.bookId);
      } else if (exists && !book.isAvailable) {
        db.markAvailable(book.bookId, book.filePath);
      }
    }
  }

  /// Locates a moved/renamed book inside the watched folders by fingerprint.
  Future<Book?> relocateBook(Book missing) async {
    for (final folder in watchedPaths) {
      for (final file in await BookScanner.findAudioFilesAsync(folder)) {
        if (file.path == missing.filePath) continue;
        final known = db.allBooks().where((b) => b.filePath == file.path).toList();
        if (known.isNotEmpty) continue;
        try {
          final id = await FingerprintService.fingerprintOffThread(file.path);
          if (id == missing.bookId) {
            db.markAvailable(missing.bookId, file.path);
            return db.book(missing.bookId);
          }
        } catch (_) {}
      }
    }
    return null;
  }

  Future<void> dispose() async {
    _debounce?.cancel();
    for (final sub in _subs.values) {
      await sub.cancel();
    }
    _subs.clear();
    _watchers.clear();
    await _events.close();
  }
}

class FolderChange {
  final String path;
  final IngestResult result;
  FolderChange(this.path, this.result);
}
