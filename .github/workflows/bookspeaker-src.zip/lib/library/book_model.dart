// ignore_for_file: non_constant_identifier_names

/// Bookspeaker data models.
///
/// Mirrors the "Data Models" section of the build specification exactly.
library;

enum AudioFormat { mp3, m4a, opus }

extension AudioFormatX on AudioFormat {
  String get label => switch (this) {
        AudioFormat.mp3 => 'mp3',
        AudioFormat.m4a => 'm4a',
        AudioFormat.opus => 'opus',
      };

  static AudioFormat? fromExtension(String path) {
    final lower = path.toLowerCase();
    if (lower.endsWith('.mp3')) return AudioFormat.mp3;
    if (lower.endsWith('.m4a') ||
        lower.endsWith('.m4b') ||
        lower.endsWith('.mp4') ||
        lower.endsWith('.aac')) {
      return AudioFormat.m4a;
    }
    if (lower.endsWith('.opus') || lower.endsWith('.ogg')) {
      return AudioFormat.opus;
    }
    return null;
  }
}

/// A single audiobook, identified by the SHA-256 audio fingerprint
/// ([bookId]) so that renames / moves keep the same identity.
class Book {
  final String bookId; // SHA-256 fingerprint (16 hex chars)
  final String title; // from metadata or filename
  final String author; // from metadata or empty
  final String filePath; // local path on this device
  final String folderName; // parent folder name
  final AudioFormat format; // mp3 / m4a / opus
  final Duration totalDuration;
  final DateTime dateAdded;
  bool isAvailable; // false if file not found
  String? coverCachePath; // locally cached/embedded cover, if any
  bool coverChecked; // true once cover resolution was attempted for this file

  Book({
    required this.bookId,
    required this.title,
    required this.author,
    required this.filePath,
    required this.folderName,
    required this.format,
    required this.totalDuration,
    required this.dateAdded,
    this.isAvailable = true,
    this.coverCachePath,
    this.coverChecked = false,
  });

  Map<String, Object?> toRow() => {
        'book_id': bookId,
        'title': title,
        'author': author,
        'file_path': filePath,
        'folder_name': folderName,
        'format': format.label,
        'total_duration_ms': totalDuration.inMilliseconds,
        'date_added': dateAdded.toUtc().toIso8601String(),
        'is_available': isAvailable ? 1 : 0,
        'cover_cache_path': coverCachePath,
        'cover_checked': coverChecked ? 1 : 0,
      };

  static Book fromRow(Map<String, Object?> r) => Book(
        bookId: r['book_id'] as String,
        title: r['title'] as String,
        author: (r['author'] as String?) ?? '',
        filePath: r['file_path'] as String,
        folderName: (r['folder_name'] as String?) ?? '',
        format: AudioFormat.values.firstWhere(
          (f) => f.label == (r['format'] as String? ?? 'mp3'),
          orElse: () => AudioFormat.mp3,
        ),
        totalDuration: Duration(milliseconds: (r['total_duration_ms'] as int?) ?? 0),
        dateAdded: DateTime.tryParse(r['date_added'] as String? ?? '')?.toLocal() ??
            DateTime.now(),
        isAvailable: ((r['is_available'] as int?) ?? 1) == 1,
        coverCachePath: r['cover_cache_path'] as String?,
        coverChecked: ((r['cover_checked'] as int?) ?? 0) == 1,
      );

  Book copyWith({
    String? title,
    String? author,
    String? filePath,
    String? folderName,
    Duration? totalDuration,
    bool? isAvailable,
    String? coverCachePath,
    bool? coverChecked,
  }) =>
      Book(
        bookId: bookId,
        title: title ?? this.title,
        author: author ?? this.author,
        filePath: filePath ?? this.filePath,
        folderName: folderName ?? this.folderName,
        format: format,
        totalDuration: totalDuration ?? this.totalDuration,
        dateAdded: dateAdded,
        isAvailable: isAvailable ?? this.isAvailable,
        coverCachePath: coverCachePath ?? this.coverCachePath,
        coverChecked: coverChecked ?? this.coverChecked,
      );
}

class Bookmark {
  final String id;
  final int position_ms;
  final String label;
  final DateTime created;

  Bookmark({
    required this.id,
    required this.position_ms,
    required this.label,
    required this.created,
  });

  Map<String, Object?> toJson() => {
        'id': id,
        'position_ms': position_ms,
        'label': label,
        'created': created.toUtc().toIso8601String(),
      };

  static Bookmark fromJson(Map<String, dynamic> j) => Bookmark(
        id: j['id'] as String,
        position_ms: (j['position_ms'] as num).toInt(),
        label: (j['label'] as String?) ?? '',
        created:
            DateTime.tryParse(j['created'] as String? ?? '')?.toLocal() ?? DateTime.now(),
      );
}

enum SyncStatus { synced, pending, conflict }

extension SyncStatusX on SyncStatus {
  String get label => switch (this) {
        SyncStatus.synced => 'synced',
        SyncStatus.pending => 'pending',
        SyncStatus.conflict => 'conflict',
      };

  static SyncStatus fromLabel(String? s) => SyncStatus.values.firstWhere(
        (v) => v.label == s,
        orElse: () => SyncStatus.pending,
      );
}

class DeviceHistoryEntry {
  final String deviceName;
  final String deviceType; // "phone" or "pc"
  final int position_ms;
  final DateTime timestamp;

  DeviceHistoryEntry({
    required this.deviceName,
    required this.deviceType,
    required this.position_ms,
    required this.timestamp,
  });

  Map<String, Object?> toJson() => {
        'deviceName': deviceName,
        'deviceType': deviceType,
        'position_ms': position_ms,
        'timestamp': timestamp.toUtc().toIso8601String(),
      };

  static DeviceHistoryEntry fromJson(Map<String, dynamic> j) => DeviceHistoryEntry(
        deviceName: (j['deviceName'] as String?) ?? 'Unknown device',
        deviceType: (j['deviceType'] as String?) ?? 'phone',
        position_ms: ((j['position_ms'] as num?) ?? 0).toInt(),
        timestamp: DateTime.tryParse(j['timestamp'] as String? ?? '')?.toLocal() ??
            DateTime.now(),
      );
}

class BookProgress {
  final String bookId;
  int position_ms;
  int totalDuration_ms;
  double percentComplete;
  double playbackSpeed; // per book
  bool finished;
  DateTime lastPlayed;
  String lastPlayedDevice; // "Pixel 7" or "Desktop PC"
  String deviceType; // "phone" or "pc"
  List<Bookmark> bookmarks;
  SyncStatus syncStatus; // synced / pending / conflict
  List<DeviceHistoryEntry> deviceHistory;

  BookProgress({
    required this.bookId,
    this.position_ms = 0,
    this.totalDuration_ms = 0,
    this.percentComplete = 0,
    this.playbackSpeed = 1.0,
    this.finished = false,
    DateTime? lastPlayed,
    this.lastPlayedDevice = '',
    this.deviceType = 'phone',
    List<Bookmark>? bookmarks,
    this.syncStatus = SyncStatus.pending,
    List<DeviceHistoryEntry>? deviceHistory,
  })  : lastPlayed = lastPlayed ?? DateTime.now(),
        bookmarks = bookmarks ?? <Bookmark>[],
        deviceHistory = deviceHistory ?? <DeviceHistoryEntry>[];

  Duration get position => Duration(milliseconds: position_ms);
  Duration get totalDuration => Duration(milliseconds: totalDuration_ms);

  /// Remaining wall-clock time at the current speed.
  Duration get remaining {
    final left = (totalDuration_ms - position_ms).clamp(0, 1 << 62);
    final speed = playbackSpeed <= 0 ? 1.0 : playbackSpeed;
    return Duration(milliseconds: (left / speed).round());
  }

  Map<String, Object?> toRow() => {
        'book_id': bookId,
        'position_ms': position_ms,
        'total_duration_ms': totalDuration_ms,
        'percent_complete': percentComplete,
        'playback_speed': playbackSpeed,
        'finished': finished ? 1 : 0,
        'last_played': lastPlayed.toUtc().toIso8601String(),
        'last_device_name': lastPlayedDevice,
        'last_device_type': deviceType,
        'sync_status': syncStatus.label,
      };

  static BookProgress fromRow(
    Map<String, Object?> r,
    List<Bookmark> bookmarks,
    List<DeviceHistoryEntry> history,
  ) =>
      BookProgress(
        bookId: r['book_id'] as String,
        position_ms: (r['position_ms'] as int?) ?? 0,
        totalDuration_ms: (r['total_duration_ms'] as int?) ?? 0,
        percentComplete: ((r['percent_complete'] as num?) ?? 0).toDouble(),
        playbackSpeed: ((r['playback_speed'] as num?) ?? 1.0).toDouble(),
        finished: ((r['finished'] as int?) ?? 0) == 1,
        lastPlayed: DateTime.tryParse(r['last_played'] as String? ?? '')?.toLocal(),
        lastPlayedDevice: (r['last_device_name'] as String?) ?? '',
        deviceType: (r['last_device_type'] as String?) ?? 'phone',
        bookmarks: bookmarks,
        syncStatus: SyncStatusX.fromLabel(r['sync_status'] as String?),
        deviceHistory: history,
      );

  /// Drive payload — identical shape to `<bookId>_progress.json` in the spec.
  Map<String, Object?> toDriveJson({String? title, String? author, String? filePath}) {
    final paths = <String, String>{};
    if (filePath != null && filePath.isNotEmpty) paths[deviceType] = filePath;
    return {
      'bookId': bookId,
      if (title != null) 'title': title,
      if (author != null) 'author': author,
      'totalDuration_ms': totalDuration_ms,
      'playbackSpeed': playbackSpeed,
      'finished': finished,
      'percentComplete': percentComplete,
      'position_ms': position_ms,
      'deviceHistory': deviceHistory.map((e) => e.toJson()).toList(),
      'bookmarks': bookmarks.map((b) => b.toJson()).toList(),
      'filePaths': paths,
      'lastPlayed': lastPlayed.toUtc().toIso8601String(),
      'lastDevice': {
        'deviceName': lastPlayedDevice,
        'deviceType': deviceType,
      },
    };
  }

  static BookProgress fromDriveJson(Map<String, dynamic> j, {String? fallbackBookId}) {
    final history = <DeviceHistoryEntry>[];
    final rawHistory = j['deviceHistory'];
    if (rawHistory is List) {
      for (final h in rawHistory) {
        if (h is Map) history.add(DeviceHistoryEntry.fromJson(h.cast<String, dynamic>()));
      }
    }
    final bookmarks = <Bookmark>[];
    final rawBookmarks = j['bookmarks'];
    if (rawBookmarks is List) {
      for (final b in rawBookmarks) {
        if (b is Map) bookmarks.add(Bookmark.fromJson(b.cast<String, dynamic>()));
      }
    }
    // Newest device entry wins for the "last played on" fields.
    history.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    final lastDevice = (j['lastDevice'] as Map?)?.cast<String, dynamic>();

    return BookProgress(
      bookId: (j['bookId'] as String?) ?? (fallbackBookId ?? ''),
      position_ms: ((j['position_ms'] as num?) ?? 0).toInt(),
      totalDuration_ms: ((j['totalDuration_ms'] as num?) ?? 0).toInt(),
      percentComplete: ((j['percentComplete'] as num?) ?? 0).toDouble(),
      playbackSpeed: ((j['playbackSpeed'] as num?) ?? 1.0).toDouble(),
      finished: (j['finished'] as bool?) ?? false,
      lastPlayed: DateTime.tryParse(
              lastDevice?['timestamp'] as String? ?? j['lastPlayed'] as String? ?? '')
          ?.toLocal(),
      lastPlayedDevice: (lastDevice?['deviceName'] as String?) ??
          (history.isNotEmpty ? history.first.deviceName : ''),
      deviceType:
          (lastDevice?['deviceType'] as String?) ?? (history.isNotEmpty ? history.first.deviceType : 'phone'),
      bookmarks: bookmarks,
      syncStatus: SyncStatus.synced,
      deviceHistory: history,
    );
  }
}

String formatDuration(Duration d, {bool hours = true}) {
  final total = d.inSeconds;
  final h = total ~/ 3600;
  final m = (total % 3600) ~/ 60;
  final s = total % 60;
  final mm = m.toString().padLeft(hours ? 2 : 1, '0');
  final ss = s.toString().padLeft(2, '0');
  return hours ? '$h:$mm:$ss' : '$m:$ss';
}

/// Like [relativeTime] but with second-level precision under 90 s.
String relativeTimePrecise(DateTime then) {
  var diff = DateTime.now().difference(then);
  if (diff.isNegative) diff = Duration.zero;
  if (diff.inSeconds < 10) return 'just now';
  if (diff.inSeconds < 90) return '${diff.inSeconds}s ago';
  return relativeTime(then);
}

String relativeTime(DateTime then) {
  final diff = DateTime.now().difference(then);
  if (diff.inSeconds < 60) return 'just now';
  if (diff.inMinutes < 60) {
    final m = diff.inMinutes;
    return '$m min${m == 1 ? '' : 's'} ago';
  }
  if (diff.inHours < 24) {
    final h = diff.inHours;
    return '$h hour${h == 1 ? '' : 's'} ago';
  }
  final d = diff.inDays;
  return '$d day${d == 1 ? '' : 's'} ago';
}
