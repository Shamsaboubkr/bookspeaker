/// Validation helpers for downloaded/picked cover images.
///
/// Needed because cover APIs answer with HTTP 200 and a tiny blank placeholder
/// when they have nothing (OpenLibrary returns a 43-byte GIF) — without this
/// check the app would happily cache an empty square as the book's artwork.
library;

class CoverImage {
  /// Minimum size for something to be considered real artwork.
  static const minBytes = 3000;

  static bool looksLikeImage(List<int> b) {
    if (b.length < 12) return false;
    final jpeg = b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF;
    final png = b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47;
    final gif = b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46;
    final webp = b[0] == 0x52 &&
        b[1] == 0x49 &&
        b[2] == 0x46 &&
        b[3] == 0x46 &&
        b[8] == 0x57 &&
        b[9] == 0x45 &&
        b[10] == 0x42 &&
        b[11] == 0x50;
    final bmp = b[0] == 0x42 && b[1] == 0x4D;
    return jpeg || png || gif || webp || bmp;
  }

  static bool isPng(List<int> b) =>
      b.length > 8 && b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47;

  /// True when the payload is a usable cover (real image, not a placeholder).
  static bool isValidCover(List<int> b) => b.length >= minBytes && looksLikeImage(b);
}
