/// Cover art source #1 — artwork embedded in the audio file's tags.
library;

import 'dart:io';
import 'dart:typed_data';

import 'package:audio_metadata_reader/audio_metadata_reader.dart';

class EmbeddedCoverSource {
  /// Returns the raw bytes + mime type of the front cover inside [filePath].
  /// Synchronous — call it through `CoverArtService.extractEmbedded` so it runs
  /// on a worker isolate instead of the UI thread.
  static ({Uint8List bytes, String mime})? extract(String filePath) {
    try {
      final meta = readMetadata(File(filePath), getImage: true);
      if (meta.pictures.isEmpty) return null;
      // Prefer a front cover, otherwise take whatever picture is present.
      final picture = meta.pictures.firstWhere(
        (p) => p.pictureType == PictureType.coverFront,
        orElse: () => meta.pictures.first,
      );
      if (picture.bytes.isEmpty) return null;
      return (bytes: picture.bytes, mime: picture.mimetype);
    } catch (_) {
      return null;
    }
  }
}

/// Isolate entry point used by `CoverArtService` (takes only a path string, so
/// nothing but plain data crosses the isolate boundary).
class EmbeddedCoverExtractor {
  static ({Uint8List bytes, String mime})? extract(String path) =>
      EmbeddedCoverSource.extract(path);
}
