/// Online cover sources: OpenLibrary (primary, per spec), Google Books
/// (backup, per spec) and the iTunes Search API (extra fallback that is
/// audiobook-specific and needs no key).
///
/// Every source returns a [CoverSearchOutcome] that carries a human-readable
/// note when it finds nothing, so the UI can say *why* instead of failing
/// silently (Google Books regularly answers HTTP 429 for anonymous callers).
library;

import 'dart:convert';

import 'package:http/http.dart' as http;

import 'image_validation.dart';

class CoverCandidate {
  final String source; // "OpenLibrary" | "Google Books" | "iTunes" | "Your device"
  final String imageUrl;
  final List<int>? bytes;
  final String? infoUrl;

  const CoverCandidate({
    required this.source,
    required this.imageUrl,
    this.bytes,
    this.infoUrl,
  });
}

class CoverSearchOutcome {
  final CoverCandidate? candidate;
  final String? note;

  const CoverSearchOutcome(this.candidate, [this.note]);

  /// "nothing found, nothing to say".
  const CoverSearchOutcome.none()
      : candidate = null,
        note = null;
}

const _userAgent = 'Bookspeaker/1.0 (local audiobook player)';
const _timeout = Duration(seconds: 20);

/// Downloads [url] and returns the bytes only if they are a real image.
Future<List<int>?> downloadCover(http.Client client, String url) async {
  try {
    final res = await client
        .get(Uri.parse(url), headers: {'User-Agent': _userAgent})
        .timeout(_timeout);
    if (res.statusCode != 200) return null;
    final bytes = res.bodyBytes;
    if (!CoverImage.isValidCover(bytes)) return null;
    return bytes;
  } catch (_) {
    return null;
  }
}

/// Loose title match used to pick the right audiobook out of a search result
/// ("The Great Gatsby (Unabridged)" still matches "The Great Gatsby").
bool titleMatches(String wanted, String candidate) {
  String norm(String s) => s
      .toLowerCase()
      .replaceAll(RegExp(r'\(.*?\)'), '')
      .replaceAll(RegExp(r'[^a-z0-9 ]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  final w = norm(wanted);
  final c = norm(candidate);
  if (w.isEmpty || c.isEmpty) return false;
  if (c.contains(w) || w.contains(c)) return true;
  // Fall back to "most of the words are there".
  final words = w.split(' ').where((x) => x.length > 3).toList();
  if (words.isEmpty) return false;
  final hits = words.where(c.contains).length;
  return hits >= (words.length / 2).ceil();
}

class OpenLibrarySource {
  /// Searches OpenLibrary. Tries title+author first, then title alone — adding
  /// the author frequently drops the only useful hit.
  static Future<CoverSearchOutcome> search(
    http.Client client,
    String title,
    String author,
  ) async {
    if (title.trim().isEmpty) return const CoverSearchOutcome(null, 'No title to search for');
    try {
      final attempts = <Map<String, String>>[
        {
          'title': title,
          if (author.trim().isNotEmpty) 'author': author,
          'limit': '3',
        },
        {'title': title, 'limit': '3'},
      ];

      for (final params in attempts) {
        final uri = Uri.https('openlibrary.org', '/search.json', params);
        final res = await client
            .get(uri, headers: {'User-Agent': _userAgent})
            .timeout(_timeout);
        if (res.statusCode != 200) continue;
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        final docs = (data['docs'] as List?) ?? const [];
        for (final raw in docs) {
          if (raw is! Map) continue;
          final doc = raw.cast<String, dynamic>();
          final coverId = doc['cover_i'];
          if (coverId == null) continue;
          // default=false makes a missing cover a 404 instead of a blank GIF.
          final url =
              'https://covers.openlibrary.org/b/id/$coverId-L.jpg?default=false';
          final bytes = await downloadCover(client, url);
          if (bytes == null) continue;
          return CoverSearchOutcome(CoverCandidate(
            source: 'OpenLibrary',
            imageUrl: url,
            bytes: bytes,
            infoUrl: 'https://openlibrary.org${doc['key'] ?? ''}',
          ));
        }
      }
      return const CoverSearchOutcome(null, 'OpenLibrary has no cover for this book');
    } catch (e) {
      return CoverSearchOutcome(null, 'OpenLibrary could not be reached');
    }
  }
}

class GoogleBooksSource {
  static Future<CoverSearchOutcome> search(
    http.Client client,
    String title,
    String author,
  ) async {
    if (title.trim().isEmpty) return const CoverSearchOutcome.none();
    try {
      final q = [
        'intitle:"$title"',
        if (author.trim().isNotEmpty) 'inauthor:"$author"',
      ].join('+');
      final uri = Uri.https('www.googleapis.com', '/books/v1/volumes', {
        'q': q,
        'maxResults': '3',
      });
      final res = await client.get(uri).timeout(_timeout);

      if (res.statusCode == 429) {
        return const CoverSearchOutcome(
            null, 'Google Books is rate-limiting right now');
      }
      if (res.statusCode != 200) {
        return CoverSearchOutcome(
            null, 'Google Books returned HTTP ${res.statusCode}');
      }

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final items = (data['items'] as List?) ?? const [];
      if (items.isEmpty) {
        return const CoverSearchOutcome(null, 'Google Books has no match');
      }

      for (final raw in items) {
        if (raw is! Map) continue;
        final volume = (raw.cast<String, dynamic>()['volumeInfo'] as Map?)
                ?.cast<String, dynamic>() ??
            const <String, dynamic>{};
        final links = (volume['imageLinks'] as Map?)?.cast<String, dynamic>();
        var thumb = links?['thumbnail'] as String? ?? links?['smallThumbnail'] as String?;
        if (thumb == null) continue;
        // Ask for a bigger render than the default ~128px thumb.
        thumb = thumb
            .replaceFirst('http://', 'https://')
            .replaceAll(RegExp(r'&zoom=\d'), '&zoom=2')
            .replaceAll('&edge=curl', '');
        final bytes = await downloadCover(client, thumb);
        if (bytes == null) continue;
        return CoverSearchOutcome(CoverCandidate(
          source: 'Google Books',
          imageUrl: thumb,
          bytes: bytes,
          infoUrl: volume['infoLink'] as String?,
        ));
      }
      return const CoverSearchOutcome(null, 'Google Books has no cover for this book');
    } catch (_) {
      return const CoverSearchOutcome(null, 'Google Books could not be reached');
    }
  }
}

class ItunesSource {
  static const _endpoint = 'https://itunes.apple.com/search';

  /// Audiobook covers from Apple's catalogue — a strong fallback because it
  /// indexes audiobook editions specifically, and needs no API key.
  static Future<CoverSearchOutcome> search(
    http.Client client,
    String title,
    String author,
  ) async {
    if (title.trim().isEmpty) return const CoverSearchOutcome.none();
    try {
      final uri = Uri.parse(_endpoint).replace(queryParameters: {
        'term': [title, if (author.trim().isNotEmpty) author].join(' '),
        'entity': 'audiobook',
        'limit': '5',
      });
      final res = await client
          .get(uri, headers: {'User-Agent': _userAgent})
          .timeout(_timeout);
      if (res.statusCode != 200) {
        return CoverSearchOutcome(null, 'iTunes returned HTTP ${res.statusCode}');
      }

      final data = jsonDecode(res.body) as Map<String, dynamic>;
      final results = (data['results'] as List?) ?? const [];
      if (results.isEmpty) {
        return const CoverSearchOutcome(null, 'iTunes has no matching audiobook');
      }

      final ranked = results
          .whereType<Map>()
          .map((r) => r.cast<String, dynamic>())
          .where((r) => (r['artworkUrl100'] as String?) != null)
          .toList()
        ..sort((a, b) {
          final am = titleMatches(
              title, (a['collectionName'] as String?) ?? (a['trackName'] as String?) ?? '');
          final bm = titleMatches(
              title, (b['collectionName'] as String?) ?? (b['trackName'] as String?) ?? '');
          return (bm ? 1 : 0).compareTo(am ? 1 : 0);
        });

      for (final result in ranked) {
        final art = result['artworkUrl100'] as String;
        // Apple serves the same artwork at any size by editing the URL.
        final big = art.replaceAll('100x100bb', '600x600bb');
        final bytes = await downloadCover(client, big) ??
            await downloadCover(client, art);
        if (bytes == null) continue;
        return CoverSearchOutcome(CoverCandidate(
          source: 'iTunes',
          imageUrl: big,
          bytes: bytes,
          infoUrl: result['collectionViewUrl'] as String?,
        ));
      }
      return const CoverSearchOutcome(null, 'iTunes has no matching audiobook');
    } catch (_) {
      return const CoverSearchOutcome(null, 'iTunes could not be reached');
    }
  }
}
