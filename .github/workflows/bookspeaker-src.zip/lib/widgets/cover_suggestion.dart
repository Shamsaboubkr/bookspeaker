/// Non-intrusive "Use this cover?" suggestion.
///
/// The spec asks for a confirmation before an online cover is cached/embedded.
/// It used to be a modal dialog that popped up *over the player* the moment
/// playback started; it is now a dismissible card on the library screen, so it
/// never interrupts listening.
library;

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../library/book_model.dart';

class CoverSuggestionBanner extends StatelessWidget {
  const CoverSuggestionBanner({super.key, required this.offers});

  final List<CoverOffer> offers;

  @override
  Widget build(BuildContext context) {
    if (offers.isEmpty) return const SizedBox.shrink();
    final state = context.read<AppState>();
    final offer = offers.first;
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: SizedBox(
                  width: 56,
                  height: 76,
                  child: (offer.candidate.bytes == null ||
                          offer.candidate.bytes!.isEmpty)
                      ? const ColoredBox(
                          color: Color(0x224A3580),
                          child: Icon(Icons.image_outlined),
                        )
                      : Image.memory(
                          Uint8List.fromList(offer.candidate.bytes!),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const ColoredBox(
                            color: Color(0x224A3580),
                            child: Icon(Icons.image_not_supported),
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Use this cover?',
                        style: theme.textTheme.titleSmall
                            ?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 2),
                    Text(
                      '${offer.book.title}\nFound on ${offer.candidate.source}',
                      style: theme.textTheme.bodySmall,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      children: [
                        FilledButton.tonal(
                          onPressed: () => state.acceptCoverOffer(offer),
                          child: const Text('Use cover'),
                        ),
                        TextButton(
                          onPressed: () => state.dismissCoverOffer(offer),
                          child: const Text('Not now'),
                        ),
                        if (offers.length > 1)
                          TextButton(
                            onPressed: () {
                              for (final o in offers.skip(1).toList()) {
                                state.dismissCoverOffer(o);
                              }
                            },
                            child: Text('Skip ${offers.length - 1} more'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Small helper kept for parity with the spec's "Book not available" state.
extension BookAvailability on Book {
  bool get canPlay => isAvailable;
}
