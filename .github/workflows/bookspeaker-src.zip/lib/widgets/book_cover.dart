/// Cover art widget with the full fallback chain and a placeholder that is
/// deterministically coloured from the book title.
library;

import 'dart:io';

import 'package:flutter/material.dart';

import '../covers/palette_service.dart';
import '../library/book_model.dart';

class BookCover extends StatelessWidget {
  const BookCover({
    super.key,
    required this.book,
    this.width,
    this.height,
    this.radius = 14,
    this.progress = 0,
    this.showProgressBar = true,
  });

  final Book book;
  final double? width;
  final double? height;
  final double radius;
  final double progress;
  final bool showProgressBar;

  @override
  Widget build(BuildContext context) {
    final path = book.coverCachePath;
    final file = path != null ? File(path) : null;
    final hasImage = file != null && file.existsSync();

    return Opacity(
      opacity: book.isAvailable ? 1 : 0.45,
      child: SizedBox(
        width: width,
        height: height,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (hasImage)
                Image.file(file, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => _placeholder(context))
              else
                _placeholder(context),
              if (showProgressBar && progress > 0)
                Align(
                  alignment: Alignment.bottomCenter,
                  child: LinearProgressIndicator(
                    value: progress.clamp(0.0, 1.0),
                    minHeight: 4,
                    backgroundColor: Colors.black26,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Theme.of(context).colorScheme.primary,
                    ),
                  ),
                ),
              if (!book.isAvailable)
                const Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: EdgeInsets.all(6),
                    child: Icon(Icons.link_off, size: 16, color: Colors.white),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _placeholder(BuildContext context) {
    final base = PaletteService.placeholderColor(book.title);
    final initials = book.title
        .split(RegExp(r'\s+'))
        .where((w) => w.isNotEmpty)
        .take(2)
        .map((w) => w[0].toUpperCase())
        .join();

    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [base, Color.lerp(base, Colors.black, 0.35)!],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.menu_book, color: Colors.white70, size: 26),
            const SizedBox(height: 6),
            Text(
              initials,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Ghost watermark of the book title used behind the player UI.
class TitleWatermark extends StatelessWidget {
  const TitleWatermark({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return IgnorePointer(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Text(
            title.toUpperCase(),
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.clip,
            style: TextStyle(
              fontSize: 46,
              height: 1.05,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              color: (dark ? Colors.white : Colors.black).withOpacity(0.05),
            ),
          ),
        ),
      ),
    );
  }
}
