/// Empty / edge-state UI: no books, file not found, offline.
library;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../library/book_model.dart';

class EmptyLibrary extends StatelessWidget {
  const EmptyLibrary({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.auto_stories_outlined,
                size: 78, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 20),
            const Text('No audiobooks yet',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(
              'Add a folder containing your audiobook files',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: state.addFolderViaPicker,
              icon: const Icon(Icons.folder_open),
              label: const Text('Add Folder'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Shown when a greyed-out (missing) book is tapped.
Future<void> showMissingFileSheet(BuildContext context, Book book) async {
  final state = context.read<AppState>();
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (sheetContext) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('File not found',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text('This file may have been moved or deleted.'),
          const SizedBox(height: 6),
          Text(book.filePath,
              style: Theme.of(context).textTheme.bodySmall,
              maxLines: 2,
              overflow: TextOverflow.ellipsis),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(sheetContext);
              state.locateFile(book);
            },
            icon: const Icon(Icons.search),
            label: const Text('Locate File'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () {
              Navigator.pop(sheetContext);
              state.removeFromLibrary(book);
            },
            icon: const Icon(Icons.delete_outline),
            label: const Text('Remove from Library'),
          ),
        ],
      ),
    ),
  );
}

class OfflineNotice extends StatelessWidget {
  const OfflineNotice({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.cloud_off, size: 14),
          SizedBox(width: 6),
          Text('Offline — progress saved locally', style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
