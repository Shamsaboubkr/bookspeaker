/// Sync status chip, Drive-full warning banner and offline notice.
library;

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_state.dart';
import '../library/book_model.dart';
import '../progress/drive_sync_service.dart';

class SyncIndicator extends StatefulWidget {
  const SyncIndicator({super.key});

  @override
  State<SyncIndicator> createState() => _SyncIndicatorState();
}

class _SyncIndicatorState extends State<SyncIndicator> {
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    // The label has to tick, otherwise a healthy 30 s cadence looks frozen.
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sync = context.watch<DriveSyncService>();
    final (icon, label, color) = switch (sync.state) {
      SyncState.syncing => (Icons.sync, 'Syncing…', Colors.blue),
      SyncState.driveFull => (Icons.warning_amber_rounded, 'Sync paused', Colors.orange),
      SyncState.offline => (Icons.cloud_off, 'Offline', Colors.grey),
      SyncState.signedOut => (Icons.person_off_outlined, 'Local only', Colors.grey),
      SyncState.error => (Icons.error_outline, 'Sync error', Colors.red),
      SyncState.idle => (
          Icons.cloud_done,
          sync.lastSync == null
              ? 'Synced'
              : 'Synced ${relativeTimePrecise(sync.lastSync!)}',
          Colors.green,
        ),
    };

    return Tooltip(
      message: switch (sync.state) {
        SyncState.offline => 'Offline — progress saved locally',
        SyncState.driveFull => 'Google Drive is full — sync paused',
        _ => label,
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(fontSize: 12, color: color)),
          ],
        ),
      ),
    );
  }
}

/// Thin strip under the app bar: Drive-full warning (per spec) and an offline hint.
class SyncBanners extends StatelessWidget {
  const SyncBanners({super.key});

  @override
  Widget build(BuildContext context) {
    final sync = context.watch<DriveSyncService>();
    if (sync.state == SyncState.driveFull) return const DriveFullBanner();
    if (sync.state == SyncState.offline && sync.isSignedIn) {
      return const OfflineBanner();
    }
    return const SizedBox.shrink();
  }
}

class DriveFullBanner extends StatelessWidget {
  const DriveFullBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.orange.withOpacity(0.15),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.orange),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'Google Drive is full. Progress sync paused. '
                'Free up Drive space to resume syncing.',
                style: TextStyle(fontSize: 12),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.refresh, size: 18),
              onPressed: () => context.read<AppState>().forceSync(),
            ),
          ],
        ),
      ),
    );
  }
}

class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.grey.withOpacity(0.12),
      child: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(
          children: [
            Icon(Icons.cloud_off, size: 16),
            SizedBox(width: 8),
            Expanded(
              child: Text('Offline — progress saved locally',
                  style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}

/// A timestamp that re-renders once a second, so "12s ago" counts up live.
class LiveRelativeTime extends StatefulWidget {
  const LiveRelativeTime(this.then, {super.key, this.prefix = ''});

  final DateTime then;
  final String prefix;

  @override
  State<LiveRelativeTime> createState() => _LiveRelativeTimeState();
}

class _LiveRelativeTimeState extends State<LiveRelativeTime> {
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) =>
      Text('${widget.prefix}${relativeTimePrecise(widget.then)}');
}
