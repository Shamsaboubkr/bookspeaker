/// "Continue listening from?" — the device-history conflict picker.
library;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../library/book_model.dart';
import '../progress/drive_sync_service.dart';

Future<DeviceHistoryEntry?> showConflictSheet(
  BuildContext context,
  SyncConflict conflict,
) {
  final options = conflict.options;
  return showModalBottomSheet<DeviceHistoryEntry>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Continue listening from?',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(conflict.title,
                style: Theme.of(context).textTheme.bodySmall,
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 16),
            ...options.map((entry) {
              final icon = entry.deviceType == 'pc'
                  ? Icons.desktop_windows
                  : Icons.smartphone;
              return Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: ListTile(
                  leading: Icon(icon),
                  title: Text(entry.deviceName,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    '${formatDuration(Duration(milliseconds: entry.position_ms), hours: false)}'
                    '  •  ${relativeTime(entry.timestamp)}',
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.pop(context, entry),
                ),
              );
            }),
          ],
        ),
      );
    },
  );
}

String formatTimestamp(DateTime time) =>
    DateFormat('d MMM yyyy, HH:mm').format(time);
