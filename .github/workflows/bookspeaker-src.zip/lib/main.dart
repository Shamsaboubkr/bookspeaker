/// Bookspeaker entry point.
library;

import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import 'app/bookspeaker_app.dart';
import 'app/theme/dynamic_theme.dart';
import 'app_state.dart';
import 'auth/auth_state.dart';
import 'auth/desktop_oauth_service.dart';
import 'auth/google_auth.dart';
import 'auth/google_sign_in_service.dart';
import 'covers/cover_art_service.dart';
import 'library/book_scanner.dart';
import 'library/folder_watcher.dart';
import 'player/audio_player_service.dart';
import 'player/sleep_timer_service.dart';
import 'progress/drive_sync_service.dart';
import 'progress/local_storage_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final local = await LocalStorageService.open();

  // Android signs in through Play Services; Windows has no such thing, so it
  // uses the browser flow instead. Both expose the same interface, which is why
  // every line of the sync code is shared.
  final authService = await _createAuth(local);
  if (authService is DesktopGoogleAuthService) {
    await authService.signInSilently();
  }
  final authState = AuthState(authService);
  final sync = DriveSyncService(local, authService);
  final theme = ThemeController();
  final player = AudioPlayerService(local, sync);
  final sleepTimer = SleepTimerService();
  final covers = CoverArtService(local.db, local.cacheDirectory);
  final scanner = BookScanner(local.db, covers);
  final watcher = FolderWatcherService(local.db, scanner);

  // Audio_service must be initialised before the first frame so Android can
  // attach the media notification / lock-screen controls.
  final handler = BookspeakerAudioHandler(player);
  try {
    await AudioService.init(
      builder: () => handler,
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'com.bookspeaker.app.channel.audio',
        androidNotificationChannelName: 'Bookspeaker playback',
        androidNotificationChannelDescription:
            'Shows the book that is currently playing.',
        androidNotificationOngoing: true,
        androidStopForegroundOnPause: true,
        androidNotificationIcon: 'drawable/ic_stat_bookspeaker',
        androidShowNotificationBadge: false,
        androidNotificationClickStartsActivity: true,
        androidResumeOnClick: true,
      ),
    );
    player.attachHandler(handler);
  } catch (error) {
    // Playback still works in-app if the foreground service cannot start.
    debugPrint('Bookspeaker: audio_service init failed → $error');
  }

  final appState = AppState(
    local: local,
    auth: authService,
    authState: authState,
    sync: sync,
    theme: theme,
    player: player,
    sleepTimer: sleepTimer,
    scanner: scanner,
    watcher: watcher,
    covers: covers,
  );

  unawaitedPermissions();

  runApp(BookspeakerApp(appState: appState));
}

/// Asks for only what this Android version actually needs, after the first
/// frame, and never blocks startup. All-files access is requested later, only
/// if a folder the user picks turns out to be unreadable.
void unawaitedPermissions() {
  Future(() async {
    try {
      if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) return;
      final sdk = await _androidSdkInt();
      final requests = <Permission>[
        Permission.notification,
        if (sdk >= 33) Permission.audio else Permission.storage,
      ];
      for (final permission in requests) {
        final status = await permission.status;
        if (status.isDenied) await permission.request();
      }
    } catch (_) {}
  });
}

/// Picks the right sign-in implementation for this platform.
Future<GoogleAuth> _createAuth(LocalStorageService local) async {
  if (defaultTargetPlatform == TargetPlatform.android ||
      defaultTargetPlatform == TargetPlatform.iOS) {
    return GoogleSignInService();
  }
  // Desktop: the client id is compiled in at build time, and can be filled in
  // afterwards from Settings if the build was made without one.
  const compiled =
      String.fromEnvironment('BOOKSPEAKER_DESKTOP_CLIENT_ID', defaultValue: '');
  const compiledSecret =
      String.fromEnvironment('BOOKSPEAKER_DESKTOP_CLIENT_SECRET', defaultValue: '');
  final stored = local.db.getSetting('desktop_client_id') ?? '';
  final service = DesktopGoogleAuthService(
    clientId: compiled.isNotEmpty ? compiled : stored,
    clientSecret: compiledSecret,
  );
  await service.restore();
  return service;
}

Future<int> _androidSdkInt() async {
  try {
    const channel = MethodChannel('com.bookspeaker.app/platform');
    final value = await channel.invokeMethod<int>('sdkInt');
    return value ?? 33;
  } catch (_) {
    return 33;
  }
}
