// Live smoke test for the online cover sources (network required).
// Run: dart run tool/verify_cover_sources.dart
import 'package:bookspeaker/covers/cover_sources/openlibrary_source.dart';
import 'package:http/http.dart' as http;

final books = <(String, String)>[
  ('The Great Gatsby', 'F. Scott Fitzgerald'),
  ('Atomic Habits', 'James Clear'),
  ('Milk and Honey', 'Rupi Kaur'),
  ('Zzzz Nonexistent Book Title 9381', 'Nobody At All'),
];

Future<void> main() async {
  final client = http.Client();
  for (final (title, author) in books) {
    print('\n=== "$title" — $author ===');
    for (final source in ['OpenLibrary', 'Google Books', 'iTunes']) {
      final outcome = switch (source) {
        'OpenLibrary' => await OpenLibrarySource.search(client, title, author),
        'Google Books' => await GoogleBooksSource.search(client, title, author),
        _ => await ItunesSource.search(client, title, author),
      };
      final c = outcome.candidate;
      print(c != null
          ? '  $source: FOUND ${c.bytes!.length} bytes  ${c.imageUrl.substring(0, c.imageUrl.length.clamp(0, 70))}'
          : '  $source: none  (${outcome.note})');
    }
  }
  client.close();
}
