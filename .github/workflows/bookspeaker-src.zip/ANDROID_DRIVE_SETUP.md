# Bookspeaker — Google Drive sync setup (Android only)

This replaces the generic "Google Drive Sync Setup Guide" for the **Android** app.
Everything below is verified against this project's actual build and keystore.

---

## 0. The one thing to know first

**The Android APK needs no credential file at all — no `google-services.json`, no client ID,
no secret.** Nothing is embedded in the app for this.

On Android, Google decides whether your app may sign in by matching **two values in the Google
Cloud Console** against the installed app:

| What Google checks | Value it must match |
|---|---|
| Package name | `com.bookspeaker.app` |
| Signing certificate SHA-1 | `06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87` |

Both are already baked into the published APK (`apksigner verify` confirms the SHA-1 above).
So: **fix the Console, not the app.** No rebuild and no reinstall are needed.

### About the `google-services.json` you downloaded

The file uploaded was **byte-identical to the Desktop-app OAuth client JSON**
(`sha256 d46debd7…e752b5`) — i.e. it is not a Google-Services file at all. A real
`google-services.json` contains `project_info`, `client[]`, `mobilesdk_app_id`, an `api_key`
and an `android_info` block with `package_name` + `certificate_hash`. This one contains none
of those; it is the Windows/desktop credential renamed.

It also wouldn't matter for Android even if it were the real thing: `google-services.json` is
a **Firebase** file, read by the `com.google.gms.google-services` Gradle plugin. Bookspeaker
uses neither Firebase nor that plugin (`flutter_signin`-style auth via plain `google_sign_in`
6.2.2), so the file would sit in `android/app/` unused.

**Therefore: do not put it in `android/app/`.** Step 5 and Step 6 of that guide do not apply
to this app — there is nothing to rebuild and no new APK to install for sign-in to work.

---

## 1. Console checklist (this is what actually makes sync work)

Project: **`bookspeaker-510116`** (the same project the Desktop client came from —
keep everything in this one project so the Drive folder is shared).

Open <https://console.cloud.google.com> → make sure that project is selected → go through
this list. Each item is independent; a missing one breaks sync in a different way.

### 1.1 Google Drive API — must be ENABLED
`APIs & Services → Library →` search **Google Drive API** → **Enable**.
(If it still says "Enable", sync fails after sign-in with a 403 regardless of everything else.)

### 1.2 OAuth consent screen — External + the right scope
`APIs & Services → OAuth consent screen`
- User type: **External**
- App name: `Bookspeaker` · user support email + developer contact: your Gmail
- **Scopes** → *Add or remove scopes* → add exactly:
  - `https://www.googleapis.com/auth/drive.appdata` — the hidden app folder
    (Bookspeaker never touches the rest of your Drive)
  - `.../auth/userinfo.email` — optional; lets the app show which account is signed in
- **Test users** → *Add users* → add the Gmail account(s) you'll sign in with.
  While the app is in "Testing", **only listed accounts can sign in** — an unlisted
  account sees "Access blocked". (Publishing the app removes this limit; no verification
  is required for `drive.appdata`, it is not a sensitive scope.)

### 1.3 An **Android** OAuth client — the step that is most often missed
`APIs & Services → Credentials → Create credentials → OAuth client ID`

- Application type: **Android**  ← *not* Desktop, *not* Web
- Name: `Bookspeaker Android`
- Package name: `com.bookspeaker.app`
- SHA-1: `06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87`

There is **no download button** for an Android client and nothing to copy into the project —
just press **Create**. That is the whole step.

> A **Desktop-app** client (which is what your uploaded JSON is) does **not** authorise the
> Android app, and an Android client does **not** authorise the Windows app. They are
> separate entries in the same project.

---

## 2. Re-checking the SHA-1 (if you ever doubt it)

From the project root:

```bash
cd bookspeaker
keytool -list -v \
  -keystore android/app/bookspeaker-release.jks \
  -alias bookspeaker \
  -storepass bookspeaker
```

Two notes, both real:

* The password is **`bookspeaker`** — not `bookspeaker123`, which fails with
  *"keystore password was incorrect"*. The same password is in `android/key.properties`;
  if you change one, change both.
* This store is PKCS12 and needs **JDK 17+**. Under JDK 11 keytool refuses to open it with
  *"Integrity check failed: Algorithm HmacPBESHA256 not available"*. Use a JDK 17 keytool
  (one is available at `/home/user/tools/jdk-17.0.20.1+1-jre/bin/keytool`).

Expected output:

```
Alias name: bookspeaker
Owner: CN=Bookspeaker, OU=Bookspeaker, O=Bookspeaker, L=Sokoto, ST=Sokoto, C=NG
Valid from: Sep 29, 2026 until: Feb 14, 2054
SHA1: 06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87
```

This must equal the APK's signer too:

```bash
apksigner verify --print-certs bookspeaker/release/Bookspeaker-v1.0.2-android9-15-universal.apk
# -> 06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87   ✅
```

**Back up `bookspeaker-release.jks` + its password now.** It is the identity of the app:
lose it and no future update can install over the version already on your phone (Android
rejects a different signing key), and Drive sign-in would need a new client entry.

---

## 3. Testing it

Install the APK you already have (nothing to rebuild):

```bash
adb install -r bookspeaker/release/Bookspeaker-v1.0.2-android9-15-universal.apk
```

In the app: **Continue with Google** (or the account avatar → *Sign in*).

What success looks like:
1. Google's account picker appears → consent screen lists *"...store files in its own hidden
   folder in your Google Drive"*.
2. Back in the app the toast says the account name, the top bar shows your Google avatar and
   the sync indicator turns to **synced**.
3. `Settings → Account` shows the signed-in email and **Force sync**.

What actually lands on Drive (hidden app folder, ~2 KB per book):

```
Bookspeaker/
├── manifest.json
├── a3f9b2c1d4e5f6a7_progress.json
└── …
```

---

## 4. Troubleshooting — what the app will tell you

The app reports the reason as a toast / in `Settings → Account`, so you don't have to guess:

| App says | Cause | Fix |
|---|---|---|
| *"Google Sign-In is not configured for this build (no OAuth client for package com.bookspeaker.app)"* | Google found no **Android** OAuth client whose package + SHA-1 match this APK. This is Google's `ApiException: 10`. | Do §1.3. Check for typos in the package name and the full SHA-1, and that you used the **release** keystore's SHA-1, not a debug one. |
| *"Access blocked: Bookspeaker has not completed the Google verification process"* | Account not on the test-user list while the consent screen is in "Testing". | Add it in §1.2, or publish the app. |
| Sign-in works, then sync shows an error / 403 | Drive API not enabled (§1.1), or the `drive.appdata` scope missing from the consent screen (§1.2). | Fix in Console — takes effect within minutes, no app change. |
| *"No internet connection"* | Offline. Progress keeps saving locally and syncs when you're back. | — |
| *"Sign-in cancelled"* | You dismissed the account picker. | Tap again. |
| App shows **Drive is full** | The Google account's 15 GB is full (Gmail/Photos). Bookspeaker uses ~2 KB/book. | Free up space elsewhere in the account. |
| Second device doesn't see progress | Different Google account, no internet, or it hasn't pulled yet. | Same account on both; `Settings → Account → Force sync`. |

---

## 5. What is *not* needed for Android

- ❌ `google-services.json` (wrong file — it's the Desktop client JSON; and Firebase isn't used)
- ❌ Any Firebase project, `firebase_core`, or the `google-services` Gradle plugin
- ❌ A client ID or secret inside the app — nothing to paste, nothing to rebuild
- ❌ Adding `applicationIdSuffix`/debug keys — that would need a *second* Android client entry

For the deferred **Windows** build the desktop client is the right credential; it is kept out
of source control in `credentials/` and passed at build time via
`tool/desktop_client_dartdefines.sh` (see `credentials/README.md`).
