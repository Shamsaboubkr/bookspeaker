/// Tests for the Windows sign-in path.
///
/// These never touch the network or a real browser: the http client and the
/// token store are both injected, so the refresh logic, the error wording and
/// the "no client id" case are all checked hermetically.
library;

import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:bookspeaker/auth/desktop_oauth_service.dart';

void main() {
  group('desktop sign-in', () {
    test('says plainly when the build has no client ID', () async {
      final auth = DesktopGoogleAuthService(
        clientId: '',
        store: MemoryTokenStore(),
        httpClientFactory: () => MockClient((_) async => http.Response('{}', 200)),
        openBrowser: (_) async {},
      );

      final ok = await auth.signIn();

      expect(ok, isFalse);
      expect(auth.isSignedIn, isFalse);
      expect(auth.lastError, contains('client ID'));
      expect(auth.setupHint, contains('client ID'));
      expect(auth.usesBrowserSignIn, isTrue);
    });

    test('a stored refresh token is exchanged for an access token', () async {
      final store = MemoryTokenStore();
      await store.write({
        'refresh_token': 'refresh-123',
        'email': 'listener@example.com',
        'name': 'A Listener',
      });
      var seen = <String>[];

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          seen.add(request.url.toString());
          expect(request.body, contains('grant_type=refresh_token'));
          expect(request.body, contains('refresh_token=refresh-123'));
          return http.Response(
            jsonEncode({'access_token': 'access-456', 'expires_in': 3600}),
            200,
          );
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      expect(auth.isSignedIn, isTrue);
      expect(auth.user!.email, 'listener@example.com');

      final token = await auth.validAccessToken();
      expect(token, 'access-456');
      expect(seen.single, contains('oauth2.googleapis.com'));

      // A second call inside the token's lifetime must not hit the network.
      expect(await auth.validAccessToken(), 'access-456');
      expect(seen.length, 1);
    });

    test('a revoked grant signs the user out with an actionable message',
        () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'gone', 'email': 'x@example.com'});

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((_) async => http.Response(
              jsonEncode({'error': 'invalid_grant'}),
              400,
            )),
        openBrowser: (_) async {},
      );

      await auth.restore();
      final token = await auth.validAccessToken();

      expect(token, isNull);
      expect(auth.isSignedIn, isFalse, reason: 'the dead token is forgotten');
      expect(await store.read(), isNull, reason: 'and removed from disk');
      expect(auth.lastError, contains('expired'));
    });

    test('a web-app client id is explained instead of failing silently',
        () async {
      final auth = DesktopGoogleAuthService(
        clientId: 'web-client',
        store: MemoryTokenStore(),
        httpClientFactory: () => MockClient((_) async => http.Response(
              jsonEncode({
                'error': 'redirect_uri_mismatch',
                'error_description': 'Bad Request',
              }),
              400,
            )),
        openBrowser: (_) async {},
      );

      // Drive the exchange directly: the loopback wait is covered by the real
      // browser run, but the message for this specific rejection is worth
      // pinning down.
      final message = auth.explainTokenError({
        'error': 'redirect_uri_mismatch',
      });

      expect(message, contains('Desktop app'));
      expect(message, contains('web clients'));
    });

    test('offline is reported as a connection problem, not an auth one',
        () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'r', 'email': 'x@example.com'});
      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((_) async => throw const SocketishError()),
        openBrowser: (_) async {},
      );

      await auth.restore();
      expect(await auth.validAccessToken(), isNull);
      expect(auth.lastError, isNotNull);
      expect(auth.lastError!.toLowerCase(), contains('internet'));
    });

    test('signing out revokes the grant and clears the stored token', () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'revoke-me', 'email': 'x@example.com'});
      var revoked = false;

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          if (request.url.toString().contains('revoke')) revoked = true;
          return http.Response('{}', 200);
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      await auth.signOut();

      expect(revoked, isTrue);
      expect(auth.isSignedIn, isFalse);
      expect(await store.read(), isNull);
    });
  });

  _urlIntegrityTests();
  _clientIdHandlingTests();
  _clientSecretTests();
}

/// Stands in for a connection failure without importing dart:io into the test.
class SocketishError implements Exception {
  const SocketishError();
  @override
  String toString() => 'SocketException: Failed host lookup (no internet)';
}

/// Regression tests for the bug that made Google answer
/// "Required parameter is missing: response_type".
///
/// The consent URL contains several `&` characters. Launching it through
/// `cmd /c start` let cmd.exe treat those as command separators, so the browser
/// only received everything up to the first `&` — which cut the URL right after
/// `redirect_uri`, dropping `response_type` and every parameter after it.
void _urlIntegrityTests() {
  group('the browser receives the whole URL', () {
    const url = 'https://accounts.google.com/o/oauth2/v2/auth'
        '?client_id=abc.apps.googleusercontent.com'
        '&redirect_uri=http://127.0.0.1:51234/'
        '&response_type=code'
        '&scope=openid%20email%20profile%20https://www.googleapis.com/auth/drive.appdata'
        '&access_type=offline'
        '&state=xyz';

    test('the Windows command carries the URL untouched', () {
      final command = browserCommandFor(url, onWindows: true, onMacOS: false);
      final joined = command.arguments.join(' ');

      expect(joined, contains(url),
          reason: 'the URL must appear intact, ampersands and all');
      expect(joined, contains('response_type=code'));
      expect(joined, contains('drive.appdata'));
      expect(command.executable, isNot('cmd'),
          reason: 'cmd.exe splits the URL at the first "&"');
    });

    test('the URL is never handed to a shell that would split it', () {
      for (final windows in [true, false]) {
        final command =
            browserCommandFor(url, onWindows: windows, onMacOS: !windows);
        final joined = command.arguments.join(' ');
        // Ampersands must be inside a quoted string, not bare.
        if (joined.contains('&')) {
          expect(joined.contains("'$url'") || command.arguments.contains(url), isTrue,
              reason: 'a bare & would be read as a command separator');
        }
      }
    });

    test('every parameter Google requires is in the consent URL', () {
      final built = DesktopGoogleAuthService.buildAuthUrl(
        clientId: 'abc.apps.googleusercontent.com',
        redirectUri: 'http://127.0.0.1:51234/',
        state: 'state-value',
        codeChallenge: 'challenge-value',
      );
      final params = built.queryParameters;

      expect(params['response_type'], 'code');
      expect(params['client_id'], 'abc.apps.googleusercontent.com');
      expect(params['redirect_uri'], 'http://127.0.0.1:51234/');
      expect(params['access_type'], 'offline',
          reason: 'without this Google issues no refresh token');
      expect(params['code_challenge_method'], 'S256');
      expect(params['scope'], contains('drive.appdata'));
      expect(params['scope'], contains('openid'));

      // and the serialised URL keeps them all
      final text = built.toString();
      for (final key in ['client_id', 'redirect_uri', 'response_type', 'scope',
                         'access_type', 'state', 'code_challenge']) {
        expect(text, contains('$key='));
      }
      // a redirect to the loopback address is what the local server listens on
      expect(params['redirect_uri'], startsWith('http://127.0.0.1:'));
    });
  });
}

/// Correcting a wrong client ID must never require rebuilding the app.
void _clientIdHandlingTests() {
  group('choosing which client ID to use', () {
    test('one typed in Settings beats the one compiled into the build', () {
      final chosen = DesktopGoogleAuthService.resolveClientId(
        compiled: 'old-broken.apps.googleusercontent.com',
        stored: 'fresh-desktop-client.apps.googleusercontent.com',
      );
      expect(chosen, 'fresh-desktop-client.apps.googleusercontent.com');
    });

    test('with nothing in Settings the build value is used', () {
      expect(
        DesktopGoogleAuthService.resolveClientId(
          compiled: 'from-build.apps.googleusercontent.com',
          stored: '',
        ),
        'from-build.apps.googleusercontent.com',
      );
      expect(
        DesktopGoogleAuthService.resolveClientId(
          compiled: 'from-build.apps.googleusercontent.com',
          stored: '   ',
        ),
        'from-build.apps.googleusercontent.com',
        reason: 'whitespace must not count as a choice',
      );
    });

    test('typos are caught here rather than by Google', () {
      expect(DesktopGoogleAuthService.validateClientId(''), isNotNull);
      expect(DesktopGoogleAuthService.validateClientId('   '), isNotNull);
      expect(
        DesktopGoogleAuthService.validateClientId('481266824841-abc.apps.google.com'),
        isNotNull,
        reason: 'the suffix must be exact',
      );
      expect(
        DesktopGoogleAuthService.validateClientId('481266824841 abc.apps.googleusercontent.com'),
        isNotNull,
        reason: 'no spaces',
      );
      expect(
        DesktopGoogleAuthService.validateClientId('short.apps.googleusercontent.com'),
        isNotNull,
        reason: 'too short to be real',
      );
      expect(
        DesktopGoogleAuthService.validateClientId(
            '481266824841-utk24fqnq2uhjgnvrokqpfils3dmcosh.apps.googleusercontent.com'),
        isNull,
        reason: 'a well-formed ID passes',
      );
    });
  });
}

/// Desktop clients are issued an id *and* a secret, and the token exchange is
/// rejected with "client_secret is missing" without it.
void _clientSecretTests() {
  group('the client secret', () {
    test('is sent with the refresh-token exchange', () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'r', 'email': 'x@example.com'});
      String? body;

      final auth = DesktopGoogleAuthService(
        clientId: '481266824841-abc.apps.googleusercontent.com',
        clientSecret: 'GOCSPX-not-really-secret',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          body = request.body;
          return http.Response(jsonEncode({'access_token': 'a', 'expires_in': 3600}), 200);
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      expect(await auth.validAccessToken(), 'a');
      expect(body, contains('client_secret=GOCSPX-not-really-secret'));
      expect(body, contains('client_id=481266824841-abc.apps.googleusercontent.com'));
    });

    test('is omitted when the build has none, instead of sending an empty one',
        () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'r', 'email': 'x@example.com'});
      String? body;

      final auth = DesktopGoogleAuthService(
        clientId: 'c.apps.googleusercontent.com',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          body = request.body;
          return http.Response(jsonEncode({'access_token': 'a', 'expires_in': 3600}), 200);
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      await auth.validAccessToken();
      expect(body, isNot(contains('client_secret')));
    });

    test('the missing-secret error says exactly what to do', () {
      final auth = DesktopGoogleAuthService(
        clientId: 'c.apps.googleusercontent.com',
        store: MemoryTokenStore(),
        httpClientFactory: () => MockClient((_) async => http.Response('{}', 200)),
        openBrowser: (_) async {},
      );

      final message = auth.explainTokenError({
        'error': 'invalid_request',
        'error_description': 'client_secret is missing.',
      });

      expect(message, contains('secret'));
      expect(message, contains('Credentials'));
      expect(message, isNot(contains('invalid_request —')),
          reason: 'a raw Google string is not an instruction');
    });

    test("Google's downloaded JSON fills in both values at once", () {
      const downloaded = '''
      {"installed":{
        "client_id":"481266824841-utk24fqnq2uhjgnvrokqpfils3dmcosh.apps.googleusercontent.com",
        "project_id":"bookspeaker-510116",
        "auth_uri":"https://accounts.google.com/o/oauth2/auth",
        "token_uri":"https://oauth2.googleapis.com/token",
        "client_secret":"GOCSPX-abc123",
        "redirect_uris":["http://localhost"]}}''';

      final parsed = DesktopGoogleAuthService.parseClientJson(downloaded);
      expect(parsed.id, endsWith('.apps.googleusercontent.com'));
      expect(parsed.secret, 'GOCSPX-abc123');
      expect(
        DesktopGoogleAuthService.validateClientId(parsed.id),
        isNull,
        reason: 'the id taken from the file is well formed',
      );
    });

    test('a pasted client ID alone is not mistaken for JSON', () {
      final parsed = DesktopGoogleAuthService.parseClientJson(
          '481266824841-utk24fqnq2uhjgnvrokqpfils3dmcosh.apps.googleusercontent.com');
      expect(parsed.id, isEmpty);
      expect(parsed.secret, isEmpty);
    });

    test('rubbish in the JSON box does not throw', () {
      for (final junk in ['{', '{"installed":', 'null', '{"installed":null}']) {
        final parsed = DesktopGoogleAuthService.parseClientJson(junk);
        expect(parsed.id, isEmpty);
        expect(parsed.secret, isEmpty);
      }
    });
  });
}
