/// Tests for the Windows sign-in path.
///
/// These never touch the network or a real browser: the http client and the
/// token store are both injected, so the refresh logic, the error wording and
/// the "no client id" case are all checked hermetically.
library;

import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

import 'package:bookspeaker/auth/desktop_oauth_service.dart';

void main() {
  group('desktop sign-in', () {
    test('says plainly when the build has no client ID', () async {
      final auth = DesktopGoogleAuthService(
        clientId: '',
        store: MemoryTokenStore(),
        httpClientFactory: () => MockClient((_) async => http.Response('{}', 200)),
        openBrowser: (_) async {},
      );

      final ok = await auth.signIn();

      expect(ok, isFalse);
      expect(auth.isSignedIn, isFalse);
      expect(auth.lastError, contains('client ID'));
      expect(auth.setupHint, contains('client ID'));
      expect(auth.usesBrowserSignIn, isTrue);
    });

    test('a stored refresh token is exchanged for an access token', () async {
      final store = MemoryTokenStore();
      await store.write({
        'refresh_token': 'refresh-123',
        'email': 'listener@example.com',
        'name': 'A Listener',
      });
      var seen = <String>[];

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          seen.add(request.url.toString());
          expect(request.body, contains('grant_type=refresh_token'));
          expect(request.body, contains('refresh_token=refresh-123'));
          return http.Response(
            jsonEncode({'access_token': 'access-456', 'expires_in': 3600}),
            200,
          );
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      expect(auth.isSignedIn, isTrue);
      expect(auth.user!.email, 'listener@example.com');

      final token = await auth.validAccessToken();
      expect(token, 'access-456');
      expect(seen.single, contains('oauth2.googleapis.com'));

      // A second call inside the token's lifetime must not hit the network.
      expect(await auth.validAccessToken(), 'access-456');
      expect(seen.length, 1);
    });

    test('a revoked grant signs the user out with an actionable message',
        () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'gone', 'email': 'x@example.com'});

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((_) async => http.Response(
              jsonEncode({'error': 'invalid_grant'}),
              400,
            )),
        openBrowser: (_) async {},
      );

      await auth.restore();
      final token = await auth.validAccessToken();

      expect(token, isNull);
      expect(auth.isSignedIn, isFalse, reason: 'the dead token is forgotten');
      expect(await store.read(), isNull, reason: 'and removed from disk');
      expect(auth.lastError, contains('expired'));
    });

    test('a web-app client id is explained instead of failing silently',
        () async {
      final auth = DesktopGoogleAuthService(
        clientId: 'web-client',
        store: MemoryTokenStore(),
        httpClientFactory: () => MockClient((_) async => http.Response(
              jsonEncode({
                'error': 'redirect_uri_mismatch',
                'error_description': 'Bad Request',
              }),
              400,
            )),
        openBrowser: (_) async {},
      );

      // Drive the exchange directly: the loopback wait is covered by the real
      // browser run, but the message for this specific rejection is worth
      // pinning down.
      final message = auth.explainTokenError({
        'error': 'redirect_uri_mismatch',
      });

      expect(message, contains('Desktop app'));
      expect(message, contains('web clients'));
    });

    test('offline is reported as a connection problem, not an auth one',
        () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'r', 'email': 'x@example.com'});
      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((_) async => throw const SocketishError()),
        openBrowser: (_) async {},
      );

      await auth.restore();
      expect(await auth.validAccessToken(), isNull);
      expect(auth.lastError, isNotNull);
      expect(auth.lastError!.toLowerCase(), contains('internet'));
    });

    test('signing out revokes the grant and clears the stored token', () async {
      final store = MemoryTokenStore();
      await store.write({'refresh_token': 'revoke-me', 'email': 'x@example.com'});
      var revoked = false;

      final auth = DesktopGoogleAuthService(
        clientId: 'client-abc',
        store: store,
        httpClientFactory: () => MockClient((request) async {
          if (request.url.toString().contains('revoke')) revoked = true;
          return http.Response('{}', 200);
        }),
        openBrowser: (_) async {},
      );

      await auth.restore();
      await auth.signOut();

      expect(revoked, isTrue);
      expect(auth.isSignedIn, isFalse);
      expect(await store.read(), isNull);
    });
  });
}

/// Stands in for a connection failure without importing dart:io into the test.
class SocketishError implements Exception {
  const SocketishError();
  @override
  String toString() => 'SocketException: Failed host lookup (no internet)';
}
