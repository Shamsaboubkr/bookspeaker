// Unit tests for the pure-Dart pieces of Bookspeaker (no platform channels).
import 'package:bookspeaker/library/book_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('duration formatting', () {
    expect(formatDuration(const Duration(hours: 2, minutes: 32)), '2:32:00');
    expect(formatDuration(const Duration(minutes: 3, seconds: 7), hours: false), '3:07');
  });

  test('audio format detection', () {
    expect(AudioFormatX.fromExtension('/books/gatsby.mp3'), AudioFormat.mp3);
    expect(AudioFormatX.fromExtension('/books/gatsby.M4B'), AudioFormat.m4a);
    expect(AudioFormatX.fromExtension('/books/gatsby.opus'), AudioFormat.opus);
    expect(AudioFormatX.fromExtension('/books/notes.txt'), isNull);
  });

  test('progress percent + remaining honour playback speed', () {
    final pr = BookProgress(
      bookId: 'abc',
      position_ms: 1000,
      totalDuration_ms: 4000,
      playbackSpeed: 2.0,
    );
    expect(pr.remaining, const Duration(milliseconds: 1500));
  });

  test('drive payload round-trips position and device history', () {
    final pr = BookProgress(
      bookId: 'abc',
      position_ms: 9177000,
      totalDuration_ms: 33311000,
      percentComplete: 27.4,
      playbackSpeed: 1.5,
      lastPlayedDevice: 'Pixel 7',
      deviceType: 'phone',
      deviceHistory: [
        DeviceHistoryEntry(
          deviceName: 'Pixel 7',
          deviceType: 'phone',
          position_ms: 9177000,
          timestamp: DateTime(2024, 1, 15, 14, 32),
        ),
      ],
    );
    final json = pr.toDriveJson(title: 'The Great Gatsby', author: 'F. Scott Fitzgerald');
    final back = BookProgress.fromDriveJson(json);
    expect(back.position_ms, 9177000);
    expect(back.playbackSpeed, 1.5);
    expect(back.deviceHistory.first.deviceName, 'Pixel 7');
  });
}
