# Making the Windows app sync with your phone

Windows has no Google Play Services, so the desktop build cannot use the same
sign-in the Android app uses. Instead it opens **your own browser**, you approve
access on Google's page, and the app catches the reply on a loopback address
(`http://127.0.0.1`). That is the flow Google requires for installed apps
(RFC 8252). Your password is never typed into the app.

Both apps write to the **same hidden Drive folder**, so progress travels between
them. Nothing else in your Drive is ever visible to the app.

---

## 1. Check the Google Cloud project (mostly already done for Android)

Open <https://console.cloud.google.com/> and pick the project your Android app
uses — **`bookspeaker-510116`**.

| What | Where | Expected |
|---|---|---|
| Drive API | APIs & Services ▸ Enabled APIs | **Google Drive API** enabled (it is: the phone syncs) |
| Android client | APIs & Services ▸ Credentials | `com.bookspeaker.app` — unchanged |
| Desktop client | APIs & Services ▸ Credentials | **Desktop app** type, id starting `481266824841-…` |
| Consent screen | APIs & Services ▸ OAuth consent screen | same as now — if it is in *Testing*, your Google account must be listed as a test user (it already is, or the phone could not sync) |

**The one thing that matters most:** the desktop client must live in the **same
project** as the Android client. Drive's hidden app folder is per-project, so a
client from a different project would sync to a *different* hidden folder and the
two devices would never see each other's progress.

### If you have to create the desktop client

1. Credentials ▸ **Create credentials** ▸ **OAuth client ID**
2. Application type: **Desktop app** ← *not* "Web application"
3. Name it anything (e.g. `Bookspeaker Windows`), click **Create**
4. Copy the client ID (ends with `.apps.googleusercontent.com`)

No redirect URI needs registering — loopback addresses are allowed automatically
for Desktop clients.

> **"Web application" will not work.** Google only permits the loopback reply for
> Desktop clients. If a web client is used, the app now says so in plain words:
> *"Google rejected the redirect. The client ID must belong to a 'Desktop app'
> OAuth client."*

---

## 2. Put the client ID into the build

The workflow already carries it:

```yaml
env:
  DESKTOP_CLIENT_ID: ${{ secrets.BOOKSPEAKER_DESKTOP_CLIENT_ID || '481266824841-…' }}
```

* **Nothing to do** if that client is the correct Desktop app client — the
  fallback value is used.
* **To use a different client**, add a repository secret named
  `BOOKSPEAKER_DESKTOP_CLIENT_ID` (Settings ▸ Secrets and variables ▸ Actions ▸
  New repository secret). A secret always wins over the fallback.

The value is compiled into the app, so changing it means re-running the build.

---

## 3. Sign in on the PC

1. Open Bookspeaker ▸ **Settings ▸ Account**
2. Press **Connect Google Drive**
3. Your browser opens Google's consent page — choose the **same Google account
   your phone uses**, and approve
4. The browser shows *"Bookspeaker is connected"*; close the tab and return
5. The card now shows your address and *Last synced*

From then on the app keeps a refresh token on the PC (in
`%APPDATA%`-style app support folder, file `google_desktop_auth.json`) and
renews access tokens silently. You stay signed in between launches.

---

## 4. How the sync behaves (same rules as Android)

| Event | What happens |
|---|---|
| Every 10 s while playing | progress saved to the local database |
| Every 30 s while playing | pushed to Drive |
| Pause, book switch, app close | saved **and** pushed immediately |
| App start, book opened | pulled from Drive |
| Connection returns | every pending push is retried |

If two devices were played within a minute of each other, the app asks which
position should win instead of silently overwriting one.

---

## Troubleshooting

| Message | Meaning / fix |
|---|---|
| *No Google client ID is set for this build* | Paste one in **Settings ▸ Account** (or rebuild with the secret). |
| *Google rejected the redirect… Desktop app OAuth client* | The client is a "Web application" one. Create a Desktop app client. |
| *Google did not recognise this client ID* | The ID was copied incompletely, or belongs to another project. |
| *Sign-in has expired. Connect again.* | The grant was revoked (or unused 6 months). Press Connect again. |
| *Could not reach Google* | The PC is offline. Progress keeps saving locally and pushes later. |
| Sync badge stays **Local only** | Not signed in yet. Settings ▸ Account ▸ Connect Google Drive. |
| Phone and PC both syncing, but never to each other | The two OAuth clients are in different Cloud projects. |

---

## What is *not* shared

Only **progress, bookmarks, playback speed, device history and file paths**.
The audiobooks themselves stay on each device — the app never uploads audio.
That is deliberate: it keeps sync instant and your Drive small.
