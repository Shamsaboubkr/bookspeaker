# Bookspeaker — Android build report

**Deliverable:** `release/Bookspeaker-v1.0.5-android9-15-universal.apk`
**History:** v1.0.0 (first build) → v1.0.1 (§7: UI/UX bugs) → v1.0.2 (§8: cover art) → v1.0.3 (§9: sync cadence) → v1.0.4 (§10: drive client bug) → v1.0.5 (§11: log removed from UI)
**Built:** 2026-09-29 · Flutter 3.24.5 (Dart 3.5.4) · JDK 17 · AGP 8.1 · Gradle 8.3 · Android SDK 35

---

## 1. Install

```bash
adb install -r Bookspeaker-v1.0.3-android9-15-universal.apk
# or: copy to the phone and tap it (enable "Install unknown apps" for your file manager)
```

First launch: **Continue with Google** (or *Continue without signing in*) → pick your
audiobook folder → the scan lists what it found → *Go to my library*.

## 2. Verified APK properties

| Property | Value |
|---|---|
| File | `Bookspeaker-v1.0.3-android9-15-universal.apk` |
| Size | 72,136,579 bytes (69 MB) |
| SHA-256 | `9f476ef0de9cba4fb69e3fd4b6b8275acee44632d006dba6db4db9b300f72dc5` |
| Package | `com.bookspeaker.app` |
| Version | 1.0.3 (versionCode 4) — installs straight over v1.0.0 / 1.0.1 / 1.0.2 |
| minSdkVersion | **28 — Android 9.0** |
| targetSdkVersion / compileSdk | **35 — Android 15** |
| ABIs | `arm64-v8a`, `armeabi-v7a`, `x86_64` (runs on every Android 9–15 device, 32/64-bit, real or emulator) |
| Signature | APK Signature Scheme **v2**, verified |
| Signer | `CN=Bookspeaker, OU=Bookspeaker, O=Bookspeaker, L=Sokoto, ST=Sokoto, C=NG` |
| Cert SHA-1 | `06:8A:6A:70:AE:EF:FC:2A:97:EA:26:3F:15:5E:E0:B6:C3:F6:92:87` |
| Cert SHA-256 | `97:26:BF:8D:4C:E6:97:97:3B:5F:F0:64:68:85:CA:18:13:D3:AC:A5:C2:4E:87:ED:16:A6:4A:00:FE:A6:57:4F` |
| Launcher icons | adaptive icon (purple #4A3580 + gold book/headphones), all densities |
| Launch window | brand purple + logo (never white), light and dark variants |
| Notification icon | monochrome `drawable/ic_stat_bookspeaker` (no white square) |
| Label | “Bookspeaker” |

Manifest contents confirmed inside the built APK: `MainActivity`, the
`com.ryanheise.audioservice.AudioService` service with
`foregroundServiceType="mediaPlayback"`, the `MediaButtonReceiver`, the
`android.media.browse.MediaBrowserService` intent filter, and permissions
`WAKE_LOCK, FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PLAYBACK,
POST_NOTIFICATIONS, INTERNET, ACCESS_NETWORK_STATE, READ_MEDIA_AUDIO,
READ_EXTERNAL_STORAGE (maxSdkVersion 32), MANAGE_EXTERNAL_STORAGE`.

## 3. Test + analysis status

`flutter test` → **27 / 27 passing**

* `test/widget_test.dart` (4) — duration formatting, format detection, remaining-time at
  speed, Drive payload round-trip.
* `test/db_test.dart` (7) — real SQLite file: schema creation, progress round-trip
  (speed/finished/sync status), bookmarks + device history, watched folders + settings,
  cover-check flags that survive rescans, silence-skipping default = off, missing-file
  grey-out that keeps progress.
* `test/cover_cache_test.dart` (5) — placeholder rejection, replacing artwork writes a
  **new** file and prunes the old one, legacy cache pickup, manual override wins over
  embedded artwork on later launches, non-image payloads refused.
* `test/fingerprint_and_cover_test.dart` (5) — fingerprint is 16 hex chars and unchanged
  by rename/move, changes when audio changes, survives cover embedding; the ID3 APIC
  writer is read back through a real tag parser, keeps the existing TIT2 title, leaves the
  audio payload byte-identical, and never stacks duplicate tags.

`flutter analyze` → **0 errors, 0 warnings** (9 style infos).

### Bug found and fixed by the tests

The spec's formula hashes the **total file size**, but the app itself embeds cover art,
which changes the container size — that would have changed a book's ID every time a cover
was set, orphaning its progress. `FingerprintService` now hashes the **audio payload size**
(file size − metadata header). Rename, move, tag edits *and* cover embedding all keep the
same ID; any change to the audio itself still produces a new one.

## 4. Not verified here (no device in this environment)

* No runtime smoke test on hardware/emulator: this sandbox has no `/dev/kvm`, so an
  Android emulator cannot be booted. Static verification (badging, signature, manifest
  inspection) plus the 14 automated tests are what backs this build. Install it on your
  phone and the app will log anything unexpected via `adb logcat -s flutter`.
* Google Sign-In / Drive sync need your own OAuth client (see README §2) — until then the
  app runs in local-only mode by design, with a clear message rather than a crash.

## 5. Smaller / other variants

The per-ABI APKs were built and verified too (same key, same SDK levels):

| Variant | Size |
|---|---|
| `app-arm64-v8a-release.apk` | 35.0 MB |
| `app-armeabi-v7a-release.apk` | 32.6 MB |
| `app-x86_64-release.apk` | 36.1 MB |

They are not kept in `release/` (one 69 MB universal APK is enough for distribution), but
regenerate in ~1 minute with the Gradle cache warm:

```bash
source /home/user/.envrc_bs.sh
cd bookspeaker && flutter build apk --release --split-per-abi --no-tree-shake-icons
```

They carry a higher `versionCode` than the universal build (standard Flutter behaviour), so
**pick one variant and stay with it** — installing the universal APK over an arm64 install
would be treated as a downgrade.

## 6. Keep these safe

* `android/app/bookspeaker-release.jks` + `android/key.properties` — **the signing key**.
  Any future update must be signed with this same key, otherwise Android refuses to
  install it over the existing app.
* `release/SHA256SUMS.txt` — checksum for the shipped APK.


---

## 7. v1.0.1 — fixes for the reported bugs

Every symptom you reported traced to a concrete cause:

| Reported | Cause found | Fix |
|---|---|---|
| Rewind and forward buttons don't look the same | Forward used a plain arrow (`Icons.forward`), rewind a circular arrow → different shapes and weights | One `_SkipButton` widget; the forward button is the exact **mirror** of the rewind button (`Transform.flip`), with the seconds centred inside the arc |
| Audio skips silence although it was never set | `player.setSkipSilenceEnabled(true)` was hard-coded when a book loaded | Silence skipping is now an **opt-in** setting (default **off**) in Settings → Playback; the value persists and applies live. Regression test added |
| Pressing Back turns the screen white | Back at the root finished the activity; Android then displayed the launch window, which the Flutter template hard-codes as **white**, while the engine cold-started | Back now **backgrounds the task** (new `moveTaskToBack` platform method) so playback and the UI stay alive; the launch window is brand purple with the logo (light + dark), so no white flash can occur |
| App feels slow after playback starts; taps don't respond or open | Playback position ticks (≈5×/s) called `notifyListeners()` on the **app-wide** state, rebuilding the library grid and its images; the media notification was republished on every tick | Playback is now its own provider — the library/bookmarks/settings screens never rebuild during playback; position notifications are throttled to ~4×/s and the notification state to ~1×/s |
| Slow/janky startup, especially after closing and reopening | Startup scanned every folder, re-read every audio file's tags **and its embedded cover** on the UI thread, and pushed to Drive while opening screens | Directory walks are async, tag reads / fingerprinting / cover embedding run in **worker isolates**, cover lookups are limited to 6 files per pass and remembered via a `cover_checked` flag, rescans are skipped if one finished < 30 s ago, Drive pushes are fire-and-forget, and the UI paints before the heavy work starts |
| UI "pops up" when music starts | A modal *"Use this cover?"* dialog was raised from the root context over the player, and the mini player lived in the Scaffold FAB slot (overlapping the navigation bar) | The cover suggestion is now a dismissible **card on the library screen**; the mini player is part of the layout above the nav bar; opening a book no longer pops anything |
| Search → tap result could leave a blank screen | The search route was popped and the player pushed in the same frame | The outer navigator is captured first and the push happens after the search route settles |

Rebuild/verify commands and checksums are unchanged — see §2 (`SHA256SUMS.txt` in `release/`).


---

## 8. v1.0.2 — fixes for the cover-art bugs

| Reported | Cause found | Fix |
|---|---|---|
| Set a wrong cover, then picking the correct one "doesn't apply" | The replacement was written to the **same cache path**, so Flutter's `ImageCache` kept serving the already-decoded *old* picture for that path. Nothing on screen changed | Every write now gets a fresh filename (`<bookId>_<microsecondsSinceEpoch>.jpg`), the previous file is deleted and evicted from the image cache — the new artwork shows instantly in the grid, player and media notification. Covered by a regression test |
| "Fetch album cover from the internet does nothing — nothing displays" | Two separate faults: (a) all result/failure messages were stored in a field that **no widget ever displayed**; (b) Google Books (the only fallback) currently answers **HTTP 429 quota exceeded** for anonymous callers, and that was swallowed silently | Messages now flow through `AppState.messages` → snack bars in the app shell, and the lookup opens a **sheet immediately**: spinner → cover preview + *Use this cover*, or *No cover found* with the actual reason and *Try again* |
| Online lookup often found nothing | The OpenLibrary query included the author, which frequently returns zero docs; a missing cover came back as a 43-byte blank placeholder that passed the old size check | Query retries **title-only** when title+author finds nothing; covers are fetched with `?default=false` (proper 404 instead of a blank GIF) and validated by magic bytes + minimum size. **iTunes Search API added as a third source** (audiobook-specific, no key, 600×600 artwork) |

Also improved:
* **Instant feedback while embedding:** the cover appears immediately, then a message confirms it was
  written into the MP3 (`Cover written into gatsby.mp3`) or explains why it could not be
  (`.m4a`/`.opus` cannot carry artwork inside the file yet — saved in Bookspeaker instead).
* Manual picking accepts both a file path *and* raw bytes, validates that the file really is an
  image, and reports failures instead of returning silently.
* "Look up cover online" is now also in the **player's ⋯ menu**, so a wrong cover can be fixed
  while listening.
* Background lookups (on book open) still never interrupt: they show a dismissible card at the
  top of the library instead of a dialog.

Live verification (network, from the build machine):

```
"The Great Gatsby"   OpenLibrary: FOUND 23614 bytes | Google Books: none (rate-limiting) | iTunes: FOUND 51826 bytes
"Atomic Habits"      OpenLibrary: FOUND 45809 bytes | Google Books: none (rate-limiting) | iTunes: FOUND 78292 bytes
"Nonexistent Title"  OpenLibrary: none (no cover)    | Google Books: none (rate-limiting) | iTunes: none (no match)
```


---

## 9. v1.0.3 — the playback sync cadence

Full write-up: `SYNC_AUDIT.md`. Summary of what was wrong and what changed.

| Issue | Cause | Fix |
|---|---|---|
| Sync seemed to happen only on restart | `saveAndPush()` defaulted to `push: false` and **every** close path called it bare, so app close saved locally and never reached Drive. There was also no `WidgetsBindingObserver` anywhere in `lib/` | `push` now defaults to `true`; the Back-button and `shutdown()` paths use `saveAndPush(awaitPush: true)` (6 s bound). New lifecycle observer flushes on `paused`/`hidden`/`detached` and pulls on `resumed` |
| Book switch did not push | `openBook()` only did `_saveLocal()` for the book being left | It now pushes the previous book, fire-and-forget |
| Chip could freeze on "Syncing…" | `if (session == null) return;` bailed out *after* the state was set to syncing | Explicit terminal state + a log entry saying why |
| A failing platform `pause()` could leave the timers running | `await player.pause()` came before `_stopTimers()` | Cadence stops first; the platform call is guarded |
| The 30 s cadence was invisible | The chip only rebuilt when the state changed, and `relativeTime()` collapses <60 s into "just now" — so the label could not change | Chip ticks once a second (`Synced 12s ago`), and a push holds "Syncing…" on screen for 900 ms |
| Settings showed a frozen "Last synced" | Same missing tick | `LiveRelativeTime` + **Playback save cadence** counters + **Sync activity** list (time · book · position · outcome) |

New tests — `test/sync_cadence_test.dart` (6), run against the production
`AudioPlayerService` with injected 40 ms / 100 ms intervals and a recording sync layer:
repeated Drive pushes while playing, the local-save cadence, push-on-pause (exactly one,
immediately), push-on-book-switch, push-on-close, and nothing at all while stopped.

Also fixed: `android/gradle.properties` wanted a 4 GB heap + 2 GB metaspace on a 2 GB /
2-core build box, which got the Gradle daemon OOM-killed mid-build. Now bounded to 1 GB
with `org.gradle.parallel=false`; the box also needs the 3 GB swapfile recreated after a
sandbox reset.


---

## 10. v1.0.4 — "Client is already closed" (the real sync killer)

Full write-up: `SYNC_CLIENT_BUG.md`.

| Symptom | Cause | Fix |
|---|---|---|
| Every log row "offline — retrying in 45 s" while on 4G; `ClientException: HTTP request failed. Client is already closed.` | One `http.Client` was created per app run and **closed at the end of the first session** (`_BearerClient.close()` → `_inner.close()`), so every later Drive request failed. The first operation after each launch worked — which is exactly why sync looked like it only happened on restart | `_session()` builds a **client per session** (`buildSession(token, factory)`); the shared field is gone |
| "Offline" claimed on a healthy connection | `_classify()` returned `offline` for every unrecognised error, so a bug was reported as a network problem | `classifyError()` distinguishes closed-client (`error`), socket/timeout/connection (`offline`), 401/403 (`signedOut`), 403-quota (`driveFull`), 429/5xx (`offline`); unknown → `error` |
| A pointless 45 s retry loop for a bug | Retry scheduled regardless of cause | Only for `offline` |
| Log buried by identical failures | Every attempt appended | Identical consecutive failures merge into one row with ×N |
| Wall of red exception text in Settings | Raw message rendered directly | One short line (`sync failed — …`); details stay in the log |

New tests — `test/sync_client_test.dart` (4): two sessions get distinct clients and closing
the first leaves the second usable (fails on the old code); closed-client → `error`;
socket/timeout/connection errors → `offline`; unknown errors → `error`.
Suite: **31/31 passing**.

Honest note: this bug existed in v1.0.0–v1.0.3. Those builds synced once per launch and
then silently failed. The v1.0.3 log made it visible and is how it was found.


---

## 11. v1.0.5 — sync activity log removed from the UI

Confirmed working on a real device before this change: the log showed green
`pushed to Drive` rows every 30 s and `Full sync · pulled 35 book(s) from Drive`, so the
v1.0.4 client fix did its job.

On request, the **Sync activity list is no longer rendered anywhere**:

* Settings → Account now shows only the account, a live `Last synced: Ns ago`, and —
  **only while a book is loaded** — one compact tile: `Saving while playing · Local 4s ago ·
  Drive 21s ago`.
* The raw exception line is gone; a failure shows at most one short line
  (`sync failed — …`, `offline — retrying in 45 s`, `sign-in expired`).
* The internal `SyncActivity` log is **kept in the service but never displayed**. It costs
  nothing and it is the record that made the "Client is already closed" bug findable; it can
  be surfaced again on request (e.g. a hidden diagnostics screen).
* No behaviour changed: the 10 s / 30 s cadence, immediate pushes, pulls and the chip are
  all untouched. Tests: **31/31 passing**, analyzer 0 errors/0 warnings.
