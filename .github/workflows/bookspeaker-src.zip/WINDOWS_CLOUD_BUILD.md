# Building the Windows MSI in the cloud (no Visual Studio, no 7 GB download)

Everything is prepared. You upload **two files** to GitHub from any browser (phone is fine —
they total about 1.9 MB, not 7 GB), GitHub builds the MSI on its own Windows machines, and you
download the finished `.msi`.

---

## What's already in the project

| File | Purpose |
|---|---|
| `.github/workflows/windows-msi.yml` | The whole build: Flutter → Windows release → WiX → `.msi` → upload |
| `bookspeaker-src.zip` | The source bundle (1.9 MB) — **use this one**; the workflow unpacks it itself |
| `bookspeaker-src.tar.gz` | Same content in tar.gz form, if you prefer it |
| `windows/installer/Product.wxs` | WiX definition: per-user install, Start Menu shortcut, app icon, upgrade handling |
| `windows/installer/bookspeaker.ico` + `windows/runner/resources/app_icon.ico` | Real Bookspeaker icon for the installer and the `.exe` |
| `.gitignore` | Keeps the signing keystore, secrets, the 69 MB APK and build output **out** of the repo |

> **Secrets check:** the bundle deliberately excludes `android/key.properties`,
> `android/app/bookspeaker-release.jks` and `credentials/`. None of those ever reach GitHub.

---

## Path A — easiest (no git, works from a phone)

1. Go to <https://github.com/new>, create a repo (e.g. `bookspeaker`). Public or private — both
   work; public gets unlimited free build minutes.
2. On the new repo page click **Add file → Upload files**.
3. Upload the **workflow first** (it needs a folder path, which the web uploader handles if you
   drag the folders in):
   * `.github/workflows/windows-msi.yml`
   * `bookspeaker-src.zip`  ← the one that downloads reliably on phones/Windows
4. (`.tar.gz` also works if you prefer it.)

The web uploader can drift from the folder structure; the reliable version-driven way is
   Path B below. If the upload lands the workflow in the wrong place, just move it with
   **Add file → Create new file**, name it exactly
   `.github/workflows/windows-msi.yml`, and paste the contents in.
5. Commit. The build starts by itself.

## Path B — with git (any machine or phone with git)

```bash
cd bookspeaker
git init
git add .
git commit -m "Bookspeaker for Windows"
git branch -M main
git remote add origin https://github.com/<your-username>/bookspeaker.git
git push -u origin main
```

If you're on mobile data: the push is about **2 MB** (the 69 MB APK is gitignored).

---

## What happens next

Open the repo's **Actions** tab → *Build Windows MSI* → the running job. It takes roughly
**6–10 minutes** the first time (Flutter SDK download is the slow part; later runs are cached).

The job does, in order:

1. `flutter pub get` + `flutter analyze` (non-blocking)
2. `flutter test` — logged but **not** allowed to block the build
3. Reads the version from `pubspec.yaml` (currently `1.0.5+6`)
4. `flutter build windows --release` ← this is where Visual Studio would be needed locally; the GitHub runner has it preinstalled
5. Zips the runnable folder → artifact **`bookspeaker-windows-portable`** (always uploaded, even if everything after it fails)
6. Installs WiX 3.14, harvests the build output, compiles + links the MSI
7. Fetches `vc_redist.x64.exe` as a companion (see the runtime note below)
8. Uploads artifact **`bookspeaker-windows-msi`**

## Getting your file

**Artifacts** section at the bottom of the run page:

* `Bookspeaker-1.0.5+6-x64.msi` ← **this is the one** — double-click to install
* `Bookspeaker-windows-x64-portable.zip` — same app, no installer, just unzip and run
* `vc_redist.x64.exe` — only needed if the app refuses to start (see below)

Pushing a tag (`git tag v1.0.5 && git push --tags`) additionally attaches all three to a
**Release** page, which gives you permanent download links instead of expiring artifacts.

---

## What the MSI does on the PC

* Installs **for your user only** — no admin prompt, no UAC
* Goes to `%LOCALAPPDATA%\Bookspeaker\`
* Creates a **Start Menu → Bookspeaker** shortcut and a proper uninstall entry in
  *Settings → Apps*
* Upgrades cleanly: installing a newer MSI replaces the old one (a downgrade is refused)

Why per-user matters here: an MSIX/container-style package would redirect `%APPDATA%` and hide
Bookspeaker's SQLite database — your local progress. A normal MSI keeps it where the app
expects it, so upgrading never looks like data loss.

First launch may show **"Windows protected your PC"** once — that's SmartScreen for an
unsigned installer. Click *More info → Run anyway*. Signing with a real certificate is the only
way to remove it (see `WINDOWS_BUILD_PREREQUISITES.md`).

---

## Two honest caveats

**1. The MSI is not yet signed.** Windows will warn once on first run. Everything works.

**2. The Windows-only features are not in this build yet.** The MSI gives you a working
Bookspeaker on Windows — library, playback, local progress, bookmarks, covers. What is *not*
there yet, because it has to be written specifically for desktop:

* **Google sign-in.** `google_sign_in` does not work on Windows; it needs the loopback OAuth
  flow using your Desktop client (`credentials/google_desktop_client.json`). Until that exists,
  the Windows app runs in local-only mode — progress stays on the PC and does not sync with
  the phone.
* **Window sizing** (spec: 400×600 minimum, 420×800 default) — currently the stock 1280×720.
* **System tray** and the **mini player**.
* **File association** for `.mp3/.m4a/.opus`.

I'd suggest this order: get the MSI building and installed first, then I write the desktop
sign-in flow, then tray/mini-player. Each addition is a normal push that rebuilds the MSI.

**Runtime note:** Flutter Windows apps need the Visual C++ 2015–2022 runtime. Most PCs have
it; if Bookspeaker doesn't start at all (no window, no error), run the bundled
`vc_redist.x64.exe` once.

**If the workflow fails:** send me the failing step's log (Actions → the run → the red step →
copy the text). The WiX packaging is the fiddliest part and I have not been able to test it on
Windows from here — a first-run fix or two is likely, and I'll patch the workflow directly.

---

## After the first successful build

Everything is driven by the same pipeline, so future changes are just:

1. I update the source (and refresh `bookspeaker-src.tar.gz`),
2. you re-upload or push,
3. GitHub rebuilds the MSI automatically.

Keeping the version in `pubspec.yaml` in step with the Android APK means both platforms carry
the same number, which makes the Drive conflict messages ("Pixel 7 vs Desktop PC") easy to read.

---

## First run failed — what happened and what I changed

**Your run #2** (`Add files via upload`, commit `fae74b6`) reached the tests (29 passed, 2 failed —
that step is allowed to fail) and then died before producing any artifact. No artifacts at all
means the failure was in `flutter build windows` itself.

**Cause: Developer Mode.** On Windows, any Flutter app that uses plugins needs **symlink
support**, which is only available when Developer Mode is on. GitHub's runners ship with it
off, so the build stops with:

```
Building with plugins requires symlink support.
Please enable Developer Mode in your system settings.
```

This is the single most common reason a Flutter Windows build works on a dev machine — where
Developer Mode is usually on — and fails in CI.

**Fixes in this version of the workflow:**

1. **Enables Developer Mode** by setting the registry value that the setting controls
   (`HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock\AllowDevelopmentWithoutDevLicense`),
   plus `git config --system core.longpaths true` for deep paths.
2. **Self-diagnosing failures.** If `flutter build windows` fails again, the last 80 lines of
   its output are written straight into the run Summary, and a `build-logs` artifact with the
   full log is uploaded. You'll never need to guess again.
3. **Failing test names go into the Summary** (as a warning, still non-blocking).
4. **The two flaky tests were hardened.** They counted timer ticks inside fixed wall-clock
   windows (e.g. "≥3 pushes in 360 ms"), which a cold CI VM can miss. They now use longer
   windows and assert "the timer keeps repeating" rather than an exact count — still a real
   test of the 10 s/30 s cadence, no longer a coin flip.

### What to do now — two files

1. **Update the workflow** (this is the one that matters):
   repo → `.github/workflows/windows-msi.yml` → pencil icon → select all → paste the new
   contents → **Commit changes**.
2. **Upload the refreshed `bookspeaker-src.zip`** (same filename, replaces the old one) so the
   hardened tests are in the repo too.

Then open **Actions → Build Windows MSI → Run workflow** (or just wait for the push to trigger
it). If anything fails this time, copy the **Summary** text and send it to me — the reason will
be right there.
